
(function(){
'use strict';
const root=document.getElementById('rumo-app-preview');
const stage=root.querySelector('#rp-stage'),navigation=root.querySelector('#rp-navigation'),live=root.querySelector('#rp-live');
const O=(text,signals={},note='')=>({text,signals,note});
const questions=[
 {topic:'O que te dá energia',title:'Mesmo sem nota ou elogio, o que você continuaria fazendo?',hint:'Pense no que você faria por vontade própria, mesmo sem receber uma nota ou um elogio.',options:[O('Criar algo com o meu jeito.',{creative:3},'Vontade de criar com seu próprio estilo.'),O('Investigar uma dúvida até entender.',{team:1,enterprise:1},'Interesse em investigar antes de concluir.'),O('Juntar pessoas e tirar uma ideia do papel.',{team:1,enterprise:2},'Vontade de mobilizar pessoas para uma ideia.'),O('Ajudar alguém a aprender ou melhorar.',{team:2},'Interesse em contribuir para o desenvolvimento de alguém.'),O('Fazer algo concreto funcionar melhor.',{team:2,enterprise:1},'Satisfação em melhorar uma solução prática.')]},
 {topic:'O que você precisa no trabalho',title:'O que mais te desgasta numa tarefa?',hint:'Pense no que mais te cansa ou trava ao estudar, trabalhar ou fazer um projeto.',options:[O('Não poder decidir como fazer.',{enterprise:1,creative:1},'Necessidade de espaço para decidir como trabalhar.'),O('Não saber o que esperam de mim.',{team:2},'Preferência por expectativas claras.'),O('Repetir sem espaço para mudar nada.',{creative:2,enterprise:1},'Busca de variedade e espaço para mudar.'),O('Não enxergar para quem aquilo serve.',{team:1,enterprise:1},'Importância de perceber quem se beneficia do trabalho.'),O('Não saber como começar ou fazer a tarefa.',{},'Necessidade de entender como começar ou executar uma tarefa.')]},
 {topic:'Autonomia com apoio',title:'Você recebe uma tarefa sem instruções. Por onde começa?',hint:'Imagine que você precisa entregar algo, mas ninguém explicou como. Qual é sua primeira atitude?',options:[O('Peço um exemplo e depois sigo.',{team:2},'Preferência por uma referência inicial para começar.'),O('Defino um teste pequeno e tento.',{enterprise:2},'Disposição para começar com um teste próprio.'),O('Investigo algumas opções antes de escolher.',{team:1,enterprise:1},'Preferência por investigar opções antes de agir.'),O('Proponho um jeito próprio de fazer.',{creative:2,enterprise:1},'Vontade de propor um modo próprio de executar.')]},
 {topic:'O papel que você quer assumir',title:'Numa ideia sua, que parte você toparia assumir?',hint:'Pense em algo que você quer criar. Qual tarefa você aceitaria cuidar, além de ter a ideia?',options:[O('Criar e melhorar o que será entregue.',{creative:2,team:1},'Interesse em criar e aperfeiçoar a entrega.'),O('Ouvir pessoas e entender o que precisam.',{enterprise:2,team:1},'Interesse em descobrir necessidades de um público.'),O('Convidar alguém a testar ou comprar.',{enterprise:3},'Vontade de apresentar e testar uma proposta com um público.'),O('Organizar a equipe para entregar bem.',{team:2,enterprise:1},'Interesse em organizar uma entrega em equipe.')]},
 {topic:'Expressão e adaptação',title:'Uma criação sua precisa mudar para atender alguém. Como reage?',hint:'Imagine que alguém pede mudanças num texto, vídeo ou desenho seu. Escolha sua reação mais comum.',options:[O('Gosto de adaptar para resolver o pedido.',{team:2,creative:1},'Abertura para adaptar uma criação a um pedido.'),O('Adapto, mas quero preservar meu estilo.',{creative:2,enterprise:1},'Vontade de conciliar seu estilo com o que alguém precisa.'),O('Prefiro criar livre e buscar outro público.',{creative:3},'Preferência por preservar a liberdade da criação.'),O('Quero entender a mudança antes de decidir.',{team:1,enterprise:1},'Necessidade de entender um pedido antes de mudar.')]},
 {topic:'Seu jeito de lidar com incerteza',title:'Um projeto seu ainda não trouxe retorno. O que te ajuda a continuar?',hint:'O retorno pode ser dinheiro ou interesse das pessoas. Pense no que te apoiaria enquanto ele não vem.',options:[O('Um prazo de teste e limites claros.',{enterprise:2,team:1},'Preferência por experimentar com prazo e limites.'),O('Ter uma renda previsível em paralelo.',{team:2},'Importância de uma base previsível enquanto experimenta.'),O('Perceber pequenos sinais de interesse.',{enterprise:2},'Vontade de acompanhar a resposta real de um público.'),O('Apoio de alguém mais experiente.',{team:2},'Valor dado ao apoio de quem já tem experiência.')]},
 {topic:'Como você aprende com uma tentativa',title:'Alguém diz que sua ideia não funcionou. Seu primeiro impulso é…',hint:'Pense em quando recebeu uma crítica. Escolha o que faria primeiro, mesmo se depois mudasse de atitude.',options:[O('Entender o que aconteceu e ajustar.',{team:1,enterprise:1},'Vontade de entender o retorno e fazer ajustes.'),O('Pedir um exemplo do que esperavam.',{team:2},'Preferência por feedback com referências concretas.'),O('Testar outra solução e comparar.',{enterprise:2},'Interesse em comparar alternativas na prática.'),O('Revisar com calma antes de mudar.',{creative:1,team:1},'Preferência por um tempo de reflexão antes de revisar.')]},
 {topic:'O que faz o esforço valer a pena',title:'Qual conquista te daria mais satisfação?',hint:'Imagine que seu esforço deu resultado. Escolha a conquista que mais faria valer a pena para você.',options:[O('Virar referência numa habilidade.',{team:1,creative:1},'Desejo de aprofundar uma habilidade.'),O('Ver algo com a minha assinatura.',{creative:3},'Importância de reconhecer sua autoria no resultado.'),O('Ter pessoas usando algo que criei.',{enterprise:2,creative:1},'Satisfação em ver uma solução sua ser usada.'),O('Crescer numa equipe com renda regular.',{team:3},'Interesse em crescer com uma equipe e renda regular.')]},
 {topic:'Sua realidade também conta',title:'Você pode testar uma ideia sem precisar ganhar dinheiro com ela agora?',hint:'Considere seu tempo e suas contas: você precisa de dinheiro agora ou consegue testar aos poucos?',context:true,options:[O('Preciso começar a ganhar dinheiro com regularidade.'),O('Posso testar aos poucos, junto com os estudos ou o trabalho.'),O('Posso dedicar um tempo à ideia sem depender dela para pagar minhas contas.'),O('Ainda não sei quanto tempo e dinheiro consigo dedicar.')]},
 {topic:'Transformar descoberta em experiência',title:'Qual primeiro teste você toparia fazer?',hint:'Escolha algo que toparia experimentar por 7 dias, sem gastar dinheiro nem definir sua carreira.',context:true,options:[O('Criar um projeto autoral e pedir opinião.'),O('Ouvir duas pessoas e testar uma proposta.'),O('Conhecer uma função e fazer uma tarefa guiada.'),O('Comparar uma tarefa criativa e uma de negócio.')]}
];
const routes={
 team:{title:'Emprego e aprendizagem em equipe',short:'equipe',desc:'Conhecer uma função com referências, troca e uma rotina real de trabalho.',watch:'Ainda vale descobrir de quanta estrutura você gosta e que autonomia quer ter dentro de uma equipe.',test:'Peça a alguém conhecido para explicar uma tarefa da própria área. Faça uma versão introdutória e peça feedback.',combination:'Há trabalhos com autonomia e criação dentro de empresas. Estrutura não exige abrir mão das suas ideias.'},
 enterprise:{title:'Projeto empreendedor',short:'projeto próprio',desc:'Experimentar a criação de uma solução e a relação com quem pode usá-la.',watch:'É preciso observar também organização, rotina comercial, custos e resposta de clientes. Gostar de liberdade não resolve tudo isso.',test:'Converse com duas pessoas conhecidas sobre um problema. Desenhe uma proposta fictícia e peça opinião, sem investir ou depender de vendas.',combination:'Você pode aprender numa equipe e testar uma ideia em paralelo. Criar um projeto não exige abandonar os estudos ou uma fonte de renda.'},
 creative:{title:'Trabalho artístico e criativo',short:'criação',desc:'Explorar autoria, expressão e aperfeiçoamento de uma produção.',watch:'Ainda vale investigar se você prefere criação autoral, atender pedidos ou combinar os dois — e como manter essa rotina.',test:'Faça um pequeno projeto de criação: texto, música, vídeo, desenho ou outro formato. Peça uma opinião e observe como foi criar e revisar.',combination:'Você pode criar como contratado, autônomo ou dono de um negócio. A área criativa combina com diferentes formas de trabalho.'}
};
let answers=Array(questions.length).fill(null),step=0,view='home',previous='question',menuOpen=false;
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const complete=()=>answers.every(x=>x!==null);
function getProfile(values=answers){
 const scores=Object.fromEntries(Object.keys(routes).map(k=>[k,0])),evidence=Object.fromEntries(Object.keys(routes).map(k=>[k,[]]));
 questions.forEach((q,i)=>{if(q.context)return;const o=q.options[values[i]];if(!o)return;for(const [k,n] of Object.entries(o.signals)){scores[k]+=n;evidence[k].push({i,weight:n,text:o.note})}});
 const ranked=Object.keys(scores).sort((a,b)=>scores[b]-scores[a]);
 const top=ranked[0],second=ranked[1],enough=evidence[top].length>=3;
 const clear=enough&&scores[top]-scores[second]>=3;
 return {scores,evidence,ranked,top,second,enough,clear};
}
function closeMenu(){const wasOpen=menuOpen;menuOpen=false;navigation.hidden=true;root.querySelector('.rp-menu-shade').hidden=true;root.querySelector('.rp-main').inert=false;root.querySelector('[data-act="menu"]').setAttribute('aria-expanded','false');if(wasOpen)root.querySelector('[data-act="menu"]').focus({preventScroll:true})}
function openMenu(){menuOpen=true;navigation.hidden=false;root.querySelector('.rp-menu-shade').hidden=false;root.querySelector('.rp-main').inert=true;root.querySelector('[data-act="menu"]').setAttribute('aria-expanded','true');navigation.querySelector('.rp-drawer-close').focus({preventScroll:true})}
function reflection(){
 if(step<3)return '';
 if(answers[1]===0&&answers[2]===0)return 'Você sinalizou querer autonomia e também um exemplo para começar. Essas necessidades podem coexistir: apoio inicial e mais liberdade com o tempo.';
 if(step>=6&&answers[0]===0&&answers[4]===2)return 'Você destacou autoria e liberdade para criar. Agora vamos olhar também para o apoio de que precisa para manter essa rotina.';
 if(step>=6&&answers[2]===1&&answers[5]===1)return 'Você gosta da ideia de testar por conta própria e valoriza renda previsível em paralelo. Um projeto e uma base estável podem andar juntos.';
 if(step>=4&&answers[0]===2&&answers[3]===2)return 'Você citou tirar ideias do papel e organizar uma equipe. Vamos distinguir o interesse em liderar da vontade de cuidar também de clientes e de uma operação.';
 return '';
}
function aside(){const done=answers.map((v,i)=>({v,i})).filter(x=>x.v!==null&&x.v>=0&&x.i<8);const recent=done.slice(-2);return `<aside class="rp-aside"><small>Uma conversa sobre o seu momento</small><h3>${recent.length?'O que você já contou':'Aqui vale seu jeito real.'}</h3>${recent.length?`<ul>${recent.map(({v,i})=>`<li>${esc(questions[i].options[v].note)}</li>`).join('')}</ul>`:'<p>Não precisa parecer mais criativo, independente ou decidido. Escolha o que se aproxima do que você vive.</p>'}${reflection()?`<div class="rp-reflection"><small>Juntando suas respostas</small><p>${reflection()}</p></div>`:''}<div class="rp-reflection"><p>Preferências são pistas. Elas não medem talento nem dizem o que você consegue aprender.</p></div></aside>`}
function questionView(){const q=questions[step],a=answers[step];return `<button class="rp-home-back" data-act="home"><span aria-hidden="true">←</span> Voltar ao início</button><div class="rp-layout"><section><div class="rp-step-meta"><span>CONHECER SEU JEITO</span><span class="rp-count">${step+1} de ${questions.length}</span></div><div class="rp-track" role="progressbar" aria-label="Posição no questionário" aria-valuenow="${step+1}" aria-valuemin="0" aria-valuemax="${questions.length}"><span style="width:${(step+1)/questions.length*100}%"></span></div>${interestFocus?`<p class="rp-theme-note">Tema escolhido: ${esc(interestFocus)}. Agora vamos explorar como você gosta de trabalhar.</p>`:''}<span class="rp-overline">${q.topic}</span><h1>${q.title}</h1><p>${q.hint}</p><div class="rp-options" role="group" aria-label="${esc(q.title)}">${q.options.map((o,i)=>`<button class="rp-choice" data-option="${i}" aria-pressed="${a===i}"><span class="rp-choice-mark" aria-hidden="true">${a===i?'✓':''}</span><span>${o.text}</span></button>`).join('')}</div><button class="rp-skip" data-option="-1" aria-pressed="${a===-1}">${a===-1?'✓ ':''}Ainda não sei / nenhuma opção me representa</button><div class="rp-actions"><button class="rp-button rp-quiet" data-act="back" ${step===0?'disabled':''}>← Voltar</button><span style="font-size:12px;color:var(--rp-muted)">Uma opção · pode mudar depois</span><button class="rp-button" data-act="next" ${a===null?'disabled':''}>${step===9?'Ver minhas rotas':'Continuar'} →</button></div></section>${aside()}</div>`}
function overviewView(){return `<span class="rp-overline">A proposta completa</span><h1>Curto para responder.<br>Com espaço para pensar.</h1><p>Dez perguntas sobre situações e escolhas. Abra cada uma para ver as opções ou retome sua exploração.</p><button class="rp-button rp-secondary" data-act="question">${answers.some(v=>v!==null)?'Continuar minhas respostas':'Responder à primeira pergunta'} →</button><div class="rp-questions">${questions.map((q,i)=>`<details><summary><span class="rp-q-number">${String(i+1).padStart(2,'0')}</span>${q.title}</summary><p>${q.hint}</p><ul>${q.options.map((o,j)=>`<li>${esc(o.text)}${answers[i]===j?' <span style="color:var(--rp-lime)">← sua escolha</span>':''}</li>`).join('')}<li>Ainda não sei / nenhuma opção me representa.</li></ul><button class="rp-button rp-quiet rp-q-edit" data-jump="${i}">${answers[i]===null?'Responder':'Rever resposta'}</button></details>`).join('')}</div><details class="rp-transparency"><summary>O que esta proposta analisa?</summary><p>Motivação, autonomia, estrutura, relação com criação e público, apoio diante de incerteza e condições atuais. As perguntas são originais desta proposta, não itens de um teste psicológico validado. As respostas sobre interesses aproximam áreas; apoio, organização e condições atuais ajudam a adaptar a experiência.</p></details>`}
function baseContextText(values=answers){switch(values[8]){case 0:return 'Você precisa de renda previsível logo. Por isso, o plano começa por conhecer opções com uma base de renda e testar sua rota de interesse em paralelo, sem depender de retorno do experimento. Essa condição não define seu potencial.';case 1:return 'Você pode experimentar em paralelo ao estudo ou trabalho. Comece com um projeto pequeno e um limite de tempo que preserve seus compromissos.';case 2:return 'Você indicou tempo e apoio para testar sem contar com retorno. Combine um limite de tempo e recursos e observe a experiência antes de assumir compromissos maiores.';default:return 'Antes de ampliar um projeto, vale esclarecer seu tempo, recursos e necessidade de renda. O primeiro teste pode ser pequeno e sem compras.'}}
function comboText(p){const keys=[p.top,p.second];if(!p.enough)return 'Ainda faltam sinais repetidos. Experimente uma tarefa de cada rota antes de preferir uma delas.';if(keys.includes('creative')&&keys.includes('enterprise'))return 'Criação e projeto próprio podem se encontrar num negócio criativo. Também é possível testar autoria e atendimento a um público sem depender disso para ter renda.';if(keys.includes('creative')&&keys.includes('team'))return 'Você pode conhecer uma equipe criativa ou um trabalho com espaço para autoria. Fazer arte e ter um emprego são possibilidades que podem andar juntas.';return 'Aprender numa equipe e experimentar uma ideia própria em paralelo pode ajudar a comparar as duas rotinas, sem precisar escolher tudo agora.'}
const chosenTests=['Criar um pequeno projeto autoral, pedir uma opinião e observar como foi revisar.','Ouvir duas pessoas conhecidas sobre um problema e pedir opinião sobre uma proposta fictícia, sem gastar.','Conhecer uma função com alguém conhecido e experimentar uma tarefa introdutória com orientação.','Fazer uma criação curta e uma proposta fictícia. Comparar o que deu mais energia e o que foi mais difícil.'];
function originalResultView(){if(!complete()){const missing=answers.filter(x=>x===null).length;return `<h1>Vamos completar seu mapa.</h1><p>${missing===1?'Falta 1 pergunta':'Faltam '+missing+' perguntas'} para comparar suas rotas. Você pode escolher uma opção ou marcar “Ainda não sei”. Suas respostas anteriores continuam aqui.</p><button class="rp-button" data-act="question">Ir à primeira pergunta pendente →</button>`;}const p=getProfile();const first=p.clear?routes[p.top].title:p.enough?'Mais de uma rota merece um teste':'Ainda faltam pistas para destacar uma rota';return `<span class="rp-overline">Seu mapa de formas de trabalhar</span><h1>${first}</h1><p>${p.clear?'Esta rota reuniu mais sinais nas suas respostas. Ela é um primeiro experimento possível, não uma previsão sobre onde você vai se sair melhor.':p.enough?'Suas respostas apontam para interesses que podem coexistir. O mapa não força uma escolha quando os sinais estão próximos.':'As opções abaixo servem como exemplos para explorar. Com poucas respostas, a ordem não deve ser lida como preferência sua.'}</p>${interestFocus?`<p class="rp-theme-note">Use o tema ${esc(interestFocus)} nos projetos e tarefas quando fizer sentido. Ele não decide sozinho sua rota.</p>`:''}<div class="rp-route-grid">${p.ranked.map((k,index)=>{const r=routes[k],ev=p.evidence[k].slice().sort((a,b)=>b.weight-a.weight).slice(0,3);return `<article class="rp-route ${p.clear&&index===0?'rp-highlight':''}"><span class="rp-tag">${p.clear&&index===0?'Primeira rota para testar':ev.length>=3?'Sinais presentes em várias respostas':ev.length?'Pistas iniciais':'Ainda sem sinais seus'}</span><h2>${r.title}</h2><p>${r.desc}</p><span class="rp-label">O que nas suas respostas aponta para isso</span>${ev.length?`<ul class="rp-evidence">${ev.map(e=>`<li>${esc(e.text)}</li>`).join('')}</ul>`:'<p>Não temos respostas suas que apoiem esta rota por enquanto.</p>'}<span class="rp-label">O que falta descobrir</span><p>${r.watch}</p><span class="rp-label">Um teste pequeno</span><p>${r.test}</p><div class="rp-route-bottom"><span class="rp-plan-caption">Rotina sugerida · primeiros 7 dias</span><button class="rp-button rp-secondary" data-up-route="${k}">Conhecer esse caminho ↗</button><button class="rp-button rp-secondary" data-route="${k}">Ver rotina e plano →</button></div></article>`}).join('')}</div><div class="rp-summary"><h3>Uma combinação que vale comparar</h3><p>${comboText(p)}</p></div><div class="rp-context"><h3>Seu momento muda o plano, não seu valor.</h3><p>${contextText()}</p><span class="rp-label">Seu teste escolhido</span><p>${chosenTests[answers[9]]||'Você ainda não escolheu. Experimente uma das propostas dos cartões, sem compromisso com uma carreira.'}</p></div><p style="margin-top:20px">Arte é uma área de atuação. Emprego e empreendedorismo são formas de trabalhar. Você pode ser artista contratado, autônomo ou ter um negócio criativo.</p><details class="rp-transparency"><summary>Como chegamos a este mapa?</summary><p>Regras editoriais somam pistas das oito primeiras respostas e procuram sinais repetidos. A ordem não é uma nota de aptidão, chance de sucesso ou diagnóstico. Preferências por apoio e estrutura não impedem criar um negócio; gostar de autonomia não prova preparo para empreender. Empates são apresentados sem uma rota vencedora.</p><p>As perguntas foram escritas para esta proposta, inspiradas na distinção entre interesses, valores e estilos de trabalho. O questionário não foi validado como instrumento psicológico. Resultados precisam ser confrontados com experiências e, quando útil, orientação profissional.</p><div class="rp-source-links"><a href="https://www.onetcenter.org/content.html" target="_blank" rel="noopener noreferrer">O*NET · interesses e estilos</a><a href="https://capd.mit.edu/channels/self-assessments/" target="_blank" rel="noopener noreferrer">MIT · autorreflexão e carreira</a></div></details><div class="rp-actions"><button class="rp-button rp-secondary" data-act="question">← Rever minhas respostas</button><button class="rp-button rp-quiet" data-act="restart">Recomeçar jornada</button></div>`}
function resetView(){return '<section class="rp-reset-panel"><span class="rp-overline">Recomeçar jornada</span><h1>Testar outras escolhas?</h1><p>Suas respostas, registros, criações, comparações, missões em dupla, conquistas, feedback e acesso simulado desta prévia serão limpos. Você volta à primeira pergunta para explorar outro cenário.</p><div class="rp-actions"><button class="rp-button rp-secondary" data-act="cancel-reset">Cancelar</button><button class="rp-button" data-act="confirm-reset">Sim, recomeçar</button></div></section>'}
const routinePlans={
 creative:{intro:'Reserve um momento para criar, testar uma técnica e perceber o que combina com seu jeito.',focus:'Um projeto de criação, do primeiro rascunho à revisão.',days:[
 ['Escolha seu projeto','Escolha um projeto de criação: um texto, uma música, um vídeo, um desenho ou outro formato. Defina um projeto pequeno que consiga terminar nesta semana.'],
 ['Observe referências','Escolha duas referências artísticas e anote o que chama sua atenção nelas. Use elas como estudo para fazer o seu projeto, sem copiar a criação de outra pessoa.'],
 ['Faça um rascunho','Crie uma primeira versão simples. Não precisa mostrar nem deixar perfeita.'],
 ['Pratique um detalhe','Escolha uma técnica que ajudaria o seu projeto e faça um exercício curto.'],
 ['Termine uma versão','Junte o que testou e conclua uma versão pequena. Observe como foi terminar, não só começar.'],
 ['Ouça outra perspectiva','Se quiser, mostre a alguém conhecido e pergunte o que ficou claro. Você também pode revisar por conta própria.'],
 ['Veja o que te deu energia','Compare criar, praticar e revisar. Registre o que gostaria de repetir e o que prefere mudar.'],
 ['Escolha um segundo projeto','Mantenha o formato ou mude um detalhe do primeiro projeto. Defina um novo projeto pequeno.'],
 ['Experimente outra técnica','Estude uma introdução gratuita e aplique um único recurso no seu projeto.'],
 ['Desenvolva o segundo projeto','Faça um projeto curto usando o que aprendeu. Compare o processo com a primeira semana.'],
 ['Teste um pedido fictício','Imagine um projeto de criação para um evento da escola, faculdade ou bairro. Perceba como é criar com um objetivo dado.'],
 ['Revise sem apagar seu estilo','Faça uma alteração pensando em quem vai ver. Observe o equilíbrio entre autoria e pedido.'],
 ['Organize seus projetos','Reúna os projetos em uma pasta privada e escreva o que fez e o que melhorou. Publicar é opcional.'],
 ['Escolha o próximo passo','Decida entre aprofundar uma técnica, conhecer uma rotina criativa em equipe ou experimentar outra rota.']
 ]},
 team:{intro:'Experimente aprender com uma referência, cumprir uma tarefa pequena e trocar feedback.',focus:'Conhecer uma função e testar um pouco do seu dia a dia.',days:[
 ['Escolha uma função','Escolha uma atividade profissional que desperte curiosidade. Anote o que você imagina que a pessoa faz.'],
 ['Conheça as tarefas reais','Pesquise uma descrição da função em fontes da área. Separe três tarefas frequentes, além do nome do cargo.'],
 ['Encontre uma habilidade para praticar','Escolha uma dessas tarefas e anote o que já sabe e o que precisaria aprender.'],
 ['Faça uma tarefa introdutória','Use um exercício gratuito e guiado para experimentar uma parte simples da função.'],
 ['Peça uma referência','Se puder, converse com alguém conhecido da área ou peça feedback sobre seu exercício. Não precisa procurar desconhecidos.'],
 ['Simule um bloco de trabalho','Escolha uma tarefa, defina a entrega e tente concluí-la no tempo que reservou. Observe dúvidas e interrupções.'],
 ['Compare expectativa e experiência','Registre o que gostou na rotina, como recebeu orientação e o que ainda quer conhecer sobre trabalhar numa equipe.'],
 ['Escolha uma habilidade para melhorar','Retome a dificuldade que mais apareceu e defina uma prática curta.'],
 ['Pratique com uma referência','Refaça um exercício ou acompanhe uma demonstração gratuita. Registre o que ficou mais claro.'],
 ['Repita a tarefa com mais autonomia','Faça uma nova versão sem seguir cada passo da referência. Peça ajuda quando precisar.'],
 ['Entenda o ambiente','Pesquise como a equipe costuma dividir tarefas e o que muda entre organizações. Evite generalizar uma única experiência.'],
 ['Organize seus exemplos','Reúna um exercício e situações reais em que usou uma habilidade. Não invente experiências ou qualificações.'],
 ['Compare caminhos de entrada','Conheça requisitos reais de formação e oportunidades de entrada em fontes oficiais das organizações.'],
 ['Decida uma ação concreta','Escolha entre aprofundar a habilidade, conversar com alguém da área ou preparar uma candidatura compatível com seu momento.']
 ]},
 enterprise:{intro:'Reserve um bloco para ouvir pessoas, testar uma hipótese e ajustar uma solução sem depender de vendas.',focus:'Descobrir se um problema e uma proposta fazem sentido para alguém.',days:[
 ['Escolha um problema real','Anote um problema que observa entre pessoas conhecidas. Evite começar apenas pelo produto que gostaria de vender.'],
 ['Escute duas pessoas','Pergunte a duas pessoas conhecidas como lidam com esse problema. Ouça antes de apresentar sua solução.'],
 ['Resuma o que descobriu','Escreva para quem é o problema, quando acontece e como a pessoa tenta resolver hoje. Separe observação de suposição.'],
 ['Desenhe uma proposta','Faça um esboço ou explicação simples de uma solução. Não compre materiais nem assuma compromissos.'],
 ['Peça opinião sobre a proposta','Mostre o rascunho e pergunte o que seria útil ou confuso. Um elogio não confirma que alguém compraria.'],
 ['Ajuste e pense na operação','Revise um detalhe e anote as tarefas, o tempo e os recursos que seriam necessários. Por enquanto, mantenha no papel.'],
 ['Reveja a hipótese','Compare suas suposições com o que ouviu. Decida se vale ajustar, testar outra ideia ou pausar.'],
 ['Escolha uma dúvida importante','Identifique o que ainda não sabe: problema, público, proposta ou modo de entregar. Escolha apenas uma dúvida para testar.'],
 ['Compare alternativas','Veja como as pessoas já resolvem o problema e o que ainda falta. Não presuma que uma solução nova será melhor.'],
 ['Faça um protótipo simples','Prepare um exemplo, uma tela ou uma simulação da entrega usando recursos que já tem.'],
 ['Observe o uso da simulação','Convide uma pessoa conhecida a experimentar o exemplo. Anote onde ela precisa de explicação, sem cobrar ou prometer uma entrega real.'],
 ['Revise a viabilidade','Reveja tarefas, tempo e possíveis custos. Diferencie preço imaginado de evidência real de interesse.'],
 ['Decida o limite do próximo teste','Defina tempo e recursos máximos antes de ampliar. Você pode manter o projeto em paralelo aos estudos ou trabalho.'],
 ['Escolha o próximo experimento','Continue, ajuste o público ou pause com base no que aprendeu. Concluir o plano não exige abrir uma empresa nem garante retorno.']
 ]}
};
const newRoutine=()=>({days:Array.from({length:14},()=>({registered:false,mood:'',note:''})),extended:false,openDay:0,passAccess:false,feedback:{feeling:null,next:null,note:'',saved:false}});
let routineState=freshRoutes(),activeRoute='creative';
routineState.creative.openDay=0;
const moodLabels={liked:'Gostei e quero repetir',mixed:'Algumas partes fizeram sentido',different:'Prefiro experimentar outra tarefa',notdone:'Ainda não consegui fazer',other:'Outra resposta — escrever'};
function routineCount(k,limit=7){return routineState[k].days.slice(0,limit).filter(d=>d.registered).length}
function baseRoutineTiming(){const smaller=routineState[activeRoute].feedback.saved&&routineState[activeRoute].feedback.next==='smaller';return smaller||answers[8]===0?{prepare:3,practice:10,reflect:2,total:15}:answers[8]===2?{prepare:5,practice:20,reflect:5,total:30}:{prepare:3,practice:12,reflect:5,total:20}}
function routinesView(){return `<section class="up-page"><button type="button" class="rp-home-back" data-act="home"><span aria-hidden="true">←</span> Voltar ao início</button><span class="rp-overline">7 experiências por caminho</span><h1>Cada área,<br><em>uma semana diferente.</em></h1><p>Escolha uma área para ver seus sete testes específicos. O mesmo plano é usado quando você chega pelo questionário.</p><div class="up-path-grid">${Object.entries(routes).map(([k,r])=>`<article class="up-box"><h2>${r.title}</h2><ol class="ex-route-list">${experimentalWeeks[k].map(([title])=>`<li>${title}</li>`).join('')}</ol><button class="rp-button rp-secondary" data-route="${k}">Abrir estes 7 passos →</button><button class="rp-link" data-up-route="${k}">Ver detalhes das experiências ↗</button></article>`).join('')}</div></section>`}
function routineView(){const k=activeRoute,p=getPlan(k),r=routes[k],rs=routineState[k],limit=rs.extended?14:7,count=routineCount(k,limit),weekOne=routineCount(k,7),timing=routineTiming();return `<div class="rp-plan-toolbar"><button class="rp-link" data-act="routines">← Comparar rotinas</button>${complete()?'<button class="rp-link" data-act="results">Voltar ao meu mapa</button>':''}</div><span class="rp-overline">${r.title}</span><h1>Sua rotina para experimentar.</h1><p>${p.intro} Ajuste os horários à sua vida; não precisa fazer tudo em dias seguidos.</p><section class="rp-rhythm"><div><span class="rp-plan-caption">UM BLOCO POR DIA</span><h2>${timing.total} minutos como ponto de partida</h2><p>${answers[8]===0?'Você indicou precisar de renda agora. Esta é uma exploração curta, que pode acontecer em paralelo à busca por uma base de renda.':answers[8]===2?'Você indicou ter tempo para testar. Comece pequeno e aumente apenas se fizer sentido para você.':'Comece com um bloco curto, junto dos seus outros compromissos.'}</p></div><ol class="rp-rhythm-parts"><li><span>${timing.prepare} min</span><div><strong>Preparar</strong><small>Escolher a tarefa de hoje.</small></div></li><li><span>${timing.practice} min</span><div><strong>Experimentar</strong><small>Fazer uma versão pequena.</small></div></li><li><span>${timing.reflect} min</span><div><strong>Registrar</strong><small>Anotar como foi para você.</small></div></li></ol></section><div class="rp-plan-grid"><section><div class="rp-plan-heading"><div><span class="rp-overline">${rs.extended?'Continue até 14 dias':'Seus primeiros 7 dias'}</span><h2>Um passo por dia.</h2></div><span class="rp-plan-caption">${count} de ${limit} registros</span></div><div class="rp-track" role="progressbar" aria-label="Dias registrados" aria-valuenow="${count}" aria-valuemin="0" aria-valuemax="${limit}"><span style="width:${count/limit*100}%"></span></div><div class="rp-plan-days">${p.days.slice(0,limit).map(([title,task],i)=>{const d=rs.days[i];return `<details class="rp-plan-day" data-plan-day="${i}" ${rs.openDay===i?'open':''}><summary><span class="rp-day-number ${d.registered?'rp-day-done':''}" aria-label="${d.registered?'Dia registrado':'Dia ainda sem registro'}">${d.registered?'✓':String(i+1).padStart(2,'0')}</span><span><small>Dia ${i+1}${i>6?' · continuação':''}</small><strong>${esc(title)}</strong></span><span class="rp-day-plus" aria-hidden="true">+</span></summary><div class="rp-day-body"><p>${esc(task)}</p><div class="rp-mood-label">Como foi a tarefa de hoje para você?</div><p class="rp-checkin-help">Escolha como foi ou use “Outra resposta” para escrever do seu jeito. Depois, registre o dia.</p><details class="rp-select-menu"><summary id="rp-mood-${k}-${i}" aria-label="Como foi o dia ${i+1}: ${d.mood?moodLabels[d.mood]:'escolha uma opção'}"><span class="rp-select-value">${d.mood?moodLabels[d.mood]:'Escolha uma opção'}</span><span class="rp-select-chevron" aria-hidden="true">⌄</span></summary><fieldset class="rp-dropdown-options"><legend class="rp-dropdown-legend">Como foi o dia ${i+1}?</legend>${Object.entries(moodLabels).map(([v,t])=>`<button type="button" class="rp-dropdown-option" data-mood-choice="${i}" data-mood-value="${v}" aria-pressed="${d.mood===v}">${t}</button>`).join('')}</fieldset></details><label for="rp-note-${k}-${i}">${d.mood==='other'?'Sua resposta, com suas palavras':'O que você descobriu? <span>(opcional)</span>'}</label><textarea id="rp-note-${k}-${i}" data-day-note="${i}" maxlength="2000" aria-required="${d.mood==='other'}" placeholder="${d.mood==='other'?'Ex.: Gostei de começar, mas precisei de ajuda para terminar.':'Uma frase já ajuda…'}">${esc(d.note)}</textarea><div class="rp-day-save"><button class="rp-button rp-secondary" data-register-day="${i}" ${!d.mood||(d.mood==='other'&&!d.note.trim())?'disabled':''}>${d.registered?'Atualizar registro':'Registrar este dia'}</button>${d.registered?'<span class="rp-recorded">Registro feito ✓</span>':''}</div>${d.registered?'<div class="ry-record-actions"><button class="rp-link" data-y-action="new-creation">Guardar algo que criei ↗</button><button class="rp-link" data-y-nav="achievements">Minhas conquistas</button></div>':''}</div></details>`}).join('')}</div></section><aside class="rp-plan-side"><div class="rp-continuation"><span class="rp-overline">Depois dos primeiros 7 dias</span><h3>${rs.passAccess?'Sua continuação está liberada.':'Abra seu Passaporte da jornada.'}</h3><p>${rs.passAccess?'Os dias 8 a 14 estão no plano. Seu feedback e o histórico da primeira semana ficam no Passaporte.':weekOne===7?'Conte como foi a semana, veja seus registros e conheça a continuação opcional.':'Complete os sete registros para abrir seu feedback da semana e conhecer os próximos passos.'}</p><button class="rp-button ${weekOne<7?'rp-quiet':''}" data-act="passport" ${weekOne<7?'disabled':''}>${weekOne<7?'Concluir 7 registros':'Abrir meu Passaporte →'}</button><small>${weekOne} de 7 registros da primeira semana</small></div><div class="rp-plan-reminder"><h3>O objetivo é descobrir, não acertar tudo.</h3><p>Mesmo se não conseguiu fazer a tarefa, registre como foi. Uma dificuldade também ajuda a ajustar o próximo passo.</p><p>Você pode testar outra rota sem apagar os registros desta.</p></div><div class="rp-plan-reminder"><h3>Seu progresso está com você</h3><p>Os registros ficam salvos neste navegador e dispositivo. Você pode voltar depois. Limpar os dados do navegador pode apagar sua jornada.</p></div></aside></div>${rs.extended&&count===14?'<div class="rp-summary"><h3>Você registrou duas semanas de experiências.</h3><p>Releia o que deu energia e o que não fez sentido. Escolha entre aprofundar uma habilidade, ajustar a rotina ou comparar outra rota. Continuar é uma escolha sua.</p></div>':''}`}
function openRoutine(k){if(!Object.hasOwn(routes,k))return;routeChosen=true;activeRoute=k;navigate('routine')}
function registerRoutineDay(i){const rs=routineState[activeRoute],limit=rs.extended?14:7;if(!Number.isInteger(i)||i<0||i>=limit||!rs.days[i].mood||(rs.days[i].mood==='other'&&!rs.days[i].note.trim()))return;if(!rs.days[i].taskSnapshot)rs.days[i].taskSnapshot=getPlan(activeRoute).days[i].slice();rs.days[i].registered=true;const next=rs.days.findIndex((d,j)=>j<limit&&!d.registered);rs.openDay=next>=0?next:i;render();live.textContent=routineCount(activeRoute,7)===7&&!rs.extended?'Sete dias registrados. Abra o Passaporte para refletir sobre a semana e conhecer a continuação.':'Dia '+(i+1)+' registrado.'}
function selectRoutineMood(i,value){
 const rs=routineState[activeRoute],limit=rs.extended?14:7;
 if(!Number.isInteger(i)||i<0||i>=limit||!Object.hasOwn(moodLabels,value))return;
 rs.days[i].mood=value;rs.openDay=i;
 if(value==='other'&&!rs.days[i].note.trim())rs.days[i].registered=false;
 render();
 const target=root.querySelector(value==='other'?'[data-day-note="'+i+'"]':'#rp-mood-'+activeRoute+'-'+i);
 if(target)target.focus({preventScroll:true});
 live.textContent=value==='other'?'Escreva sua resposta para registrar este dia.':'Opção escolhida: '+moodLabels[value];
}
root.addEventListener('input',event=>{
 if(event.target.dataset.dayNote===undefined)return;
 const i=Number(event.target.dataset.dayNote),rs=routineState[activeRoute],d=rs.days[i];
 if(!d)return;d.note=event.target.value.slice(0,2000);
 if(d.mood==='other'&&!d.note.trim()&&d.registered){d.registered=false;rs.openDay=i;render();root.querySelector('[data-day-note="'+i+'"]')?.focus({preventScroll:true})}
 const button=root.querySelector('[data-register-day="'+i+'"]');
 if(button)button.disabled=!d.mood||(d.mood==='other'&&!d.note.trim());
});

const feedbackFeeling={deepen:'Quero aprofundar essa rota',adjust:'Quero ajustar e comparar',change:'Prefiro conhecer outra rota'};
const feedbackNext={same:'Manter esse ritmo',smaller:'Fazer tarefas menores',compare:'Comparar outra rota'};
let passportDemo=false,demoSnapshot=null,interestFocus=null;
// Fictitious examples are explicitly labelled in the preview, never presented as the visitor's records.
const demoNotes=['Escolhi um projeto de vídeo curto.','As referências ajudaram a organizar a ideia.','Gostei de criar, mas travei para começar.','Praticar um detalhe ficou mais fácil.','Terminei uma primeira versão pequena.','O feedback de alguém conhecido ajudou.','Quero entender melhor como manter uma rotina.'];

function passportUnlocked(){return routineCount(activeRoute,7)===7}
function passportIntro(){return `<div class="rp-pass-heading"><div><span class="rp-overline">Passaporte da jornada</span><h1>O que essa semana te mostrou?</h1><p>Suas experiências viram pistas para escolher como continuar.</p></div><div class="rp-pass-mark" aria-hidden="true">7<span>DIAS</span></div></div>`}
function passportView(){const rs=routineState[activeRoute],f=rs.feedback,week=routineCount(activeRoute,7);if(week<7)return `<span class="rp-overline">Passaporte da jornada</span><h1>Seu Passaporte está em construção.</h1><p>Você registrou ${week} de 7 dias nesta rota. Ao completar os sete registros, abre uma reflexão da semana e a opção de conhecer a continuação.</p><button class="rp-button" data-route="${activeRoute}">Voltar ao meu plano →</button>`;return `${passportIntro()}<div class="rp-pass-route"><span>ROTA EXPLORADA</span><strong>${routes[activeRoute].title}</strong></div><div class="rp-stamps" aria-label="Primeira semana: sete dias registrados">${Array.from({length:7},(_,i)=>`<span><small>Dia ${i+1}</small><b aria-hidden="true">✓</b><small>Registrado</small></span>`).join('')}</div>${youthNextCallout()}<div class="rp-pass-grid"><section><div class="rp-feedback"><span class="rp-overline">Uma pausa para perceber</span><h2>Conte como foi para você.</h2><p>Não precisa ter gostado de tudo. Suas respostas ajudam a ajustar o próximo passo.</p><div class="rp-feedback-field"><h3>Depois desta semana, como essa rota ficou para você?</h3><div class="rp-feedback-options" role="group" aria-label="Como ficou esta rota para você">${Object.entries(feedbackFeeling).map(([v,t])=>`<button class="rp-feedback-choice" data-feedback-field="feeling" data-feedback-value="${v}" aria-pressed="${f.feeling===v}">${t}</button>`).join('')}</div></div><div class="rp-feedback-field"><label for="rp-feedback-note">O que mais te ajudou ou travou? <span>(opcional)</span></label><textarea id="rp-feedback-note" data-feedback-note maxlength="2000" placeholder="Ex.: Gostei de criar, mas precisei de tarefas menores para conseguir terminar.">${esc(f.note)}</textarea></div><div class="rp-feedback-field"><h3>Como você quer seguir?</h3><div class="rp-feedback-options" role="group" aria-label="Como quer continuar">${Object.entries(feedbackNext).map(([v,t])=>`<button class="rp-feedback-choice" data-feedback-field="next" data-feedback-value="${v}" aria-pressed="${f.next===v}">${t}</button>`).join('')}</div></div><div class="rp-actions"><button class="rp-button" data-act="save-feedback" ${!f.feeling||!f.next?'disabled':''}>${f.saved?'Atualizar meu feedback':'Guardar no meu Passaporte'} →</button>${f.saved?'<span class="rp-recorded">Feedback registrado ✓</span>':''}</div></div>${f.saved?`<div class="rp-summary"><h3>Seu próximo passo, por enquanto</h3><p>${feedbackAdvice(f)}</p>${f.next==='compare'||f.feeling==='change'?'<button class="rp-link" data-act="routines">Comparar as outras rotinas →</button>':''}</div>`:''}<section class="rp-pass-history"><h2>O que você já viveu nesta rota.</h2><p>Os registros da primeira semana continuam acessíveis. A continuação é opcional.</p>${rs.days.slice(0,7).map((d,i)=>`<details><summary>Dia ${i+1} · ${esc(getPlan(activeRoute).days[i][0])}</summary><p><strong>Como foi:</strong> ${esc(d.mood==='other'?d.note:moodLabels[d.mood])}</p>${d.note&&d.mood!=='other'?`<p>${esc(d.note)}</p>`:''}</details>`).join('')}</section></section><aside><div class="rp-pass-offer"><span class="rp-overline">Próximo capítulo</span><h2>${rs.passAccess?'Sua continuação está liberada.':'Passaporte de continuação'}</h2><p>${rs.passAccess?'Volte ao plano para ver os dias 8 a 14 e continuar registrando as descobertas.':'Continue do dia 8 ao 14 com novas tarefas e um ritmo ajustado ao seu feedback.'}</p><ul><li>Dias 8 a 14 da rota escolhida.</li><li>Registros e reflexão ao final.</li><li>Opção de adaptar o ritmo ou comparar rotas.</li></ul>${rs.passAccess?'<button class="rp-button" data-act="continue-plan">Abrir dias 8 a 14 →</button>':`<span class="rp-pass-paid">Novas experiências · dias 8 a 14</span><button class="rp-button" data-act="review-passport" ${!f.saved?'disabled':''}>Conhecer a continuação →</button><small>${f.saved?'Veja o que inclui antes de decidir.':'Registre o feedback para ver a continuação.'}</small>`}<p class="rp-pass-fine">Nesta prévia, o acesso é simulado. Não há cobrança nem coleta de dados de pagamento.</p></div><div class="rp-plan-reminder"><h3>Você continua no comando.</h3><p>Parar, comparar outra rota ou continuar são escolhas válidas. Você não precisa pagar para ver os registros dos primeiros sete dias.</p></div></aside></div><button class="rp-link" data-route="${activeRoute}">← Voltar ao plano</button>`}
function feedbackAdvice(f){if(f.feeling==='change')return 'Essa experiência ajudou a perceber o que não combina tanto com você agora. Compare outra rotina antes de decidir continuar nesta.';if(f.next==='smaller')return 'Você quer seguir com tarefas menores. A continuação pode começar com um bloco de 15 minutos, ajustável ao seu dia.';if(f.next==='compare'||f.feeling==='adjust')return 'Vale comparar o que deu energia com outra forma de trabalhar. Você pode explorar as outras rotinas sem apagar estes registros.';return 'Você quer aprofundar esta rota e manter o ritmo. A segunda semana propõe repetir, revisar e comparar o que aprendeu.'}
function purchasePreview(){const rs=routineState[activeRoute];if(!passportUnlocked()||!rs.feedback.saved)return passportView();return `<button class="rp-link" data-act="passport">← Voltar ao meu Passaporte</button><div class="rp-purchase"><div><span class="rp-overline">Passaporte de continuação</span><h1>Mais uma semana para se conhecer.</h1><p>Continue sua exploração em <strong>${routes[activeRoute].title}</strong>, com o que aprendeu nos primeiros sete dias.</p><div class="rp-summary"><h3>O ajuste a partir do seu feedback</h3><p>${feedbackAdvice(rs.feedback)}</p></div><h3>O que entra na continuação</h3><ul class="rp-purchase-list"><li>Sete tarefas novas, do dia 8 ao 14.</li><li>Um ritmo que você pode adaptar aos compromissos.</li><li>Espaço para registrar experiências e rever escolhas.</li></ul><p>Seu histórico da primeira semana permanece acessível. A continuação é opcional e não garante renda ou resultado profissional.</p></div><aside class="rp-checkout-preview"><span class="rp-pass-paid">SEU PRÓXIMO CAPÍTULO</span><h2>Continuar do dia 8 ao 14.</h2><p><strong>Seu próximo capítulo começa aqui.</strong></p><p>Explore novas tarefas do dia 8 ao 14, ajuste seu ritmo e continue registrando o que descobre sobre você.</p><button class="rp-button" data-act="simulate-passport">Simular acesso nesta prévia →</button><small>Este botão apenas demonstra a liberação. Nenhum pagamento é processado.</small></aside></div>`}
root.addEventListener('input',event=>{if(!event.target.hasAttribute('data-feedback-note'))return;routineState[activeRoute].feedback.note=event.target.value.slice(0,2000)});

function landingView(){const has=answers.some(v=>v!==null),state={completed:complete()};return `<section class="page home-page"><div class="home-hero"><div><div class="hero-kicker"><span>Geração em movimento</span> O próximo passo é seu</div><h1>Descubra o que te move.<br><em>Construa seu futuro.</em></h1><p class="lead">Tem muita coisa que você ainda pode ser. Explore seus interesses e transforme uma dúvida em uma experiência de verdade.</p><div class="actions"><button class="rumo-btn" data-act="start">${state.completed?'Revisitar meu mapa':has?'Continuar minha jornada':'Encontrar meu primeiro passo'} <span>↗</span></button><button class="subtle-link" data-act="example">Ver uma jornada de exemplo</button></div><div class="hero-proof"><span><b>✓</b> Versão gratuita</span><span><b>✓</b> Sem cadastro</span><span><b>✓</b> No seu ritmo</span></div></div><div class="world" aria-hidden="true"><div class="world-grid"></div><svg class="world-routes" viewBox="0 0 460 490" preserveAspectRatio="none"><ellipse cx="225" cy="245" rx="170" ry="200" class="path" transform="rotate(30 225 245)"/><ellipse cx="225" cy="245" rx="210" ry="125" class="path path2" transform="rotate(-30 225 245)"/><path d="M 75 115 Q 290 60 385 235 T 80 440" class="path"/><circle cx="343" cy="81" r="4" fill="#b4a0ff"/><circle cx="425" cy="322" r="4" fill="#c7ff62"/><circle cx="118" cy="295" r="3" fill="#99cfff"/></svg><span class="spark">✳</span><span class="spark s2">✧</span><div class="world-core"><svg viewBox="0 0 80 80"><path d="M13 61 52 22H21V9h54v54H62V32L23 71z" fill="#c7ff62"/></svg></div><div class="world-tile one"><small>Explore uma ideia</small><span class="tile-symbol">⌘</span><strong>Criar o que<br>ainda não existe.</strong></div><div class="world-tile two"><small>Descubra uma força</small><span class="tile-symbol">✧</span><strong>Seu jeito pode<br>abrir caminhos.</strong></div><div class="world-tile three"><small>Experimente na prática</small><span class="tile-symbol">⚑</span><strong>Uma missão.<br>Uma nova versão.</strong></div><div class="world-sticker">NÃO É SOBRE<br>TER CERTEZA.<br>É COMEÇAR.</div><div class="world-label">POSSIBILIDADES EM ÓRBITA</div><div class="world-note">você escolhe o próximo teste ↗</div></div></div><div class="manifest-strip"><strong>Para quem está descobrindo quem quer ser.</strong><span class="star">✳</span><span>Mais de um caminho possível.</span><span class="star">✳</span><span>A escolha continua sendo sua.</span></div><section class="home-section" id="how"><div class="section-line"><div><div class="tiny" style="margin-bottom:10px">UM MAPA. NÃO UM DESTINO FECHADO.</div><h2>O futuro fica mais claro<br>quando você experimenta.</h2></div><span class="micro">10 perguntas curtas · 9 caminhos<br>7 dias para experimentar</span></div><div class="grid"><article class="rumo-card"><span class="card-num">01 / OLHE PARA VOCÊ</span><div class="icon">⌕</div><h3>O que te move?</h3><p>Responda a 10 perguntas curtas sobre motivação, autonomia, criação e o que cabe na sua rotina.</p></article><article class="rumo-card"><span class="card-num">02 / ABRA POSSIBILIDADES</span><div class="icon">⌘</div><h3>Tem mais de um rumo.</h3><p>Compare nove grupos de áreas próximas, com exemplos e um primeiro experimento em cada caminho.</p></article><article class="rumo-card"><span class="card-num">03 / SAIA DA IDEIA</span><div class="icon">⚑</div><h3>Teste. Sinta. Descubra.</h3><p>Escolha uma rotina de 7 dias, registre como foi e reveja suas descobertas no Passaporte.</p></article></div><div class="curiosity-head"><h2>Qual interesse pode virar seu próximo projeto?</h2><p>Música, esporte, jogos, moda ou tecnologia: use o que você curte para criar e explorar caminhos.</p></div>${topicPicker(true)}</section><section class="manifesto"><div><div class="tiny">UM CONVITE PARA A NOSSA GERAÇÃO</div><h2>Ninguém constrói<br>o futuro sozinho.</h2><p>Traga um amigo, troquem ideias e criem um primeiro projeto. Aqui, cada descoberta importa. E cada pessoa continua livre para encontrar seu próprio rumo.</p><button class="rumo-btn" data-act="duo">Começar em dupla ↗</button></div><div class="manifesto-art" aria-hidden="true">↗↗<small>FUTURO NO PLURAL.</small></div></section><div class="home-faq"><div><h3>“E se eu ainda não souber nada?”</h3><p>Esse também é um começo. Você pode responder “não sei”, mudar de ideia e experimentar uma área sem assumir um compromisso.</p></div><div><h3>“O Rumo decide minha profissão?”</h3><p>A escolha é sua. As sugestões usam suas respostas para propor experiências. Esta é uma ferramenta de exploração, não uma avaliação psicológica.</p></div></div></section>`}


const interestNames={0:'Tecnologia e IA',2:'Criação e conteúdo',3:'Esporte e movimento',1:'Negócios e ideias'};
function resumeQuestions(){const missing=answers.findIndex(x=>x===null);step=missing>=0?missing:0;navigate('question')}
function beginDemonstration(destination){
 if(!passportDemo)demoSnapshot={answers:answers.slice(),routineState:JSON.parse(JSON.stringify(routineState)),activeRoute,step,view,interestFocus,routeChosen,catalogue,youth:JSON.parse(JSON.stringify(youth))};
 youth=newYouth();catalogue=false;routeChosen=true;passportDemo=true;answers=[0,2,3,0,1,0,3,1,1,0];step=0;interestFocus='Criação e conteúdo';
 routineState=freshRoutes();activeRoute='creative';
 routineState.creative.days.slice(0,7).forEach((d,i)=>{d.mood=i===2?'mixed':'liked';d.note=demoNotes[i];d.registered=true});
 navigate(destination);
}
function endDemonstration(){
 if(demoSnapshot){youth=demoSnapshot.youth||newYouth();routeChosen=!!demoSnapshot.routeChosen;catalogue=!!demoSnapshot.catalogue;answers=demoSnapshot.answers;routineState=demoSnapshot.routineState;activeRoute=demoSnapshot.activeRoute;step=demoSnapshot.step;interestFocus=demoSnapshot.interestFocus;const previousView=demoSnapshot.view;passportDemo=false;demoSnapshot=null;navigate(previousView)}
 else{passportDemo=false;navigate('home')}
}
function duoView(){return `<span class="rp-overline">Uma ideia, dois pontos de vista</span><h1>Experimente um projeto com um amigo.</h1><p>Cada um pode descobrir interesses diferentes na mesma experiência.</p><ol class="rp-duo-list"><li>Cada pessoa responde ao próprio questionário.</li><li>Escolham um problema ou projeto pequeno que desperte curiosidade nos dois.</li><li>Dividam tarefas e usem as sugestões dos primeiros 7 dias como ponto de partida.</li><li>Cada um registra o que gostou, o que travou e o que gostaria de repetir.</li></ol><p>Esta prévia não conecta contas nem envia convites. A troca acontece entre vocês.</p><div class="rp-actions"><button class="rp-button" data-act="question">Começar pelo meu questionário →</button><button class="rp-button rp-secondary" data-act="routines">Conhecer as rotinas</button></div>`}
function privacyView(){return `<span class="rp-overline">Seus registros são seus</span><h1>Você escolhe o que compartilhar.</h1><p>Suas respostas, registros, criações, comparações, missões em dupla e próximos passos ficam salvos neste navegador, neste dispositivo. Não há sincronização com outros aparelhos. Limpar os dados do navegador ou usar navegação anônima pode apagar o progresso.</p><p>Não há cadastro, envio das respostas para um servidor ou cobrança real neste app. O botão de continuação apenas simula o acesso aos dias 8 a 14.</p><p>O mapa usa regras de exploração. Ele não mede talento, não é avaliação psicológica e não garante emprego ou renda.</p><p>“Recomeçar jornada” limpa as respostas, registros, feedback e o acesso simulado desta prévia após sua confirmação.</p><div class="rp-actions"><button class="rp-button rp-secondary" data-act="home">Voltar ao início</button><button class="rp-button rp-quiet" data-act="restart">Recomeçar jornada</button></div>`}

function refreshDrawer(){
 const current=({home:'home',today:'home',landing:'home',question:'question',overview:'overview',results:'results',routines:'routines',routine:'routines',passport:'passport',purchase:'passport',privacy:'privacy',duo:'home',reset:'restart'})[view];
 navigation.querySelectorAll('.rp-drawer-item').forEach(button=>{
  const active=button.dataset.yNav?button.dataset.yNav===view:!!current&&button.dataset.act===current;
  button.classList.toggle('rp-current',active);
  if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');
 });
 if(globalThis.lucide&&typeof globalThis.lucide.createIcons==='function')globalThis.lucide.createIcons({attrs:{width:23,height:23}});
}
function renderCore(){updateAchievements();root.dataset.screen=view;stage.innerHTML=view==='projects'?projectsView():view==='creations'?creationsView():view==='compare'?compareView():view==='next'?nextView():view==='achievements'?achievementsView():view==='home'?homeView():view==='today'?todayView():view==='landing'?landingView():view==='duo'?duoView():view==='privacy'?privacyView():view==='question'?questionView():view==='overview'?overviewView():view==='results'?resultView():view==='routines'?routinesView():view==='routine'?routineView():view==='passport'?passportView():view==='purchase'?purchasePreview():resetView();if(passportDemo)stage.innerHTML='<div class="rp-demo-banner"><span>Demonstração · respostas e registros de exemplo. Sua jornada fica preservada.</span><button class="rp-link" data-act="clear-demo">Sair da demonstração</button></div>'+stage.innerHTML;root.querySelector('#rp-nav-result').disabled=!complete();refreshDrawer();refreshNextAvailability();if(hostingReady)scheduleHostedSave()}
function navigate(next){if(next==='next'&&!canAccessNext()){live.textContent=nextLockedMessage();return}closeMenu();view=next;render();window.scrollTo({top:0,behavior:'instant'});live.textContent=next==='home'?'Página inicial do Rumo':next==='duo'?'Como criar um projeto em dupla':next==='privacy'?'Privacidade desta prévia':next==='question'?'Pergunta '+(step+1)+' de 10':next==='results'?'Seu mapa de rotas está disponível':next==='overview'?'Todas as perguntas da proposta':next==='routine'?'Rotina e plano de '+routes[activeRoute].title:next==='routines'?'Rotinas para explorar os nove caminhos':next==='passport'?'Passaporte e feedback da primeira semana':next==='purchase'?'Prévia da continuação do Passaporte, sem cobrança real':'Confirmar reinício'}
root.addEventListener('click',event=>{const b=event.target.closest('button');if(!b||!root.contains(b))return;if(['results','question','next','start','example','demo-passport'].includes(b.dataset.act))catalogue=false;if(b.dataset.curiosity!==undefined){interestFocus=interestNames[b.dataset.curiosity]||null;resumeQuestions();return}if(b.dataset.feedbackField!==undefined){const f=routineState[activeRoute].feedback,field=b.dataset.feedbackField,value=b.dataset.feedbackValue;if((field==='feeling'&&Object.hasOwn(feedbackFeeling,value))||(field==='next'&&Object.hasOwn(feedbackNext,value))){f[field]=value;f.saved=false;render()}return}if(b.dataset.moodChoice!==undefined){selectRoutineMood(Number(b.dataset.moodChoice),b.dataset.moodValue);return}if(b.dataset.route!==undefined){openRoutine(b.dataset.route);return}if(b.dataset.registerDay!==undefined){registerRoutineDay(Number(b.dataset.registerDay));return}if(b.dataset.option!==undefined){const n=Number(b.dataset.option);answers[step]=n;render();root.querySelector('[data-option="'+n+'"]')?.focus({preventScroll:true});return}if(b.dataset.jump!==undefined){step=Number(b.dataset.jump);navigate('question');return}switch(b.dataset.act){case'routines':navigate('routines');break;case'extend':if(passportUnlocked())navigate('passport');break;
case'passport':navigate('passport');break;
case'save-feedback':{const f=routineState[activeRoute].feedback;if(!passportUnlocked()||!f.feeling||!f.next)break;f.saved=true;render();live.textContent='Feedback registrado no Passaporte desta prévia.';break;}
case'review-passport':if(passportUnlocked()&&routineState[activeRoute].feedback.saved)navigate('purchase');break;
case'simulate-passport':{const rs=routineState[activeRoute];if(!passportUnlocked()||!rs.feedback.saved)break;rs.passAccess=true;rs.extended=true;rs.openDay=7;navigate('routine');live.textContent='Acesso simulado. Nenhuma cobrança foi feita. Dias 8 a 14 disponíveis.';break;}
case'continue-plan':if(routineState[activeRoute].passAccess){routineState[activeRoute].openDay=7;navigate('routine')}break;
case'clear-demo':endDemonstration();break;
case'home':navigate('home');break;case'start':if(complete())navigate('results');else resumeQuestions();break;case'how':navigate('landing');root.querySelector('#how')?.scrollIntoView({behavior:'smooth',block:'start'});break;case'example':beginYouthDemo();break;case'demo-passport':beginDemonstration('passport');break;case'duo':navigate('duo');break;case'privacy':navigate('privacy');break;case'close-menu':closeMenu();break;case'menu':if(menuOpen)closeMenu();else openMenu();break;case'overview':navigate('overview');break;case'question':{const missing=answers.findIndex(x=>x===null);step=missing>=0?missing:0;navigate('question');break;}case'results':if(complete())navigate('results');break;case'back':if(step>0){step--;navigate('question')}break;case'next':if(answers[step]===null)break;if(step===questions.length-1)navigate('results');else{step++;navigate('question')}break;case'restart':previous=view;navigate('reset');break;case'cancel-reset':navigate(previous);break;case'confirm-reset':youth=newYouth();routeChosen=false;catalogue=false;passportDemo=false;demoSnapshot=null;interestFocus=null;routineState=freshRoutes();activeRoute='creative';answers=Array(questions.length).fill(null);step=0;navigate('question');break;}});
root.addEventListener('keydown',event=>{
 if(!menuOpen)return;
 if(event.key==='Escape'){event.preventDefault();closeMenu();return}
 if(event.key!=='Tab')return;
 const controls=Array.from(navigation.querySelectorAll('button:not([disabled]),a[href]'));
 if(!controls.length)return;
 const first=controls[0],last=controls[controls.length-1];
 if(event.shiftKey&&event.target===first){event.preventDefault();last.focus()}
 else if(!event.shiftKey&&event.target===last){event.preventDefault();first.focus()}
});
root.addEventListener('click',event=>{if(menuOpen&&!event.target.closest('.rp-menu')&&!event.target.closest('[data-act="menu"]'))closeMenu()});

root.addEventListener('keydown',event=>{
 const option=event.target.closest('.rp-dropdown-option');
 const picker=event.target.closest('.rp-select-menu');
 if(!picker||!picker.open)return;
 if(event.key==='Escape'){event.preventDefault();picker.open=false;picker.querySelector('summary').focus();return}
 if(!option)return;
 const options=Array.from(picker.querySelectorAll('.rp-dropdown-option'));
 const idx=options.indexOf(option);let next=idx;
 if(event.key==='ArrowDown')next=(idx+1)%options.length;
 else if(event.key==='ArrowUp')next=(idx+options.length-1)%options.length;
 else if(event.key==='Home')next=0;
 else if(event.key==='End')next=options.length-1;
 else return;
 event.preventDefault();options[next].focus();
});

let todayIndex=0,helpOpen=false,helpChoice='',smallTask=false;
const dailyExtras={
 creative:{steps:['Escolha uma única ideia para o seu projeto.','Faça um rascunho com começo, meio e fim.','Guarde essa versão. Revisar fica para outro dia.'],start:'Abra as notas do celular e escreva uma frase sobre o que você quer criar. Essa frase já é o começo do rascunho.',example:'Se o seu projeto for um vídeo: escreva uma abertura, uma ideia principal e um encerramento. Pode ficar só no texto hoje.',small:'Escreva três frases ou faça um esboço rápido. Salve como rascunho. Você pode continuar depois.'},
 team:{steps:['Leia a tarefa e escolha uma parte para começar.','Experimente com as referências que você encontrou.','Anote uma dúvida para conversar com alguém depois.'],start:'Escreva o que você já entendeu da tarefa e escolha uma única parte para tentar primeiro.',example:'Se estiver conhecendo atendimento, imagine uma dúvida comum de um cliente e escreva uma resposta simples.',small:'Escolha uma parte pequena da tarefa, tente por cinco minutos e anote onde precisou de ajuda.'},
 enterprise:{steps:['Escolha uma pessoa ou problema que quer entender.','Faça um primeiro teste simples, sem gastar dinheiro.','Anote o que aprendeu e o que ainda precisa descobrir.'],start:'Escreva uma frase sobre o problema que quer entender. Depois pense em alguém conhecido que já passou por isso.',example:'Se a ideia for organizar estudos, pergunte a alguém o que mais atrapalha sua rotina. Escute antes de oferecer uma solução.',small:'Escreva uma pergunta sobre o problema que você quer entender. O próximo passo pode ficar para depois.'}
};
function nextDailyIndex(){const rs=routineState[activeRoute],limit=rs.extended?14:7;return rs.days.findIndex((d,i)=>i<limit&&!d.registered)}
function journeyHome(){
 const rs=routineState[activeRoute],next=nextDailyIndex(),count=routineCount(activeRoute,7),r=routes[activeRoute],task=next<0?null:getPlan(activeRoute).days[next];
 return `<section class="rd-shell"><div class="rd-intro"><div><span class="rp-overline">Sua jornada continua</span><h1>Um pequeno passo.<br><em>Mais perto do seu rumo.</em></h1><p>Você não precisa decidir tudo hoje. Só experimentar o próximo passo.</p></div><span class="rd-free">Versão gratuita</span></div><div class="rd-grid"><article class="rd-mission"><div class="rd-eyebrow"><i data-lucide="navigation" aria-hidden="true"></i> Seu passo de hoje</div><div class="rd-metadata"><span>${next<0?'Semana registrada':'Dia '+(next+1)}</span><span>${routineTiming().total} minutos sugeridos</span><span>${esc(r.short)}</span></div><h2>${task?esc(task[0]):'Pare um pouco. Veja o que descobriu.'}</h2><p>${task?esc(task[1]):'Você registrou todos os dias deste plano. Abra o Passaporte para rever suas experiências e escolher como seguir.'}</p><button class="rp-button" ${task?'data-daily="start"':'data-act="passport"'}>${task?'Começar meu passo':'Abrir meu Passaporte'} <span aria-hidden="true">↗</span></button>${task?'<button class="rd-help-button" data-daily="help"><i data-lucide="life-buoy" aria-hidden="true"></i> Travei, preciso de ajuda <span aria-hidden="true">→</span></button>':''}</article><aside class="rd-week"><span class="rp-overline">Sua primeira semana</span><h2>Seu ritmo também conta.</h2><p>Não precisa fazer em dias seguidos.</p><div class="rd-days" aria-label="Dias registrados">${rs.days.slice(0,7).map((d,i)=>`<span class="${d.registered?'rd-done':i===next?'rd-next':''}"><small>D${i+1}</small><b aria-label="Dia ${i+1}: ${d.registered?'registrado':'pendente'}">${d.registered?'✓':i+1}</b></span>`).join('')}</div><div class="rd-count">${count} de 7 dias registrados</div><button class="rp-link" data-route="${activeRoute}">Ver meu plano completo →</button>${count?`<div class="rd-note"><small>Do seu último registro</small><p>“${esc(rs.days.slice(0,7).filter(d=>d.registered).at(-1).note||moodLabels[rs.days.slice(0,7).filter(d=>d.registered).at(-1).mood])}”</p></div>`:''}</aside></div><div class="rd-bottom"><div><small>CAMINHO EM EXPLORAÇÃO</small><strong>${r.title}</strong></div><div class="rd-shortcuts"><button class="rp-link" data-act="results">Rever meu mapa ↗</button><button class="rp-link" data-act="passport">Meu Passaporte ↗</button></div></div>${youthDashboard()}</section>`;
}
function dailyHelp(){const h=dailyExtras[activeRoute];return `<section class="rd-assist" aria-label="Ajuda para a tarefa"><div class="rd-assist-head"><h2>Vamos destravar esse começo.</h2><button data-daily="close-help" aria-label="Fechar ajuda">×</button></div><p>O que está dificultando hoje?</p><div class="rd-help-choices">${[['start','Não sei por onde começar'],['small','Tenho pouco tempo'],['example','Quero um exemplo']].map(([v,t])=>`<button data-help-choice="${v}" aria-pressed="${helpChoice===v}">${t}</button>`).join('')}</div>${helpChoice?`<div class="rd-answer" role="status"><strong>${({start:'Comece por uma coisa só.',small:'Hoje pode caber em 5 minutos.',example:'Um exemplo para sair do zero.'})[helpChoice]}</strong><p>${h[helpChoice]}</p>${helpChoice==='small'?`<button class="rp-button rp-secondary" data-daily="small">${smallTask?'Versão de 5 minutos ativada ✓':'Usar essa versão menor →'}</button>`:''}</div>`:'<p>Escolha uma opção para ver uma sugestão prática.</p>'}</section>`}
function todayCoreView(){
 const rs=routineState[activeRoute],i=todayIndex,d=rs.days[i],task=getPlan(activeRoute).days[i],special=i===2,h=dailyExtras[activeRoute];
 return `<section class="rd-workspace"><button class="rp-home-back" data-act="home"><span aria-hidden="true">←</span> Voltar para minha jornada</button><span class="rp-overline">Dia ${i+1} · ${routes[activeRoute].title}</span><h1>${esc(task[0])}.</h1><p>${esc(task[1])}</p><div class="rd-mission"><div class="rd-eyebrow"><i data-lucide="flag" aria-hidden="true"></i> ${smallTask?'Uma versão menor para hoje':'Uma coisa de cada vez'}</div><div class="rd-metadata"><span>${smallTask?'5':routineTiming().total} minutos sugeridos</span><span>${smallTask?'Você ajustou o tamanho da tarefa':'No seu ritmo'}</span></div>${i<7?`<p>Faça o teste descrito acima, no tamanho que cabe hoje. Depois registre o que percebeu.</p>`:smallTask?`<p>${h.small}</p>`:special?`<ol class="rd-steps">${h.steps.map(t=>`<li>${t}</li>`).join('')}</ol>`:'<p>Leia a proposta, faça uma tentativa pequena e registre como foi. Você pode adaptar o projeto ao que tem disponível.</p>'}<button class="rd-help-button" data-daily="toggle-help" aria-expanded="${helpOpen}"><i data-lucide="life-buoy" aria-hidden="true"></i> Travei, preciso de ajuda <span aria-hidden="true">${helpOpen?'−':'+'}</span></button></div>${helpOpen?dailyHelp():''}${d.registered?`<div class="rd-success" role="status"><strong>Mais uma experiência registrada ✓</strong><p>Você pode voltar depois. O próximo passo já está na sua jornada.</p><div class="ry-record-actions"><button class="rp-link" data-y-action="new-creation">Guardar algo que criei ↗</button><button class="rp-link" data-y-nav="achievements">Minhas conquistas →</button></div><button class="rp-button" data-act="home">Voltar para minha jornada →</button></div>`:`<section class="rd-record"><h2>Como foi a tarefa de hoje para você?</h2><p>Mesmo se não conseguiu fazer, vale registrar.</p><details class="rp-select-menu"><summary id="rp-mood-${activeRoute}-${i}"><span>${d.mood?moodLabels[d.mood]:'Escolha uma opção'}</span><span aria-hidden="true">⌄</span></summary><fieldset class="rp-dropdown-options"><legend class="rp-dropdown-legend">Como foi este dia?</legend>${Object.entries(moodLabels).map(([v,t])=>`<button class="rp-dropdown-option" data-mood-choice="${i}" data-mood-value="${v}" aria-pressed="${d.mood===v}">${t}</button>`).join('')}</fieldset></details><label for="rp-note-${activeRoute}-${i}">${d.mood==='other'?'Escreva sua resposta':'O que você percebeu? (opcional)'}</label><textarea id="rp-note-${activeRoute}-${i}" data-day-note="${i}" maxlength="2000" aria-required="${d.mood==='other'}" placeholder="Uma frase já ajuda…">${esc(d.note)}</textarea><div class="rp-actions"><button class="rp-button" data-register-day="${i}" ${!d.mood||(d.mood==='other'&&!d.note.trim())?'disabled':''}>Registrar meu dia ✓</button></div></section>`}</section>`;
}
function homeView(){return complete()?(routeChosen?journeyHome():resultView()):landingView()}
function openToday(needsHelp=false){const i=nextDailyIndex();if(i<0){navigate('passport');return}todayIndex=i;helpOpen=needsHelp;helpChoice='';smallTask=false;navigate('today')}
root.addEventListener('click',event=>{
 const b=event.target.closest('button');if(!b||!root.contains(b))return;
 if(b.dataset.helpChoice!==undefined){if(['start','small','example'].includes(b.dataset.helpChoice)){helpChoice=b.dataset.helpChoice;render()}return}
 switch(b.dataset.daily){case'demo':beginYouthDemo();break;case'start':openToday();break;case'help':openToday(true);break;case'toggle-help':helpOpen=!helpOpen;render();break;case'close-help':helpOpen=false;render();break;case'small':smallTask=true;render();live.textContent='Tarefa ajustada para uma versão de cinco minutos.';break;}
});
function beginDailyDemo(){
 beginDemonstration('home');
 routineState.creative.days.slice(2).forEach(d=>{d.registered=false;d.mood='';d.note=''});
 routineState.creative.days[0].note='Escolhi um projeto de vídeo curto.';
 routineState.creative.days[1].note='As referências me ajudaram a organizar a ideia.';
 routineState.creative.openDay=2;
 render();
}

// Two extra alternatives per question. Context choices never affect route order.
const extraOptions=[
 [O('Investigar como algo funciona e testar uma solução.',{research:3},'Interesse em investigar e testar soluções.'),O('Usar uma habilidade para resolver um pedido de alguém.',{freelance:3},'Interesse em transformar uma habilidade em uma entrega para alguém.')],
 [O('Não ter tempo para entender o problema a fundo.',{research:2},'Necessidade de aprofundar um problema antes de concluir.'),O('Receber pedidos sem combinar prazo e limites.',{freelance:1},'Importância de combinar o que será entregue e em qual prazo.')],
 [O('Divido a entrega em etapas e combino o prazo.',{freelance:2,team:1},'Preferência por organizar uma entrega e combinar prazos.'),O('Pergunto a quem vai usar o resultado o que mais precisa.',{social:2,enterprise:1},'Interesse em ouvir quem será afetado pelo resultado.')],
 [O('Investigar as causas e testar se a solução funciona.',{research:3},'Vontade de investigar causas e testar uma solução.'),O('Explicar a ideia e ajudar alguém a aprender com ela.',{social:3},'Interesse em explicar e apoiar a aprendizagem de alguém.')],
 [O('Comparo as versões para entender qual mudança ajuda.',{research:2},'Preferência por comparar versões antes de mudar.'),O('Revejo o combinado antes de aceitar um pedido maior.',{freelance:2},'Atenção ao limite de um pedido e ao trabalho envolvido.')],
 [O('Ter um plano para entregar pequenos serviços.',{freelance:2},'Interesse em organizar pequenas entregas de serviço.'),O('Perceber que alguém aprendeu ou foi ajudado.',{social:2},'Importância de perceber um efeito positivo para alguém.')],
 [O('Comparo o que aconteceu com o resultado que esperava.',{research:2},'Vontade de comparar a expectativa com o resultado observado.'),O('Escuto a dificuldade da pessoa antes de explicar de novo.',{social:2},'Disposição para ouvir e adaptar uma explicação.')],
 [O('Ser procurado por um serviço que sei fazer bem.',{freelance:3},'Interesse em ser reconhecido por uma entrega de serviço.'),O('Descobrir uma solução e conseguir mostrar que funciona.',{research:3},'Satisfação em investigar e demonstrar uma solução.')],
 [O('Consigo separar só uns 10 minutos por dia.'),O('Preciso de algo que dê para testar só com o celular.')],
 [O('Investigar uma dúvida e comparar duas soluções.'),O('Ensinar algo que sei ou ajudar numa ação da comunidade.')]
];
const originalCounts=questions.map(q=>q.options.length);
extraOptions.forEach((options,i)=>questions[i].options.push(...options));
questions[0].options[3].signals.social=2;
questions[2].options[2].signals.research=2;
questions[3].options[1].signals.social=1;
questions[8].title='O que mais limita você a testar uma ideia agora?';
questions[8].hint='Pense no dinheiro, no tempo e nos recursos que você tem hoje. Escolha o limite que mais pesa agora.';
Object.assign(routes,{
 freelance:{title:'Serviços por conta própria',short:'serviços',desc:'Experimentar uma habilidade como uma entrega com pedido, prazo e limites combinados.',watch:'Ainda vale descobrir como você lida com prazos, negociação e organização. Gostar de autonomia não prova preparo para viver de serviços.',test:'Simule um pedido pequeno de alguém conhecido. Combine a entrega e o prazo, faça uma amostra e peça opinião. Não precisa cobrar ou assumir um cliente.',combination:'Um serviço pode ser criativo, técnico ou educativo, e pode ser testado em paralelo a um emprego.'},
 research:{title:'Pesquisa e soluções técnicas',short:'pesquisa',desc:'Explorar perguntas, analisar informações e experimentar como resolver um problema.',watch:'Vale descobrir se você gosta também de estudar o assunto, testar de novo e documentar erros, além de ter a ideia.',test:'Escolha uma dúvida pequena. Compare duas fontes ou duas soluções simples e registre o que conseguiu observar.',combination:'Investigar e desenvolver soluções pode acontecer numa empresa, num projeto próprio ou numa instituição de ensino.'},
 social:{title:'Educação e impacto social',short:'educação e impacto',desc:'Explorar explicação, escuta e ações que ajudam pessoas a aprender ou resolver uma dificuldade.',watch:'Vale observar como é ouvir necessidades diferentes, preparar uma explicação e respeitar seus próprios limites de tempo e responsabilidade.',test:'Escolha um assunto simples que você conhece. Prepare uma explicação curta e pergunte a alguém conhecido se ficou clara.',combination:'Educação e impacto podem fazer parte de um emprego, um serviço ou um projeto social. Esta rota não exige trabalhar sem receber.'}
});
const routeKinds={team:'Forma de trabalhar',enterprise:'Forma de trabalhar',freelance:'Forma de trabalhar',creative:'Área de interesse',research:'Área de interesse',social:'Área de interesse'};
const routeExamples={team:'Ex.: atendimento, operações, apoio administrativo.',enterprise:'Ex.: uma solução, produto ou pequeno negócio.',creative:'Ex.: texto, música, vídeo, design.',freelance:'Ex.: edição, fotografia, organização de conteúdo.',research:'Ex.: tecnologia, programação, análise, ciência.',social:'Ex.: educação, comunicação educativa, projetos comunitários.'};
Object.assign(routinePlans,{
 freelance:{intro:'Teste uma entrega pequena com prazo e limites claros, sem depender de renda com ela.',focus:'Um serviço simulado, do pedido ao retorno.',days:[
 ['Escolha uma habilidade','Escolha algo que você já consegue tentar: editar um vídeo, organizar informações ou escrever um texto. Defina uma entrega pequena.'],
 ['Entenda um pedido','Imagine um pedido de alguém conhecido. Anote o resultado esperado, o prazo e o que fica fora da entrega.'],
 ['Faça uma amostra','Crie uma primeira amostra simples. Use materiais seus ou autorizados e não prometa uma entrega profissional.'],
 ['Organize o trabalho','Divida a amostra em três etapas e estime o tempo. Compare a estimativa com a tentativa.'],
 ['Conclua a entrega','Termine uma versão pequena dentro dos limites que definiu. Anote o que levou mais tempo.'],
 ['Peça um retorno','Se quiser, mostre a alguém conhecido e pergunte se o pedido ficou claro no resultado. Também pode revisar sozinho.'],
 ['Reveja a experiência','Compare executar, organizar e lidar com um pedido. Registre o que repetiria e o que mudaria.'],
 ['Ajuste o serviço','Escolha um ponto da primeira entrega que você gostaria de melhorar.'],
 ['Escreva um combinado','Descreva uma entrega fictícia com prazo e uma rodada de revisão. Não ofereça nem cobre por ela neste teste.'],
 ['Faça outra amostra','Produza uma versão curta usando o novo combinado.'],
 ['Pratique uma revisão','Imagine uma alteração pequena e observe quanto tempo ela acrescenta.'],
 ['Observe o esforço','Anote tempo, materiais e dificuldades. Não confunda interesse com garantia de renda.'],
 ['Organize os exemplos','Guarde as amostras numa pasta privada com uma descrição do que fez.'],
 ['Escolha como seguir','Decida entre aprender uma técnica, repetir uma entrega ou comparar outra rota.']
 ]},
 research:{intro:'Explore uma dúvida com observação, estudo e testes pequenos.',focus:'Uma pergunta investigável e um registro do que você encontrou.',days:[
 ['Escolha uma dúvida','Escreva uma pergunta simples sobre algo que você quer entender, como uma função de um aplicativo ou uma rotina de estudo.'],
 ['Busque referências','Consulte duas fontes confiáveis sobre a dúvida. Separe o que foi explicado do que você ainda não entendeu.'],
 ['Teste uma hipótese','Escolha uma ideia que possa verificar sem risco e sem compras. Registre o que esperava e o que observou.'],
 ['Compare duas alternativas','Mude um detalhe simples e compare os resultados. Uma diferença não prova sozinha a causa.'],
 ['Organize os achados','Resuma a pergunta, as tentativas e os limites do que conseguiu observar.'],
 ['Peça outra leitura','Mostre o resumo a alguém conhecido ou releia procurando uma explicação alternativa.'],
 ['Reveja seu processo','Compare pesquisar, testar e registrar. Anote em qual etapa teve mais interesse e onde precisou de ajuda.'],
 ['Aprofunde uma dúvida','Escolha uma pergunta que surgiu no primeiro teste.'],
 ['Estude um conceito','Leia uma introdução gratuita e anote um conceito que pode usar.'],
 ['Planeje outro teste','Defina o que vai observar e o que pode interferir.'],
 ['Experimente novamente','Faça um teste simples, seguro e sem dados pessoais de outras pessoas.'],
 ['Compare sem forçar','Anote semelhanças, diferenças e o que ainda não é possível concluir.'],
 ['Explique o processo','Faça um pequeno texto sobre o que tentou e as limitações.'],
 ['Escolha o próximo tema','Decida entre aprofundar o tema, conhecer uma função técnica ou comparar outra rota.']
 ]},
 social:{intro:'Experimente escutar, preparar uma explicação e perceber se ela ajuda.',focus:'Uma explicação curta ou uma contribuição pequena para alguém conhecido.',days:[
 ['Escolha uma contribuição','Escolha um assunto simples que sabe explicar ou uma ação pequena que pode ajudar alguém. Não assuma orientação médica ou psicológica.'],
 ['Ouça uma necessidade','Pergunte a alguém conhecido o que seria útil entender nesse assunto. Escute antes de preparar sua resposta.'],
 ['Prepare uma explicação','Escreva uma explicação curta com um exemplo. Você pode ensaiar sozinho antes de mostrar.'],
 ['Adapte a linguagem','Troque um termo difícil por uma frase simples. Teste se o exemplo ajuda.'],
 ['Experimente a contribuição','Se a pessoa quiser, compartilhe sua explicação ou faça a pequena ação que combinaram. Respeite o tempo dos dois.'],
 ['Peça um retorno','Pergunte o que ficou claro e o que ainda precisa de outra explicação. Também pode revisar por conta própria.'],
 ['Observe seus limites','Compare ouvir, preparar e explicar. Anote o que te deu energia e que limites precisa preservar.'],
 ['Escolha um ajuste','Defina uma melhoria a partir do retorno que recebeu.'],
 ['Estude uma referência','Consulte um material confiável e gratuito sobre o assunto que está explicando.'],
 ['Prepare outro exemplo','Crie uma segunda explicação curta com outro exemplo.'],
 ['Teste outro formato','Compare texto, áudio ou imagem, sem divulgar dados da pessoa.'],
 ['Observe a compreensão','Convide a pessoa, se ela quiser, a dizer com suas palavras o que entendeu.'],
 ['Guarde o aprendizado','Registre o que ajudou e o que você precisa estudar mais.'],
 ['Escolha como continuar','Decida entre aprofundar o assunto, conhecer uma função educativa ou comparar outra rota.']
 ]}
});
function freshRoutes(){return Object.fromEntries(Object.keys(routes).map(k=>[k,newRoutine()]))}
routineState=freshRoutes();
Object.assign(dailyExtras,{
 freelance:{steps:['Releia o pedido que definiu.','Faça uma amostra pequena.','Guarde o arquivo e anote uma dúvida.'],start:'Escolha uma parte do pedido que você já consegue tentar.',example:'Para um texto curto: escreva um título e três linhas antes de pensar na formatação.',small:'Faça só uma amostra de uma parte da entrega e guarde para continuar depois.'},
 research:{steps:['Escreva o que espera observar.','Faça um teste simples e seguro.','Anote o resultado e uma limitação.'],start:'Transforme a dúvida numa pergunta que você consegue observar hoje.',example:'Compare dois modos de organizar suas próprias anotações. Observe o processo, sem tirar conclusões gerais.',small:'Anote a pergunta e uma forma segura de verificar uma parte dela.'},
 social:{steps:['Escolha uma ideia para explicar.','Escreva um exemplo próximo da realidade da pessoa.','Releia em voz alta e simplifique uma frase.'],start:'Escreva uma frase sobre o que a pessoa gostaria de entender.',example:'Para explicar uma regra de um jogo: descreva um lance simples e mostre como a regra se aplica.',small:'Prepare uma única frase com um exemplo. Você pode compartilhar outro dia.'}
});
chosenTests.push('Investigar uma dúvida, comparar alternativas e registrar as limitações.','Preparar uma explicação curta ou uma contribuição para alguém conhecido.');
let catalogue=false;
function expandedResult(){
 const personal=complete()&&!catalogue,p=getProfile(),keys=personal?p.ranked:Object.keys(routes);
 if(!complete()&&!catalogue)return `<h1>Seu mapa começa pelas suas respostas.</h1><p>Responda às perguntas para comparar os sinais, ou conheça os nove caminhos como exemplos.</p><div class="rp-actions"><button class="rp-button" data-act="question">Responder às perguntas →</button><button class="rp-button rp-secondary" data-expanded="catalogue">Conhecer os 9 caminhos</button></div>`;
 return `<span class="rp-overline">${personal?'Seu mapa ampliado':'Conheça as possibilidades'}</span><h1>${personal?p.clear?routes[p.top].title:'Mais espaço para descobrir seu rumo.':'Nove caminhos. Várias combinações.'}</h1><p>${personal?'As respostas sobre interesses aproximam caminhos; as demais ajudam a adaptar a experiência ao seu jeito. Os caminhos continuam abertos: esta proposta não mede aptidão nem prevê sucesso.':'Estes são exemplos dos caminhos que poderão aparecer no mapa. A ordem abaixo não é um resultado pessoal.'}</p><div class="rx-combine"><i data-lucide="git-merge" aria-hidden="true"></i><p>As áreas podem se combinar. Você pode buscar emprego, prestar serviços ou empreender em diferentes grupos. O mapa sugere experiências; a escolha continua sendo sua.</p></div><div class="rp-route-grid">${keys.map((k,index)=>{const r=routes[k],ev=p.evidence[k];return `<article class="rp-route ${personal&&p.clear&&index===0?'rp-highlight':''}"><span class="rp-tag">${personal&&p.clear&&index===0?'Primeiro caminho para experimentar':routeKinds[k]}</span><h2>${r.title}</h2><p>${r.desc}</p><span class="rx-examples">${routeExamples[k]}</span>${personal?`<span class="rp-label">Pistas nas suas respostas</span>${ev.length?`<ul class="rp-evidence">${ev.slice(0,2).map(e=>`<li>${esc(e.text)}</li>`).join('')}</ul>`:'<p>Ainda não há uma resposta sua apoiando este caminho. Ele segue disponível para explorar.</p>'}`:''}<span class="rp-label">Um primeiro experimento</span><p>${r.test}</p><details class="rx-watch"><summary>O que ainda vale descobrir</summary><p>${r.watch}</p></details><div class="rp-route-bottom"><button class="rp-button rp-secondary" data-up-route="${k}">Conhecer esse caminho ↗</button><button class="rp-button rp-secondary" data-route="${k}">Ver rotina e plano →</button></div></article>`}).join('')}</div>${personal?`${workPreferences()}<div class="rp-context"><h2>Seu momento também entra no plano.</h2><p>${contextText()}</p><span class="rp-label">O teste que você topa fazer</span><p>${chosenTests[answers[9]]||'Você ainda não escolheu um teste. Pode começar por uma tarefa de um dos cartões.'}</p><p>As duas últimas respostas ajustam o primeiro passo. Elas não aumentam nem diminuem suas possibilidades.</p></div>`:''}<details class="rp-transparency"><summary>Como este mapa funciona?</summary><p>As perguntas sobre atividades, tarefas e conquistas dão pistas de interesse nas áreas. As demais mostram preferências de apoio, organização e rotina para adaptar o plano. Com poucas pistas ou sinais próximos, nenhum caminho é declarado vencedor. A pontuação é uma hipótese desta proposta, sem validação psicológica.</p><p>Emprego, trabalho autônomo e empreendedorismo são formas de atuar que podem atravessar os nove grupos. As alternativas amplas podem apoiar mais de uma área, então o mapa não força uma profissão.</p></details><div class="rp-actions"><button class="rp-button" data-act="question">${complete()?'Rever minhas respostas':'Descobrir meu mapa'} →</button><button class="rp-link" data-act="overview">Ver todas as perguntas</button></div>`;
}
root.addEventListener('click',event=>{
 const b=event.target.closest('button');if(!b||!root.contains(b))return;
 if(b.dataset.expanded==='catalogue'){catalogue=true;navigate('results')}
 if(b.dataset.act==='question'||b.dataset.act==='next'||b.dataset.act==='start')catalogue=false;
});
function contextText(values=answers){if(values[8]===3)return 'Você indicou cerca de 10 minutos por dia. O plano pode começar com um bloco de 2 minutos para preparar, 6 para tentar e 2 para registrar, sem exigir dias seguidos.';if(values[8]===4)return 'Você quer começar só com o celular. Use notas, áudio ou arquivos seus nos primeiros testes; nenhuma compra é necessária para começar. Se alguma tarefa não couber nos seus recursos, adapte ou registre a dificuldade.';return baseContextText(values)}
function routineTiming(){if(answers[8]===3)return {prepare:2,practice:6,reflect:2,total:10};return baseRoutineTiming()}
function resultView(){return expandedResult()}

// Keep five distinct alternatives; a merged item uses the strongest signal,
// rather than adding duplicate weights from two similar alternatives.
const beforeReduction=questions.map(q=>q.options.slice());
function mergedAnswer(text,note,...items){
 const signals={};
 for(const item of items)for(const [k,v] of Object.entries(item.signals))signals[k]=Math.max(signals[k]||0,v);
 return O(text,signals,note);
}
const fiveAnswers=[
 [beforeReduction[0][0],
  mergedAnswer('Investigar uma dúvida e testar como resolver.','Interesse em investigar dúvidas e testar soluções.',beforeReduction[0][1],beforeReduction[0][5]),
  mergedAnswer('Tirar uma ideia do papel e fazer funcionar.','Vontade de transformar uma ideia numa solução prática.',beforeReduction[0][2],beforeReduction[0][4]),
  beforeReduction[0][3],beforeReduction[0][6]],
 [beforeReduction[1][0],
  mergedAnswer('Não ter clareza sobre o pedido, o prazo e os limites.','Importância de entender expectativas, prazos e limites de uma entrega.',beforeReduction[1][1],beforeReduction[1][6]),
  beforeReduction[1][2],beforeReduction[1][4],beforeReduction[1][5]],
 [mergedAnswer('Busco uma referência para entender antes de tentar.','Preferência por começar com uma referência e entender a tarefa.',beforeReduction[2][0],beforeReduction[2][2]),
  beforeReduction[2][1],beforeReduction[2][3],beforeReduction[2][4],beforeReduction[2][5]],
 [beforeReduction[3][0],
  mergedAnswer('Ouvir o público e convidar alguém para testar.','Interesse em ouvir necessidades e testar uma proposta com um público.',beforeReduction[3][1],beforeReduction[3][2]),
  beforeReduction[3][3],beforeReduction[3][4],beforeReduction[3][5]],
 [mergedAnswer('Entendo o pedido e adapto para resolver melhor.','Abertura para entender um pedido e adaptar a criação.',beforeReduction[4][0],beforeReduction[4][3]),
  beforeReduction[4][1],beforeReduction[4][2],beforeReduction[4][4],beforeReduction[4][5]],
 [beforeReduction[5][0],beforeReduction[5][1],
  mergedAnswer('Ver que a ideia desperta interesse ou ajuda alguém.','Importância de perceber interesse ou utilidade para outras pessoas.',beforeReduction[5][2],beforeReduction[5][5]),
  beforeReduction[5][3],beforeReduction[5][4]],
 [mergedAnswer('Comparo com o que esperava, entendo o erro e ajusto.','Vontade de comparar o resultado, entender o retorno e ajustar.',beforeReduction[6][0],beforeReduction[6][4]),
  beforeReduction[6][1],beforeReduction[6][2],beforeReduction[6][3],beforeReduction[6][5]],
 [beforeReduction[7][0],
  mergedAnswer('Ver uma criação minha sendo reconhecida e usada.','Satisfação em reconhecer sua autoria numa criação que chega a outras pessoas.',beforeReduction[7][1],beforeReduction[7][2]),
  beforeReduction[7][3],beforeReduction[7][4],beforeReduction[7][5]],
 [beforeReduction[8][0],beforeReduction[8][1],beforeReduction[8][2],beforeReduction[8][4],beforeReduction[8][5]],
 [beforeReduction[9][0],beforeReduction[9][1],beforeReduction[9][2],beforeReduction[9][4],beforeReduction[9][5]]
];
fiveAnswers.forEach((options,i)=>{questions[i].options=options});
// Uncertainty stays available through the separate optional skip link.
chosenTests.splice(3,1);

// Group related activities. Work arrangements can cross all nine groups.
Object.assign(routes.team,{title:'Gestão, comércio e administração',short:'gestão e comércio',desc:'Conhecer organização, atendimento, vendas e o funcionamento de uma equipe.',test:'Escolha uma rotina simples de uma organização: atendimento, estoque ou agenda. Entenda uma tarefa e simule uma versão pequena.'});
Object.assign(routes.enterprise,{title:'Negócios e empreendedorismo',short:'negócios',desc:'Explorar uma ideia de negócio, entender um público e testar uma solução pequena.'});
Object.assign(routes.creative,{title:'Arte, design e comunicação',short:'criação e comunicação',desc:'Explorar expressão e criação em texto, música, imagem, design ou audiovisual.'});
Object.assign(routes.research,{title:'Tecnologia, dados e pesquisa',short:'tecnologia e pesquisa',desc:'Investigar perguntas, organizar informações e experimentar soluções digitais ou científicas.'});
Object.assign(routes.freelance,{title:'Serviços técnicos e produção',short:'serviços e produção',desc:'Explorar uma entrega prática: organizar, produzir, reparar ou prestar um serviço com limites claros.',test:'Escolha uma habilidade segura que já consegue tentar. Simule um pedido pequeno, combine o que será entregue e prepare uma amostra.'});
Object.assign(routes,{
 build:{title:'Engenharia, arquitetura e construção',short:'projetos e espaços',desc:'Explorar espaços, estruturas, desenho de soluções e como uma ideia pode ser construída.',watch:'Vale descobrir como você se sente ao lidar com medidas, restrições, revisão e estudo técnico. Um desenho simples não avalia preparo profissional.',test:'Desenhe uma melhoria para um espaço conhecido. Compare duas formas de organizar o ambiente, sem obras ou mudanças estruturais.',combination:'Projetar espaços e soluções pode envolver criação, tecnologia, trabalho em equipe ou um negócio próprio.'},
 care:{title:'Saúde, esporte e bem-estar',short:'cuidado e movimento',desc:'Conhecer atividades ligadas ao cuidado, ao corpo, ao movimento e ao bem-estar das pessoas.',watch:'Vale distinguir interesse por esporte, cuidado, ciência e atendimento. O primeiro teste é de exploração e não habilita a orientar outras pessoas.',test:'Escolha uma função dessa área e pesquise como é a rotina. Resuma o que a pessoa faz, o que precisa estudar e uma dúvida sua, sem prescrever treinos ou cuidados.',combination:'Cuidado e movimento podem se aproximar de ensino, pesquisa, gestão e comunicação.'},
 nature:{title:'Natureza, meio ambiente e campo',short:'natureza e ambiente',desc:'Explorar seres vivos, recursos naturais, conservação e formas de produzir com atenção ao ambiente.',watch:'Vale descobrir se você gosta mais de observar, pesquisar, atuar no campo ou organizar soluções ambientais. As atividades podem ser bem diferentes.',test:'Observe um tema próximo: água, resíduos, vegetação ou alimentos. Registre uma pergunta e compare informações de duas fontes confiáveis.',combination:'Ambiente e campo podem se combinar com pesquisa, engenharia, educação, produção e empreendedorismo.'}
});
Object.assign(routeKinds,{team:'Organização e pessoas',enterprise:'Ideias e negócios',creative:'Expressão e criação',research:'Investigação e soluções',freelance:'Entregas práticas',social:'Aprendizagem e comunidade',build:'Espaços e estruturas',care:'Cuidado e movimento',nature:'Ambiente e seres vivos'});
Object.assign(routeExamples,{
 team:'Ex.: administração, atendimento, vendas, logística.',enterprise:'Ex.: pequeno negócio, produto ou serviço próprio.',creative:'Ex.: design, música, escrita, fotografia, audiovisual.',research:'Ex.: programação, análise de dados, investigação científica.',freelance:'Ex.: produção artesanal, organização, serviços e manutenção técnica.',social:'Ex.: ensino, projetos educativos e ações comunitárias.',
 build:'Ex.: engenharia, arquitetura, construção e planejamento de espaços.',care:'Ex.: áreas da saúde, educação física, esporte e bem-estar.',nature:'Ex.: meio ambiente, agronomia, conservação e produção rural.'
});
// Keep every question title. Only three sets of answers need new interest cues.
questions[0].options=[
 O('Criar algo com meu jeito: texto, música, imagem ou vídeo.',{creative:3},'Interesse em criar e expressar seu próprio estilo.'),
 O('Investigar tecnologia, natureza ou como algo funciona.',{research:2,nature:2},'Interesse em investigar tecnologia, natureza ou o funcionamento das coisas.'),
 O('Tirar uma ideia do papel: organizar, desenhar ou construir.',{enterprise:3,team:1,build:1},'Vontade de transformar uma ideia em organização, desenho ou construção.'),
 O('Ajudar alguém a aprender, se cuidar ou se movimentar.',{social:2,care:2},'Interesse em ajudar por meio de aprendizagem, cuidado ou movimento.'),
 O('Usar uma habilidade para fazer uma entrega prática.',{freelance:3},'Interesse em usar uma habilidade numa entrega prática.')
];
questions[3].options=[
 O('Criar e melhorar o que será apresentado.',{creative:3,freelance:1},'Interesse em criar e aperfeiçoar algo que será apresentado.'),
 O('Ouvir o público e testar uma proposta de negócio.',{enterprise:2,team:2},'Interesse em ouvir um público e testar uma proposta de negócio.'),
 O('Planejar um espaço, uma estrutura ou uma construção.',{build:3},'Interesse em planejar espaços, estruturas ou construções.'),
 O('Investigar tecnologia, recursos naturais ou o ambiente.',{research:2,nature:2},'Interesse em investigar soluções ligadas à tecnologia, aos recursos naturais ou ao ambiente.'),
 O('Preparar algo ligado a cuidado, movimento ou aprendizagem.',{care:2,social:2},'Interesse em preparar uma atividade de cuidado, movimento ou aprendizagem.')
];
questions[7].options=[
 O('Descobrir uma solução usando tecnologia ou pesquisa.',{research:3},'Satisfação em descobrir uma solução por tecnologia ou pesquisa.'),
 O('Ver uma criação ou um serviço meu sendo reconhecido.',{creative:2,freelance:2},'Desejo de ver uma criação ou um serviço seu reconhecido.'),
 O('Ver um espaço ou uma solução construída funcionando.',{build:3},'Satisfação em ver um espaço ou uma solução construída funcionar.'),
 O('Melhorar o cuidado com pessoas ou com a natureza.',{care:2,nature:2,social:1},'Importância de contribuir para o cuidado com pessoas ou natureza.'),
 O('Ver uma equipe, um negócio ou um projeto educativo crescer.',{team:3,enterprise:1,social:1},'Satisfação em contribuir para o crescimento de uma equipe, negócio ou projeto educativo.')
];
// A person's preferred structure is not evidence of liking a particular field.
// Rank fields using direct interest cues; keep other answers as plan preferences.
function getProfile(values=answers){
 const scores=Object.fromEntries(Object.keys(routes).map(k=>[k,0])),evidence=Object.fromEntries(Object.keys(routes).map(k=>[k,[]]));
 [0,3,7].forEach(i=>{
  const option=questions[i].options[values[i]];if(!option)return;
  for(const [k,n] of Object.entries(option.signals)){scores[k]+=n;evidence[k].push({i,weight:n,text:option.note})}
 });
 const ranked=Object.keys(routes).sort((a,b)=>scores[b]-scores[a]),top=ranked[0],second=ranked[1];
 const enough=evidence[top].length>=2,clear=enough&&scores[top]-scores[second]>=3;
 return {scores,evidence,ranked,top,second,enough,clear};
}
function reflection(){return ''}
function workPreferences(){
 const selected=[1,2,4,5,6].filter(i=>answers[i]!==null&&answers[i]>=0);
 if(!selected.length)return '';
 return `<section class="rp-context"><span class="rp-overline">Seu jeito de experimentar</span><h2>O caminho também precisa caber em você.</h2><p>Além dos interesses, você contou estas preferências sobre como começar e lidar com o trabalho:</p><ul class="rp-evidence">${selected.map(i=>`<li>${esc(questions[i].options[answers[i]].note)}</li>`).join('')}</ul><p>Precisar de apoio, clareza ou renda não define a área em que você pode atuar.</p></section>`;
}
Object.assign(routinePlans,{
 build:{intro:'Explore um espaço ou uma solução em desenhos e simulações, sem obras ou intervenções reais.',focus:'Um projeto conceitual simples, com alternativas e revisão.',days:[
 ['Observe um espaço','Escolha um ambiente conhecido. Anote uma dificuldade de uso que você percebe, sem mudar móveis pesados ou estruturas.'],
 ['Busque duas referências','Observe duas soluções para ambientes parecidos. Anote uma ideia útil em cada uma, sem copiar um projeto.'],
 ['Desenhe uma primeira ideia','Faça um esboço em papel ou no celular. Indique como as pessoas usariam o espaço; precisão técnica não é necessária neste teste.'],
 ['Compare duas versões','Mude um detalhe no desenho e compare circulação, uso e organização. Não execute reformas.'],
 ['Conclua um projeto pequeno','Escolha uma versão e anote três decisões que tomou. Deixe claro que é um estudo inicial.'],
 ['Ouça outro olhar','Se quiser, mostre o desenho a alguém conhecido e pergunte se o uso ficou claro. Também pode revisar sozinho.'],
 ['Reveja a experiência','Compare observar, desenhar e revisar. Registre o que gostaria de estudar mais.'],
 ['Escolha outra restrição','No desenho, imagine menos espaço ou outra necessidade de uso.'],
 ['Conheça uma ferramenta','Leia uma introdução gratuita a desenho ou representação de espaços.'],
 ['Faça uma segunda versão','Aplique um recurso simples no projeto conceitual.'],
 ['Observe acessibilidade','Busque uma referência introdutória sobre uso inclusivo de espaços e anote uma dúvida.'],
 ['Revise uma decisão','Explique por que manteria ou mudaria uma escolha do desenho.'],
 ['Organize seu estudo','Reúna versões, referências e dúvidas numa pasta privada.'],
 ['Escolha como continuar','Decida entre estudar desenho, conhecer a rotina de uma profissão ou comparar outra área.']
 ]},
 care:{intro:'Conheça uma rotina de cuidado ou movimento por observação e estudo, sem orientar ou atender pessoas.',focus:'Entender uma função e o que desperta seu interesse nela.',days:[
 ['Escolha uma função','Escolha uma função de saúde, esporte ou bem-estar que gostaria de conhecer. Anote o que imagina sobre a rotina.'],
 ['Conheça uma rotina real','Leia uma apresentação de uma instituição de ensino ou associação da área. Separe estudo necessário e atividades do dia a dia.'],
 ['Prepare um resumo','Faça um texto ou áudio curto sobre o que essa função faz. Registre uma dúvida; não crie prescrições ou orientações de saúde.'],
 ['Compare duas funções','Observe diferenças entre uma função mais ligada a atendimento e outra ligada a estudo, organização ou movimento.'],
 ['Relacione com seu interesse','Anote se o que mais atrai você é o corpo, a ciência, o esporte, o contato com pessoas ou outra parte da rotina.'],
 ['Busque outra perspectiva','Se conhecer alguém da área, peça que conte como é um dia de trabalho. Sem esse contato, procure um relato institucional.'],
 ['Reveja suas impressões','Compare o que imaginava e o que descobriu. Registre interesse e dúvidas, sem concluir que já está apto a exercer a função.'],
 ['Escolha uma dúvida','Selecione algo da rotina que gostaria de entender melhor.'],
 ['Leia uma introdução','Procure um material educativo de uma instituição reconhecida sobre a profissão, sem usar o teste para decidir tratamentos.'],
 ['Compare ambientes','Observe como a função pode variar entre escola, clínica, organização ou espaço esportivo.'],
 ['Conheça a formação','Anote a formação e outras exigências que encontrou na fonte institucional.'],
 ['Reveja os limites','Observe que responsabilidades e limites de atuação chamaram sua atenção.'],
 ['Organize as descobertas','Reúna fontes, resumo e dúvidas numa pasta privada.'],
 ['Escolha o próximo passo','Decida entre conhecer um curso, conversar com alguém da área ou comparar outra rota.']
 ]},
 nature:{intro:'Explore um tema ambiental com observação, fontes e um pequeno registro.',focus:'Uma pergunta sobre natureza, recursos ou produção no campo.',days:[
 ['Escolha um tema próximo','Escolha água, resíduos, vegetação, alimentos ou outro tema ambiental próximo da sua realidade. Anote uma pergunta.'],
 ['Consulte referências','Compare duas fontes confiáveis, como instituições de ensino ou pesquisa. Separe o que sabe do que precisa verificar.'],
 ['Faça um registro','Anote uma observação sobre o tema ou organize informações públicas. Não colete animais, plantas ou materiais desconhecidos.'],
 ['Compare duas possibilidades','Observe duas formas de lidar com o problema. Anote limites e o que você ainda não sabe.'],
 ['Conclua um resumo pequeno','Faça um texto, áudio ou desenho explicando o tema, as fontes e uma dúvida que ficou.'],
 ['Peça outra leitura','Se quiser, compartilhe com alguém conhecido ou revise se o resumo distingue observação e opinião.'],
 ['Reveja seu interesse','Compare pesquisar, observar e pensar em soluções. Anote se quer conhecer conservação, produção rural, pesquisa ou educação ambiental.'],
 ['Escolha outro recorte','Aprofunde uma pergunta que apareceu na primeira semana.'],
 ['Conheça uma profissão','Leia sobre uma função ligada ao tema em uma fonte institucional.'],
 ['Organize informações','Monte uma pequena lista ou tabela com informações que conseguiu verificar.'],
 ['Observe impactos','Anote quem pode ser afetado pelo problema e quais informações faltam.'],
 ['Compare uma proposta','Reveja uma ideia de solução e registre dúvidas sobre sua viabilidade.'],
 ['Reúna os registros','Guarde fontes e observações numa pasta privada.'],
 ['Escolha como seguir','Decida entre conhecer uma formação, estudar o tema ou comparar outra área.']
 ]}
});
Object.assign(routinePlans.team,{intro:'Experimente uma tarefa de organização, atendimento ou gestão em uma equipe.',focus:'Conhecer uma função de gestão, comércio ou administração.'});
routinePlans.freelance.days[0]=['Escolha uma habilidade prática','Escolha uma entrega segura que você já consegue tentar, como organizar informações, preparar um item artesanal ou simular um serviço. Defina uma amostra pequena.'];
Object.assign(dailyExtras,{
 build:{steps:['Escolha uma dificuldade de uso do espaço.','Desenhe uma primeira alternativa.','Guarde o esboço e anote uma dúvida.'],start:'Desenhe só o contorno de um espaço conhecido e marque uma dificuldade de uso.',example:'Para uma área de estudos, desenhe duas posições possíveis da mesa. Compare no papel, sem mover objetos pesados.',small:'Faça um esboço com uma única melhoria e guarde para revisar.'},
 care:{steps:['Escolha uma informação da rotina que encontrou.','Resuma com suas palavras.','Anote a fonte e uma dúvida.'],start:'Escreva uma frase sobre o que a função faz no dia a dia.',example:'Você pode resumir como a rotina de uma função varia entre um ambiente educativo e um atendimento, usando uma fonte institucional.',small:'Anote uma atividade da profissão e uma pergunta que gostaria de fazer a alguém da área.'},
 nature:{steps:['Escolha uma informação ou observação segura.','Registre com suas palavras.','Anote uma fonte e uma limitação.'],start:'Escreva uma pergunta sobre água, resíduos, vegetação ou alimentos.',example:'No tema resíduos, observe quais informações públicas existem sobre coleta na sua região e anote uma dúvida.',small:'Guarde uma observação ou uma fonte sobre o tema, sem precisar concluir hoje.'}
});
routineState=freshRoutes();

let routeChosen=false;
const youthTopics={
 music:{label:'Música',icon:'music-2',hint:'Som, expressão e novas ideias.'},
 sport:{label:'Esporte',icon:'trophy',hint:'Movimento dentro e fora do jogo.'},
 games:{label:'Jogos',icon:'gamepad-2',hint:'Mundos, desafios e experiências.'},
 fashion:{label:'Moda',icon:'shirt',hint:'Estilo, identidade e criação.'},
 tech:{label:'Tecnologia',icon:'cpu',hint:'Ideias que podem funcionar.'}
};
const youthTitles={
 creative:['Uma ideia musical em 30 segundos','Um vídeo curto sobre esporte','Um conceito visual para um jogo','Um pequeno editorial de estilo','Uma história sobre uma tecnologia'],
 research:['O que muda a experiência de ouvir música?','Uma pergunta sobre dados no esporte','Uma comparação entre mecânicas de jogos','Uma investigação sobre materiais e moda','Duas soluções digitais para um problema'],
 build:['Um espaço para ouvir e criar música','Uma melhoria no desenho de uma quadra','Um espaço de jogos mais funcional','Um conceito de exposição de roupas','Um espaço de estudos e tecnologia'],
 care:['Uma profissão que aproxima música e cuidado','Uma rotina profissional no esporte','Quem trabalha com bem-estar no universo dos jogos?','Uma função ligada a corpo, cuidado e vestuário','Uma profissão de saúde que usa tecnologia'],
 nature:['Como acontece um evento musical atento ao ambiente?','Uma pergunta ambiental sobre espaços esportivos','Uma observação da natureza representada nos jogos','Uma pergunta sobre roupas e recursos naturais','Uma investigação sobre resíduos eletrônicos'],
 social:['Uma explicação curta sobre música','Uma explicação acessível sobre um esporte','Uma explicação de uma regra de jogo','Um guia curto sobre cuidado com roupas','Uma explicação simples sobre uma ferramenta digital'],
 enterprise:['Uma proposta para uma necessidade de quem faz música','Uma ideia para quem pratica um esporte','Uma proposta para uma necessidade de jogadores','Uma ideia para uma necessidade ligada a roupas','Uma proposta para um problema digital'],
 team:['Um plano simples para organizar um encontro musical','Um plano simples para organizar um evento esportivo','Um plano para organizar uma sessão de jogos','Uma simulação de organização de peças de roupa','Um plano simples para organizar uma equipe de tecnologia'],
 freelance:['Uma pequena entrega para um projeto musical','Uma pequena entrega para um projeto esportivo','Uma pequena entrega para um projeto de jogos','Uma amostra de serviço ligada a roupas','Uma pequena entrega de organização digital']
};
const youthOutputs={creative:'um roteiro, texto, desenho, áudio ou vídeo curto',research:'um resumo com duas alternativas e os limites da comparação',build:'um esboço conceitual com duas versões de um espaço',care:'um resumo de uma rotina profissional, sem orientar cuidados ou treinos',nature:'um registro com uma pergunta, duas fontes e uma observação',social:'uma explicação curta com um exemplo',enterprise:'uma proposta fictícia para ouvir opiniões, sem vendas ou investimento',team:'um plano curto com tarefas, responsáveis fictícios e uma ordem de execução',freelance:'uma amostra pequena de uma entrega segura, com prazo e limites'};
const youthBuildSteps={
 creative:'Escreva ou desenhe uma primeira versão. Se escolher vídeo ou áudio, um roteiro já vale como começo.',
 research:'Registre uma pergunta, compare duas alternativas e anote o que observou e o que ainda não pode concluir.',
 build:'Desenhe duas alternativas no papel ou no celular. Compare o uso do espaço, sem obras ou intervenções reais.',
 care:'Leia uma apresentação institucional da função e resuma atividades, formação e uma dúvida. Não prescreva cuidados ou exercícios.',
 nature:'Compare duas fontes institucionais e faça um registro com suas próprias palavras, sem coletar materiais ou seres vivos.',
 social:'Escreva uma explicação curta e um exemplo. Releia imaginando alguém que ainda não conhece o assunto.',
 enterprise:'Descreva um problema e uma proposta em três frases. Ela é um teste de ideia, sem depender de retorno financeiro.',
 team:'Liste três tarefas, a ordem em que aconteceriam e quem poderia fazer cada uma. Use uma situação fictícia.',
 freelance:'Faça uma amostra de uma parte do pedido. Combine o que entra e o que fica fora da entrega; não assuma um cliente real.'
};
const newYouth=()=>({topic:'sport',projectRoute:null,projects:{},creations:[],editor:null,shareId:null,deleteId:null,compareSelection:[],comparisons:{},next:{},earned:[],counter:1,message:''});
let youth=newYouth();
function youthProjectRoute(){if(Object.hasOwn(routes,youth.projectRoute))return youth.projectRoute;if(routeChosen&&Object.hasOwn(routes,activeRoute))return activeRoute;if(complete()){const p=getProfile();if(p.clear)return p.top;}return null;}
function topicIndex(topic){return Object.keys(youthTopics).indexOf(topic)}
function proposedProject(k=activeRoute,topic=youth.topic){return {route:k,topic,title:youthTitles[k][topicIndex(topic)],output:youthOutputs[k]}}
function projectFor(k=activeRoute){return youth.projects[k]||null}
function startYouthProject(){
 const k=youthProjectRoute();if(!k){youth.message='Escolha um caminho ou responda ao questionário antes de começar.';render();return;}const proposal=proposedProject(k);
 if(youth.projects[k]?.topic!==proposal.topic)youth.projects[k]={...proposal,id:'project-'+youth.counter++};
 activeRoute=k;interestFocus=youthTopics[proposal.topic].label;routeChosen=true;
 youth.message='Projeto escolhido. Os registros anteriores continuam preservados.';
 navigate(complete()?'home':'routine');
}
function creationDraft(entry=null){
 const project=projectFor();
 youth.editor=entry?JSON.parse(JSON.stringify(entry)):{id:null,title:project?.title||'',description:'',url:'',image:'',type:'text',status:'draft',feedbackRequested:false,route:activeRoute,topic:project?.topic||youth.topic,projectId:project?.id||null,error:''};
 youth.editor.error='';youth.shareId=null;navigate('creations');
}
function validProjectUrl(value){try{const url=new URL(value);return ['http:','https:'].includes(url.protocol)?url.href:null}catch{return null}}
function saveCreation(){
 const d=youth.editor;if(!d)return;
 d.title=d.title.trim().slice(0,120);d.description=d.description.trim().slice(0,3000);d.url=d.url.trim().slice(0,2000);
 if(!d.title){d.error='Dê um nome para sua criação.';render();return}
 if(!d.description&&!d.url&&!d.image){d.error='Guarde um texto, uma imagem ou um link para representar o que você fez.';render();return}
 if(d.url&&!validProjectUrl(d.url)){d.error='Use um link completo começando com https:// ou http://.';render();return}
 const saved={...d,id:d.id||'creation-'+youth.counter++,url:d.url?validProjectUrl(d.url):'',error:''};
 const index=youth.creations.findIndex(c=>c.id===saved.id);if(index>=0)youth.creations[index]=saved;else youth.creations.unshift(saved);
 youth.editor=null;youth.message='Criação guardada. Você escolhe o que compartilhar.';render();live.textContent='Criação guardada.';
}
const youthBadges=[
 {id:'finish',title:'Terminei meu primeiro projeto',hint:'Guarde uma criação e marque como concluída.',icon:'flag'},
 {id:'feedback',title:'Pedi meu primeiro feedback',hint:'Marque numa criação que você pediu uma opinião.',icon:'messages-square'},
 {id:'explore',title:'Experimentei outra área',hint:'Registre experiências em dois caminhos ou termine os dois testes de uma comparação.',icon:'compass'}
];
function updateAchievements(){
 const tests=Object.keys(routineState).filter(k=>routineCount(k,14)>0).length;
 const compared=Object.values(youth.comparisons).some(pair=>Object.values(pair.entries).filter(e=>e.tried).length===2);
 const earned={finish:youth.creations.some(c=>c.status==='done'),feedback:youth.creations.some(c=>c.feedbackRequested),explore:tests>=2||compared};
 for(const badge of youthBadges)if(earned[badge.id]&&!youth.earned.includes(badge.id))youth.earned.push(badge.id);
}
function currentComparison(){
 if(youth.compareSelection.length!==2)return null;
 const key=youth.compareSelection.slice().sort().join('|');
 if(!youth.comparisons[key])youth.comparisons[key]={topic:youth.topic,entries:Object.fromEntries(youth.compareSelection.map(k=>[k,{energy:'',repeat:'',note:'',tried:false}]))};
 return youth.comparisons[key];
}
const energyLabels={liked:'Gostei da experiência',mixed:'Foi mais ou menos',tired:'Me cansou ou não combinou hoje'};
const repeatLabels={yes:'Quero repetir',maybe:'Talvez, com ajustes',no:'Prefiro outro teste'};
function comparisonTask(k,topic){const p=proposedProject(k,topic);return `Experimente por cerca de 10 minutos: ${youthBuildSteps[k]} Use como tema “${p.title}”. Você não precisa concluir um projeto inteiro para registrar o teste.`}
function nextState(){const k=nextPathKey();if(!k)return null;return youth.next[k]??={goal:null,done:{learn:[false,false,false],experience:[false,false,false],project:[false,false,false]}}}
const nextGoals={learn:{title:'Quero aprender mais',icon:'book-open',hint:'Um assunto por vez, com um teste pequeno.'},experience:{title:'Quero minha primeira experiência',icon:'briefcase-business',hint:'Organize o que você já consegue apresentar.'},project:{title:'Quero desenvolver um projeto',icon:'rocket',hint:'Transforme uma descoberta em uma nova versão.'}};
function nextTasks(goal){
 const k=nextPathKey();if(!k)return [];const area=routes[k].title,project=projectFor(k);
 if(goal==='learn')return [`Escolha uma habilidade de ${area.toLowerCase()} que você quer entender melhor.`,`Encontre um material introdutório gratuito de uma instituição ou autor com experiência na área. Anote a fonte e uma dúvida.`,`Reserve um bloco curto para aplicar uma ideia do material e guardar o resultado em Minhas criações.`];
 if(goal==='experience')return [`Liste duas funções de ${area.toLowerCase()} que você gostaria de conhecer e leia o que fazem no dia a dia.`,`Prepare uma apresentação curta: o que quer aprender, uma habilidade que está praticando e um exemplo de projeto seu.`,`Escolha um próximo contato ou uma oportunidade que faça sentido para seu momento. Confira as exigências antes de enviar qualquer coisa por conta própria.`];
 return [`Escolha um resultado pequeno${project?' para “'+project.title+'”':''} e defina o que vai deixar para depois.`,`Divida o trabalho em três etapas e separe um momento curto para a primeira tentativa.`,`Guarde uma versão em Minhas criações e decida se quer pedir uma opinião antes de revisar.`];
}
function youthShareText(entry){return `${entry.title}\n${routes[entry.route].title}\n\n${entry.description}${entry.url?'\n\n'+entry.url:''}\n\nCriado durante uma exploração no Rumo.`}
function beginYouthDemo(){
 beginDailyDemo();youth.topic='sport';
 youth.projects.creative={...proposedProject('creative','sport'),id:'sample-project'};
 youth.creations=[{id:'sample-video',title:'Meu primeiro roteiro sobre esporte',description:'Abertura: um detalhe que mudou minha forma de assistir ao jogo.\nMeio: explicar esse detalhe com um exemplo.\nFinal: o que eu quero observar na próxima partida.',type:'text',url:'',image:'',status:'done',feedbackRequested:false,route:'creative',topic:'sport',projectId:'sample-project'}];
 youth.counter=1;youth.message='';render();
}

function youthNotice(){return youth.message?`<div class="ry-notice" role="status"><span>${esc(youth.message)}</span><button data-y-action="dismiss" aria-label="Fechar aviso">×</button></div>`:''}
function topicPicker(open=false){return `<div class="ry-topics" role="group" aria-label="Tema do projeto">${Object.entries(youthTopics).map(([k,t])=>`<button class="ry-topic" ${open?'data-y-topic-open':'data-y-topic'}="${k}" aria-pressed="${!open&&youth.topic===k}"><i data-lucide="${t.icon}" aria-hidden="true"></i><strong>${t.label}</strong><small>${t.hint}</small></button>`).join('')}</div>`}
function projectRoutePicker(k){return `<details class="ry-route-picker"><summary>Caminho: <strong>${k?routes[k].title:'Indefinido'}</strong><span aria-hidden="true">⌄</span></summary><div class="ry-route-options">${Object.entries(routes).map(([key,r])=>`<button data-y-project-route="${key}" aria-pressed="${key===k}">${r.title}</button>`).join('')}</div></details>`}
function projectsView(){const k=youthProjectRoute();if(!k)return `<section class="ry-page">${youthNotice()}<span class="rp-overline">Projetos por interesse</span><h1>Comece pelo que você curte.<br><em>Explore suas possibilidades.</em></h1><p>Escolher um interesse muda o tema do projeto. Seu caminho continua indefinido até você escolher uma área ou concluir seu mapa com uma indicação clara.</p>${topicPicker()}${projectRoutePicker(null)}<section class="ry-project-copy"><span class="rp-overline">Seu caminho</span><h2>Indefinido</h2><p>Responda ao questionário para descobrir possibilidades ou escolha um dos nove caminhos acima para experimentar.</p><div class="rp-actions"><button class="rp-button" data-act="start">Descobrir meu mapa →</button><button class="rp-button rp-secondary" data-y-action="start-project" disabled>Escolha um caminho para começar</button></div></section></section>`;const p=proposedProject(k),existing=projectFor(k);return `<section class="ry-page">${youthNotice()}<span class="rp-overline">Projetos por interesse</span><div class="ry-heading"><div><h1>Comece pelo que você curte.<br><em>Crie algo que é seu.</em></h1><p>O mesmo interesse pode abrir caminhos diferentes. Escolha um tema e veja uma ideia pequena para experimentar.</p></div><span class="ry-chip">Sem compras para começar</span></div>${topicPicker()}${projectRoutePicker(k)}<div class="ry-project"><div class="ry-project-art" aria-hidden="true"><div class="ry-orbit"></div><i data-lucide="${youthTopics[youth.topic].icon}"></i><small>DA CURIOSIDADE<br>À PRIMEIRA VERSÃO.</small></div><div class="ry-project-copy"><span class="rp-overline">${youthTopics[youth.topic].label} × ${routes[k].short}</span><h2>${p.title}</h2><p>O que você vai guardar: <strong>${p.output}.</strong></p><ol class="rd-steps"><li>Escolha uma versão que caiba na sua semana.</li><li>Use as tarefas do plano para criar, testar e revisar.</li><li>Guarde o que fez e o que descobriu em Minhas criações.</li></ol><div class="rp-actions"><button class="rp-button" data-y-action="start-project">${existing?.topic===youth.topic?'Continuar este projeto':'Começar este projeto'} ↗</button><button class="rp-link" data-y-nav="creations">Ver minhas criações →</button></div>${existing&&existing.topic!==youth.topic&&routineCount(k,14)>0?'<p class="ry-fine">O novo tema será usado nas próximas tarefas. Os registros já feitos ficam preservados.</p>':''}</div></div><p class="ry-fine">Essas são ideias de projeto, não um resultado pessoal. Seu questionário continua disponível no menu.</p></section>`}
function creationEditor(){const d=youth.editor;return `<section class="ry-editor"><div class="ry-heading"><div><span class="rp-overline">Um registro do que você criou</span><h2>${d.id?'Revisar minha criação':'Guardar uma criação'}</h2></div><button class="rp-link" data-y-action="cancel-editor">Cancelar</button></div>${d.error?`<p class="ry-error" role="alert">${esc(d.error)}</p>`:''}<label for="ry-title">Nome do projeto</label><input id="ry-title" data-y-field="title" maxlength="120" value="${esc(d.title)}" placeholder="Ex.: Meu primeiro roteiro sobre esporte"><label for="ry-description">Seu texto ou o que você criou</label><textarea id="ry-description" data-y-field="description" maxlength="3000" placeholder="Cole um texto, conte o que fez ou registre o que aprendeu…">${esc(d.description)}</textarea><label for="ry-url">Link do projeto <span>(opcional)</span></label><input id="ry-url" data-y-field="url" type="url" maxlength="2000" value="${esc(d.url)}" placeholder="https://"><label for="ry-image">Uma imagem do projeto <span>(opcional · PNG, JPEG ou WebP · até 3 MB)</span></label><input id="ry-image" data-y-image type="file" accept="image/png,image/jpeg,image/webp">${d.image?`<div class="ry-image-preview"><img src="${d.image}" alt="Imagem escolhida para o projeto"><button class="rp-link" data-y-action="remove-image">Remover imagem</button></div>`:''}<fieldset class="ry-status"><legend>Em que ponto está?</legend><button data-y-status="draft" aria-pressed="${d.status==='draft'}">Em construção</button><button data-y-status="done" aria-pressed="${d.status==='done'}">Concluído</button></fieldset><p class="ry-fine">Ligado a ${routes[d.route].title}. Você pode guardar rascunhos; não precisa publicar.</p><div class="rp-actions"><button class="rp-button" data-y-action="save-creation">Guardar em Minhas criações ✓</button></div></section>`}
function creationCard(c){return `<article class="ry-work">${c.image?`<img class="ry-work-image" src="${c.image}" alt="Imagem do projeto ${esc(c.title)}">`:`<div class="ry-work-cover" aria-hidden="true"><i data-lucide="${youthTopics[c.topic]?.icon||'file-text'}"></i><span>${youthTopics[c.topic]?.label||'Meu projeto'}</span></div>`}<div class="ry-work-body"><span class="ry-work-status">${c.status==='done'?'Concluído ✓':'Em construção'}</span><h2>${esc(c.title)}</h2><small>${routes[c.route].title}</small>${c.description?`<p class="ry-work-text">${esc(c.description)}</p>`:''}${c.url?`<a class="ry-work-link" href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">Abrir link do projeto ↗</a>`:''}<button class="ry-feedback-mark" data-y-feedback="${c.id}" aria-pressed="${c.feedbackRequested}"><i data-lucide="message-circle" aria-hidden="true"></i>${c.feedbackRequested?'Você marcou: pedi uma opinião ✓':'Pedi uma opinião sobre este projeto'}</button><div class="ry-work-actions"><button class="rp-link" data-y-edit="${c.id}">Editar</button><button class="rp-link" data-y-share="${c.id}">Preparar para compartilhar</button><button class="rp-link" data-y-delete="${c.id}">${youth.deleteId===c.id?'Confirmar remoção':'Remover'}</button></div>${youth.shareId===c.id?`<div class="ry-share"><strong>Compartilhe só quando quiser.</strong><p>O resumo inclui o texto e o link. A imagem fica aqui; você pode anexar o arquivo original ao compartilhar.</p><textarea readonly aria-label="Resumo para compartilhar">${esc(youthShareText(c))}</textarea><button class="rp-button rp-secondary" data-y-copy="${c.id}">Copiar resumo</button><small>O Rumo não envia nem publica por você.</small></div>`:''}</div></article>`}
function creationsView(){return `<section class="ry-page">${youthNotice()}<span class="rp-overline">Minhas criações</span><div class="ry-heading"><div><h1>Olha o que você<br><em>já está construindo.</em></h1><p>Textos, imagens, links e descobertas. Um espaço para o que é seu, mesmo quando ainda é rascunho.</p></div>${!youth.editor?'<button class="rp-button" data-y-action="new-creation">Guardar uma criação +</button>':''}</div>${youth.editor?creationEditor():''}${youth.creations.length?`<div class="ry-work-grid">${youth.creations.map(creationCard).join('')}</div>`:!youth.editor?`<div class="ry-empty"><i data-lucide="folder-heart" aria-hidden="true"></i><h2>Seu primeiro projeto começa pequeno.</h2><p>Um texto de três linhas, um esboço ou um link já pode mostrar uma tentativa sua.</p><button class="rp-button" data-y-nav="projects">Escolher um projeto ↗</button></div>`:''}<p class="ry-fine">As criações ficam salvas neste navegador e dispositivo. Nada é publicado automaticamente. Limpar os dados do navegador pode apagar seus registros.</p></section>`}
function compareView(){const pair=currentComparison(),keys=youth.compareSelection;return `<section class="ry-page">${youthNotice()}<span class="rp-overline">Comparar dois caminhos</span><h1>Na dúvida entre dois?<br><em>Experimente os dois.</em></h1><p>Escolha dois caminhos, faça uma tentativa curta em cada um e compare sua experiência. Não precisa decidir uma profissão.</p><div class="ry-compare-picker" role="group" aria-label="Escolha dois caminhos">${Object.entries(routes).map(([k,r])=>`<button data-y-compare-route="${k}" aria-pressed="${keys.includes(k)}" ${keys.length===2&&!keys.includes(k)?'disabled':''}>${keys.includes(k)?'<span aria-hidden="true">✓</span>':''}${r.title}</button>`).join('')}</div><p class="ry-fine">${keys.length} de 2 escolhidos. Para trocar, desmarque um caminho.</p>${pair?`<div class="ry-compare-grid">${keys.map(k=>{const e=pair.entries[k];return `<article class="ry-test"><span class="rp-overline">Um teste de cerca de 10 minutos</span><h2>${routes[k].title}</h2><p>${comparisonTask(k,pair.topic)}</p><fieldset><legend>O que você sentiu ao experimentar?</legend>${Object.entries(energyLabels).map(([v,t])=>`<button data-y-compare-field="energy" data-y-compare-route-key="${k}" data-y-value="${v}" aria-pressed="${e.energy===v}">${t}</button>`).join('')}</fieldset><label for="ry-compare-note-${k}">O que foi fácil ou cansou? <span>(opcional)</span></label><textarea id="ry-compare-note-${k}" data-y-compare-note="${k}" maxlength="1000" placeholder="Uma frase sobre a experiência…">${esc(e.note)}</textarea><fieldset><legend>Você toparia repetir?</legend>${Object.entries(repeatLabels).map(([v,t])=>`<button data-y-compare-field="repeat" data-y-compare-route-key="${k}" data-y-value="${v}" aria-pressed="${e.repeat===v}">${t}</button>`).join('')}</fieldset><button class="rp-button rp-secondary" data-y-compare-save="${k}" ${!e.energy||!e.repeat?'disabled':''}>${e.tried?'Teste registrado ✓':'Registrar meu teste'}</button></article>`}).join('')}</div>${keys.every(k=>pair.entries[k].tried)?`<section class="ry-compare-result"><span class="rp-overline">Suas experiências lado a lado</span><h2>O que você gostaria de repetir?</h2><div class="ry-compare-summary">${keys.map(k=>{const e=pair.entries[k];return `<div><h3>${routes[k].title}</h3><p>${energyLabels[e.energy]}.</p><strong>${repeatLabels[e.repeat]}.</strong>${e.note?`<p>${esc(e.note)}</p>`:''}<button class="rp-button" data-y-adopt="${k}">Continuar por aqui ↗</button></div>`}).join('')}</div><p>Esse foi um teste curto. Você pode mudar de ideia e testar outra tarefa antes de escolher.</p></section>`:''}`:'<div class="ry-empty"><i data-lucide="git-compare-arrows" aria-hidden="true"></i><h2>Dois testes. Mais pistas para você.</h2><p>Depois de escolher os caminhos, as tarefas aparecem aqui.</p></div>'}</section>`}
function nextView(){const k=nextPathKey();if(!k)return lockedNextView();const n=nextState();return `<section class="ry-page">${youthNotice()}<span class="rp-overline">Meu próximo passo</span><h1>Sua descoberta pode<br><em>virar um começo.</em></h1><p>Caminho ${routeChosen?'em exploração':'sugerido pelo seu mapa'}: ${routes[k].title}. Escolha o que você precisa agora.</p><div class="ry-goals">${Object.entries(nextGoals).map(([k,g])=>`<button data-y-goal="${k}" aria-pressed="${n.goal===k}"><i data-lucide="${g.icon}" aria-hidden="true"></i><strong>${g.title}</strong><small>${g.hint}</small></button>`).join('')}</div>${n.goal?`<section class="ry-next-plan"><span class="rp-overline">${nextGoals[n.goal].title}</span><h2>Três passos que cabem no seu momento.</h2><div class="ry-checklist">${nextTasks(n.goal).map((t,i)=>`<label><input type="checkbox" data-y-next-check="${i}" ${n.done[n.goal][i]?'checked':''}><span>${t}</span></label>`).join('')}</div><p>${n.done[n.goal].filter(Boolean).length} de 3 passos marcados por você. Sem prazo obrigatório.</p><div class="rp-actions"><button class="rp-button" data-y-nav="${n.goal==='project'?'projects':'creations'}">${n.goal==='project'?'Escolher meu projeto':'Abrir Minhas criações'} ↗</button><button class="rp-link" data-y-nav="compare">Ainda quero comparar dois caminhos</button></div></section>`:'<p class="ry-fine">Você pode trocar de objetivo depois. Cada objetivo guarda seus próprios passos neste navegador.</p>'}</section>`}
function achievementsView(){return `<section class="ry-page"><span class="rp-overline">Minhas conquistas</span><h1>Pequenos passos.<br><em>Conquistas de verdade.</em></h1><p>Aqui vale o que você experimenta. Uma pausa não apaga o que já construiu.</p><div class="ry-badges">${youthBadges.map(b=>{const earned=youth.earned.includes(b.id);return `<article class="ry-badge ${earned?'ry-earned':''}"><span class="ry-badge-icon"><i data-lucide="${b.icon}" aria-hidden="true"></i></span><small>${earned?'Conquistado ✓':'Um próximo marco'}</small><h2>${b.title}</h2><p>${earned?({finish:'Você guardou uma criação marcada como concluída.',feedback:'Você marcou que pediu uma opinião sobre um projeto.',explore:'Você registrou experiências em mais de um caminho.'})[b.id]:b.hint}</p><button class="rp-link" data-y-nav="${b.id==='explore'?'compare':'creations'}">${b.id==='explore'?'Comparar caminhos':'Ver minhas criações'} →</button></article>`}).join('')}</div><p class="ry-fine">Os marcos reconhecem seus registros. Não são notas de talento nem uma comparação com outras pessoas.</p></section>`}
function youthDashboard(){const p=projectFor();return `<section class="ry-dashboard"><div class="ry-heading"><div><span class="rp-overline">Da descoberta para algo seu</span><h2>Um interesse. Muitas possibilidades.</h2></div><button class="rp-link" data-y-nav="achievements">Minhas conquistas →</button></div>${p?`<div class="ry-active-project"><span class="ry-topic-stamp"><i data-lucide="${youthTopics[p.topic].icon}" aria-hidden="true"></i></span><div><small>SEU PROJETO · ${youthTopics[p.topic].label}</small><strong>${esc(p.title)}</strong></div><button class="rp-link" data-y-action="new-creation">Guardar uma criação ↗</button></div>`:''}<div class="ry-quick-grid"><button data-y-nav="projects"><i data-lucide="sparkles" aria-hidden="true"></i><strong>Projetos por interesse</strong><small>Um projeto com a sua cara.</small><span aria-hidden="true">↗</span></button><button data-y-nav="creations"><i data-lucide="folder-heart" aria-hidden="true"></i><strong>Minhas criações</strong><small>${youth.creations.length?'Seus projetos e rascunhos.':'Guarde a sua primeira tentativa.'}</small><span aria-hidden="true">↗</span></button><button data-y-nav="compare"><i data-lucide="git-compare-arrows" aria-hidden="true"></i><strong>Estou entre dois caminhos</strong><small>Compare experiências curtas.</small><span aria-hidden="true">↗</span></button><button data-y-nav="next"><i data-lucide="arrow-up-right" aria-hidden="true"></i><strong>Meu próximo passo</strong><small>Aprender, experimentar ou criar.</small><span aria-hidden="true">↗</span></button></div><div class="ry-earned-strip">${youthBadges.map(b=>`<button data-y-nav="achievements" class="${youth.earned.includes(b.id)?'is-earned':''}"><i data-lucide="${b.icon}" aria-hidden="true"></i><span>${b.title}${youth.earned.includes(b.id)?' ✓':''}</span></button>`).join('')}</div></section>`}
function youthNextCallout(){return `<section class="ry-pass-next"><span class="rp-overline">O que você quer fazer com essa descoberta?</span><h2>Seu próximo passo também pode começar aqui.</h2><p>Escolha entre aprender mais, preparar uma primeira experiência ou desenvolver um projeto. Essa orientação é gratuita e não exige liberar a continuação.</p><button class="rp-button rp-secondary" data-y-nav="next">Escolher meu próximo passo →</button></section>`}

root.addEventListener('click',async event=>{
 const b=event.target.closest('button');if(!b||!root.contains(b))return;
 if(b.dataset.yNav){if(b.dataset.yNav==='next'&&!canAccessNext()){live.textContent=nextLockedMessage();return}if(['projects','creations','compare','next','achievements'].includes(b.dataset.yNav)){youth.message='';navigate(b.dataset.yNav)}return}
 if(b.dataset.yTopicOpen){if(Object.hasOwn(youthTopics,b.dataset.yTopicOpen)){youth.topic=b.dataset.yTopicOpen;navigate('projects')}return}
 if(b.dataset.yTopic){if(Object.hasOwn(youthTopics,b.dataset.yTopic)){youth.topic=b.dataset.yTopic;render()}return}
 if(b.dataset.yProjectRoute){if(Object.hasOwn(routes,b.dataset.yProjectRoute)){youth.projectRoute=b.dataset.yProjectRoute;render()}return}
 if(b.dataset.yStatus){if(youth.editor&&['draft','done'].includes(b.dataset.yStatus)){youth.editor.status=b.dataset.yStatus;render()}return}
 if(b.dataset.yEdit){const entry=youth.creations.find(c=>c.id===b.dataset.yEdit);if(entry)creationDraft(entry);return}
 if(b.dataset.yFeedback){const entry=youth.creations.find(c=>c.id===b.dataset.yFeedback);if(entry){entry.feedbackRequested=!entry.feedbackRequested;render()}return}
 if(b.dataset.yShare){youth.shareId=youth.shareId===b.dataset.yShare?null:b.dataset.yShare;render();return}
 if(b.dataset.yDelete){
  const id=b.dataset.yDelete;
  if(youth.deleteId===id){youth.creations=youth.creations.filter(c=>c.id!==id);youth.deleteId=null;youth.message='Criação removida desta prévia.'}else youth.deleteId=id;
  render();return;
 }
 if(b.dataset.yCopy){
  const entry=youth.creations.find(c=>c.id===b.dataset.yCopy);if(!entry)return;
  try{if(!globalThis.navigator?.clipboard?.writeText)throw new Error('Clipboard unavailable');await navigator.clipboard.writeText(youthShareText(entry));youth.message='Resumo copiado. Você decide onde compartilhar.'}
  catch{youth.message='Selecione o resumo e use a opção Copiar do seu dispositivo.'}
  render();return;
 }
 if(b.dataset.yCompareRoute){
  const k=b.dataset.yCompareRoute;if(!Object.hasOwn(routes,k))return;
  if(youth.compareSelection.includes(k))youth.compareSelection=youth.compareSelection.filter(v=>v!==k);else if(youth.compareSelection.length<2)youth.compareSelection.push(k);
  render();return;
 }
 if(b.dataset.yCompareField){
  const pair=currentComparison(),field=b.dataset.yCompareField,k=b.dataset.yCompareRouteKey,value=b.dataset.yValue;
  if(pair?.entries[k]&&((field==='energy'&&Object.hasOwn(energyLabels,value))||(field==='repeat'&&Object.hasOwn(repeatLabels,value)))){pair.entries[k][field]=value;pair.entries[k].tried=false;render()}
  return;
 }
 if(b.dataset.yCompareSave){
  const entry=currentComparison()?.entries[b.dataset.yCompareSave];if(entry?.energy&&entry?.repeat){entry.tried=true;render();live.textContent='Experiência registrada na comparação.'}return;
 }
 if(b.dataset.yAdopt){
  const k=b.dataset.yAdopt;if(!currentComparison()?.entries[k]?.tried)return;
  activeRoute=k;routeChosen=true;youth.projectRoute=k;
  if(!projectFor(k)){const pair=currentComparison();youth.projects[k]={...proposedProject(k,pair.topic),id:'project-'+youth.counter++}}
  interestFocus=youthTopics[projectFor(k).topic].label;navigate(complete()?'home':'routine');return;
 }
 if(b.dataset.yGoal){if(canAccessNext()&&Object.hasOwn(nextGoals,b.dataset.yGoal)){nextState().goal=b.dataset.yGoal;render()}return}
 switch(b.dataset.yAction){
  case'start-project':startYouthProject();break;
  case'new-creation':creationDraft();break;
  case'cancel-editor':youth.editor=null;render();break;
  case'save-creation':saveCreation();break;
  case'remove-image':if(youth.editor){youth.editor.image='';render()}break;
  case'dismiss':youth.message='';render();break;
 }
});
root.addEventListener('input',event=>{
 const field=event.target.dataset.yField;
 if(youth.editor&&['title','description','url'].includes(field)){const limit={title:120,description:3000,url:2000}[field];youth.editor[field]=event.target.value.slice(0,limit);return}
 const key=event.target.dataset.yCompareNote;if(key!==undefined){const entry=currentComparison()?.entries[key];if(entry)entry.note=event.target.value.slice(0,1000)}
});
root.addEventListener('change',event=>{
 if(event.target.dataset.yNextCheck!==undefined){const n=nextState(),i=Number(event.target.dataset.yNextCheck);if(n&&n.goal&&Number.isInteger(i)&&i>=0&&i<3){n.done[n.goal][i]=!!event.target.checked;render()}return}
 if(!event.target.hasAttribute('data-y-image')||!youth.editor)return;
 const file=event.target.files?.[0];if(!file)return;
 if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>3*1024*1024){youth.editor.error='Escolha uma imagem PNG, JPEG ou WebP de até 3 MB.';render();return}
 const draft=youth.editor,reader=new FileReader();
 reader.onload=()=>{if(youth.editor!==draft)return;draft.image=String(reader.result);draft.error='';render()};
 reader.onerror=()=>{if(youth.editor===draft){draft.error='Não foi possível ler essa imagem. Tente outro arquivo.';render()}};
 reader.readAsDataURL(file);
});

function nextPathKey(){
 if(!complete())return null;
 if(routeChosen&&Object.hasOwn(routes,activeRoute))return activeRoute;
 const profile=getProfile();
 return profile.clear?profile.top:null;
}
function canAccessNext(){return nextPathKey()!==null}
function nextLockedMessage(){return complete()?'Escolha um caminho no seu mapa para liberar seu próximo passo.':'Responda às dez perguntas para criar seu mapa e liberar seu próximo passo.'}
function refreshNextAvailability(){
 const available=canAccessNext();
 root.querySelectorAll('[data-y-nav="next"]').forEach(button=>{
  button.disabled=!available;button.setAttribute('aria-disabled',String(!available));
  if(!available)button.setAttribute('data-tooltip',nextLockedMessage());else button.removeAttribute('data-tooltip');
 });
 const caption=navigation.querySelector('[data-y-nav="next"] small');
 if(caption)caption.textContent=available?'Aprender, experimentar ou criar':complete()?'Escolha um caminho no seu mapa':'Disponível após criar seu mapa';
}
function lockedNextView(){return `<section class="ry-page"><span class="rp-overline">Meu próximo passo</span><h1>Primeiro, descubra<br><em>seus caminhos.</em></h1><p>${nextLockedMessage()}</p><button class="rp-button" data-act="${complete()?'results':'question'}">${complete()?'Abrir meu mapa':'Responder ao questionário'} →</button></section>`}

const duoRoles={
 create:{title:'Criar',icon:'pencil-line',hint:'Dar forma à primeira versão.',task:'Faça um primeiro rascunho ou esboço da entrega. Comece pequeno e mostre sua ideia à outra pessoa.'},
 research:{title:'Pesquisar',icon:'search',hint:'Trazer referências e perguntas.',task:'Encontre duas referências e anote uma ideia útil e uma dúvida. Explique como isso pode ajudar o projeto, sem copiar a criação de outra pessoa.'},
 organize:{title:'Organizar',icon:'list-checks',hint:'Transformar a ideia em etapas.',task:'Divida a entrega em três etapas. Combine com a outra pessoa uma ordem simples e o que vocês vão deixar para depois.'},
 present:{title:'Apresentar',icon:'messages-square',hint:'Ajudar a ideia a ser entendida.',task:'Prepare uma explicação curta sobre o que vocês estão fazendo, para quem e por quê. Pergunte à outra pessoa o que ficou claro.'},
 test:{title:'Testar e revisar',icon:'scan-eye',hint:'Perceber o que pode melhorar.',task:'Observe uma primeira versão e anote algo que funciona e uma mudança pequena que ajudaria. Conversem antes de alterar.'}
};
const newDuoRecord=()=>({done:false,energy:'',note:''});
const newDuo=()=>({phase:'setup',nameA:'',nameB:'',topic:'sport',route:'creative',roles:{a:'create',b:'research'},round:1,rounds:[],records:{a:newDuoRecord(),b:newDuoRecord()},id:null,restartConfirm:false});
function duoState(){return youth.duo??=newDuo()}
function duoName(person){const d=duoState();return (person==='a'?d.nameA:d.nameB).trim()||(person==='a'?'Pessoa 1':'Pessoa 2')}
function duoComplete(){const d=duoState();return ['a','b'].every(p=>d.records[p].done&&Object.hasOwn(energyLabels,d.records[p].energy))}
function duoRolePicker(person){const d=duoState();return `<div class="ru-role-picker" role="group" aria-label="Papel de ${esc(duoName(person))}">${Object.entries(duoRoles).map(([k,r])=>`<button data-duo-role-person="${person}" data-duo-role="${k}" aria-pressed="${d.roles[person]===k}"><i data-lucide="${r.icon}" aria-hidden="true"></i><span><strong>${r.title}</strong><small>${r.hint}</small></span></button>`).join('')}</div>`}
function duoSetup(){const d=duoState(),p=proposedProject(d.route,d.topic);return `<div class="ru-setup"><div class="ru-people">${['a','b'].map((person,i)=>`<section class="ru-person"><span class="ru-person-tag">${String(i+1).padStart(2,'0')} / SEU LADO DA DUPLA</span><label for="ru-name-${person}">Como podemos chamar você? <span>(opcional)</span></label><input id="ru-name-${person}" data-duo-name="${person}" maxlength="30" value="${esc(person==='a'?d.nameA:d.nameB)}" placeholder="${i===0?'Seu nome':'Nome do seu amigo'}"><h2>Escolha o que quer experimentar.</h2>${duoRolePicker(person)}</section>`).join('')}</div><section class="ru-shared"><span class="rp-overline">Um projeto para conectar os dois</span><h2>O ponto de partida de vocês.</h2><div class="ry-topics" role="group" aria-label="Tema da dupla">${Object.entries(youthTopics).map(([k,t])=>`<button class="ry-topic" data-duo-topic="${k}" aria-pressed="${d.topic===k}"><i data-lucide="${t.icon}" aria-hidden="true"></i><strong>${t.label}</strong><small>${t.hint}</small></button>`).join('')}</div><details class="ry-route-picker"><summary>Caminho da missão: <strong>${routes[d.route].title}</strong><span aria-hidden="true">⌄</span></summary><div class="ry-route-options">${Object.entries(routes).map(([k,r])=>`<button data-duo-route="${k}" aria-pressed="${d.route===k}">${r.title}</button>`).join('')}</div></details><div class="ru-proposal"><i data-lucide="flag" aria-hidden="true"></i><div><small>O PROJETO DE VOCÊS</small><h3>${p.title}</h3><p>Entrega pequena: ${p.output}.</p></div></div>${d.roles.a===d.roles.b?'<p class="ru-tip">Vocês escolheram o mesmo papel. Cada um pode fazer uma versão pequena e depois comparar as ideias.</p>':'<p class="ru-tip">Papéis diferentes, um resultado em comum. Vocês podem trocar de papel na próxima rodada.</p>'}<button class="rp-button" data-duo-action="start">Começar nossa missão <span aria-hidden="true">↗</span></button></section></div>`}
function duoMission(){const d=duoState(),p=proposedProject(d.route,d.topic),done=duoComplete();return `<section class="ru-mission-heading"><span class="rp-overline">Rodada ${d.round} · um projeto em comum</span><h2>${p.title}</h2><p>Façam uma tentativa pequena, conversem e juntem as contribuições. Uma pausa não apaga o que vocês registraram.</p><div class="ru-flow"><span>01 · Cada um experimenta</span><span>02 · Vocês juntam as ideias</span><span>03 · Cada um conta como foi</span></div><details class="ru-scope"><summary>O que cabe neste primeiro teste?</summary><p>A proposta é ${p.output}. ${youthBuildSteps[d.route]}</p></details></section><div class="ru-people">${['a','b'].map((person,i)=>{const role=duoRoles[d.roles[person]],record=d.records[person];return `<section class="ru-person ru-task"><span class="ru-person-tag">${String(i+1).padStart(2,'0')} / CONTRIBUIÇÃO DE ${esc(duoName(person)).toUpperCase()}</span><div class="ru-task-title"><span><i data-lucide="${role.icon}" aria-hidden="true"></i></span><div><small>${esc(duoName(person))}, seu papel nesta rodada</small><h2>${role.title}</h2></div></div><p>${role.task}</p><label class="ru-done"><input type="checkbox" data-duo-done="${person}" ${record.done?'checked':''}><span>Fiz uma primeira tentativa e compartilhei com a outra pessoa.</span></label><fieldset class="ru-energy"><legend>Como foi esse papel para você?</legend>${Object.entries(energyLabels).map(([k,label])=>`<button data-duo-energy-person="${person}" data-duo-energy="${k}" aria-pressed="${record.energy===k}">${label}</button>`).join('')}</fieldset><label for="ru-note-${person}">Uma descoberta sua <span>(opcional)</span></label><textarea id="ru-note-${person}" data-duo-note="${person}" maxlength="1000" placeholder="Ex.: Gostei de pesquisar, mas preferi testar a ideia na prática…">${esc(record.note)}</textarea></section>`}).join('')}</div>${done?`<section class="ru-together"><span class="rp-overline">Uma criação. Dois olhares.</span><h2>Vocês podem gostar de partes diferentes.</h2><div class="ru-perspectives">${['a','b'].map(person=>`<div><strong>${esc(duoName(person))}</strong><small>${duoRoles[d.roles[person]].title}</small><p>${energyLabels[d.records[person].energy]}.</p>${d.records[person].note?`<p>“${esc(d.records[person].note)}”</p>`:''}</div>`).join('')}</div><p>Conversem sobre o que cada um repetiria. Esses registros mostram uma experiência, sem escolher uma profissão por vocês.</p><div class="rp-actions"><button class="rp-button" data-duo-action="save">Guardar o projeto da dupla ↗</button><button class="rp-button rp-secondary" data-duo-action="swap">Trocar papéis e tentar outra rodada ⇄</button></div></section>`:'<p class="ru-tip">Quando os dois marcarem a tentativa e escolherem como foi, a reflexão da dupla aparece aqui.</p>'}${d.rounds.length?`<details class="ru-history"><summary>Rodadas anteriores · ${d.rounds.length}</summary>${d.rounds.map(r=>`<article><h3>Rodada ${r.number}</h3>${['a','b'].map(person=>`<p><strong>${esc(duoName(person))}</strong> · ${duoRoles[r.roles[person]].title}: ${energyLabels[r.records[person].energy]}.${r.records[person].note?' '+esc(r.records[person].note):''}</p>`).join('')}</article>`).join('')}</details>`:''}<div class="rp-actions"><button class="rp-link" data-duo-action="new">${d.restartConfirm?'Confirmar nova missão — limpar esta missão':'Criar outra missão em dupla'}</button><button class="rp-link" data-act="home">Voltar à minha jornada</button></div>`}
function duoMissionAppView(){const d=duoState();return `<section class="ry-page ru-page"><div class="ru-intro"><div><span class="rp-overline">Rumo em dupla</span><h1>Dois jeitos de pensar.<br><em>Uma ideia para criar.</em></h1><p>Descubram como vocês se complementam fazendo um projeto juntos. Cada pessoa tem uma contribuição e um espaço para dizer como foi.</p></div><div class="ru-emblem" aria-hidden="true"><span><i data-lucide="sparkles"></i></span><b>+</b><span><i data-lucide="search"></i></span></div></div><div class="ru-mode-note"><i data-lucide="users-round" aria-hidden="true"></i><span>Duas pessoas, no mesmo dispositivo. Cada um registra seu próprio olhar sobre a experiência.</span></div>${d.phase==='setup'?duoSetup():duoMission()}</section>`}
function saveDuoCreation(){
 if(!duoComplete())return;
 const d=duoState(),p=proposedProject(d.route,d.topic),existing=youth.creations.find(c=>c.duoId===d.id);
 const rounds=[...d.rounds,{number:d.round,roles:{...d.roles},records:JSON.parse(JSON.stringify(d.records))}];
 const description=rounds.map(r=>`Rodada ${r.number}\n`+['a','b'].map(person=>`${duoName(person)} — ${duoRoles[r.roles[person]].title}\n${energyLabels[r.records[person].energy]}.${r.records[person].note?'\n'+r.records[person].note:''}`).join('\n\n')).join('\n\n');
 youth.editor={id:existing?.id||null,title:(p.title+' · em dupla').slice(0,120),description:description.slice(0,3000),url:existing?.url||'',image:existing?.image||'',type:'text',status:'done',feedbackRequested:existing?.feedbackRequested||false,route:d.route,topic:d.topic,projectId:d.id,duoId:d.id,error:''};
 navigate('creations');
}
root.addEventListener('click',event=>{
 const b=event.target.closest('button');if(!b||!root.contains(b))return;
 if(b.dataset.duoRolePerson){const d=duoState(),person=b.dataset.duoRolePerson;if(d.phase==='setup'&&['a','b'].includes(person)&&Object.hasOwn(duoRoles,b.dataset.duoRole)){d.roles[person]=b.dataset.duoRole;render()}return}
 if(b.dataset.duoTopic){const d=duoState();if(d.phase==='setup'&&Object.hasOwn(youthTopics,b.dataset.duoTopic)){d.topic=b.dataset.duoTopic;render()}return}
 if(b.dataset.duoRoute){const d=duoState();if(d.phase==='setup'&&Object.hasOwn(routes,b.dataset.duoRoute)){d.route=b.dataset.duoRoute;render()}return}
 if(b.dataset.duoEnergyPerson){const d=duoState(),person=b.dataset.duoEnergyPerson;if(d.phase==='mission'&&['a','b'].includes(person)&&Object.hasOwn(energyLabels,b.dataset.duoEnergy)){d.records[person].energy=b.dataset.duoEnergy;render()}return}
 switch(b.dataset.duoAction){
  case'start':{const d=duoState();if(d.phase!=='setup'||!duoQuizComplete()||!duoQuizState().applied)break;d.nameA=d.nameA.trim().slice(0,30);d.nameB=d.nameB.trim().slice(0,30);d.id='duo-'+youth.counter++;d.phase='mission';render();break;}
  case'save':saveDuoCreation();break;
  case'swap':{const d=duoState();if(!duoComplete())break;d.rounds.push({number:d.round,roles:{...d.roles},records:JSON.parse(JSON.stringify(d.records))});[d.roles.a,d.roles.b]=[d.roles.b,d.roles.a];d.records={a:newDuoRecord(),b:newDuoRecord()};d.round++;render();break;}
  case'new':{const d=duoState();if(!d.restartConfirm)d.restartConfirm=true;else youth.duo=newDuo();render();break;}
 }
});
root.addEventListener('input',event=>{
 if(event.target.dataset.duoName===undefined&&event.target.dataset.duoNote===undefined)return;
 const d=duoState();
 if(['a','b'].includes(event.target.dataset.duoName)&&d.phase==='setup'){d[event.target.dataset.duoName==='a'?'nameA':'nameB']=event.target.value.slice(0,30)}
 if(['a','b'].includes(event.target.dataset.duoNote)&&d.phase==='mission'){d.records[event.target.dataset.duoNote].note=event.target.value.slice(0,1000)}
});
root.addEventListener('change',event=>{const person=event.target.dataset.duoDone;if(['a','b'].includes(person)&&duoState().phase==='mission'){duoState().records[person].done=!!event.target.checked;render()}});

const DQ=(text,extra={})=>({text,...extra});
const duoQuestions=[
 {topic:'Uma curiosidade em comum',title:'Que projeto faria você querer começar com alguém?',hint:'Pense numa atividade que você teria vontade de experimentar com a outra pessoa.',options:[
  DQ('Criar uma história, música, imagem ou vídeo nosso.',{routes:{creative:3}}),DQ('Investigar uma dúvida de tecnologia, dados ou natureza.',{routes:{research:2,nature:2}}),DQ('Desenhar uma solução para um espaço ou uma entrega prática.',{routes:{build:3,freelance:2}}),DQ('Preparar algo ligado a aprendizagem, cuidado ou movimento.',{routes:{social:2,care:2}}),DQ('Organizar um evento, serviço ou uma ideia de negócio.',{routes:{enterprise:2,team:2,freelance:1}})
 ]},
 {topic:'Como cada um começa',title:'A ideia ainda está confusa. O que você faria primeiro na dupla?',hint:'Escolha o começo que parece mais natural para você, sem pensar no que seu amigo vai responder.',options:[
  DQ('Faço um rascunho para a gente enxergar a ideia.',{role:'create'}),DQ('Procuro referências e levanto algumas dúvidas.',{role:'research'}),DQ('Organizo o que precisa ser feito primeiro.',{role:'organize'}),DQ('Converso e tento explicar melhor a proposta.',{role:'present'}),DQ('Testo uma parte para ver se funciona.',{role:'test'})
 ]},
 {topic:'Discordar sem perder a parceria',title:'Vocês preferem soluções diferentes. Como você gostaria de decidir?',hint:'Imagine que as duas ideias fazem sentido. Escolha uma forma de comparar sem apagar a opinião de ninguém.',options:[
  DQ('Fazemos duas versões pequenas e comparamos.'),DQ('Combinamos critérios e escolhemos por eles.'),DQ('Cada um testa sua ideia numa rodada diferente.'),DQ('Buscamos uma referência antes de decidir.'),DQ('Conversamos até encontrar uma terceira ideia.')
 ]},
 {topic:'Responsabilidade na prática',title:'Perto da entrega, que parte você toparia assumir?',hint:'Pense no trabalho que você aceitaria cuidar, mesmo sem alguém precisar ficar cobrando.',options:[
  DQ('Revisar e testar o que já foi feito.',{role:'test'}),DQ('Organizar prioridades e combinar o que falta.',{role:'organize'}),DQ('Preparar a explicação ou apresentação do projeto.',{role:'present'}),DQ('Finalizar uma parte da criação.',{role:'create'}),DQ('Conferir informações, referências e dúvidas.',{role:'research'})
 ]},
 {topic:'O apoio que você oferece',title:'Seu amigo trava numa tarefa. Como você costuma tentar ajudar?',hint:'Escolha sua primeira atitude mais comum. Oferecer ajuda também pode começar por perguntar o que a pessoa precisa.',options:[
  DQ('Escuto o que aconteceu antes de sugerir algo.'),DQ('Mostro um exemplo para deixar mais claro.'),DQ('Faço o primeiro passo junto com a pessoa.'),DQ('Dou um tempo para ela pensar e depois retomo.'),DQ('Ajudo a combinar um próximo passo menor.')
 ]},
 {topic:'Um combinado justo',title:'Um de vocês tem menos tempo. Que acordo faria mais sentido?',hint:'Vocês não precisam fazer tudo igual. Pense numa divisão que os dois consigam cumprir e aceitar.',options:[
  DQ('Dividir tarefas de tamanhos diferentes conforme o tempo.'),DQ('Revezar as partes mais trabalhosas entre as rodadas.'),DQ('Diminuir a entrega para os dois conseguirem participar.'),DQ('Remarcar um momento em que os dois possam estar juntos.'),DQ('Fazer partes separadas e combinar quando juntar tudo.')
 ]},
 {topic:'Como falar de uma melhoria',title:'Que tipo de retorno ajuda você a melhorar sem desanimar?',hint:'Imagine a outra pessoa comentando seu trabalho. Escolha como você prefere receber essa conversa.',options:[
  DQ('Um exemplo concreto do que pode mudar.'),DQ('Primeiro entender o que funcionou, depois o que revisar.'),DQ('Uma conversa direta, mas com respeito.'),DQ('Um tempo para olhar sozinho antes de conversar.'),DQ('Uma pergunta para eu mesmo perceber o que ajustar.')
 ]},
 {topic:'O que vocês querem construir',title:'No final, o que faria esse projeto valer a pena para você?',hint:'Escolha o resultado que daria mais vontade de tentar de novo, mesmo num projeto pequeno.',options:[
  DQ('Ver uma criação ou um serviço nosso sendo reconhecido.',{routes:{creative:2,freelance:2}}),DQ('Ver uma solução técnica ou um espaço funcionando melhor.',{routes:{research:2,build:2}}),DQ('Perceber que ajudamos alguém a aprender ou se cuidar.',{routes:{social:2,care:2}}),DQ('Ver uma equipe, um evento ou um negócio funcionar.',{routes:{team:2,enterprise:2,freelance:1}}),DQ('Entender ou melhorar algo ligado ao ambiente e à natureza.',{routes:{nature:3,research:1}})
 ]},
 {topic:'O apoio que você precisa',title:'Quando você travar, que ajuda gostaria de receber da dupla?',hint:'Agora pense em você recebendo apoio. Pode ser diferente da ajuda que você costuma oferecer.',options:[
  DQ('Que a pessoa escute antes de tentar resolver.'),DQ('Que mostre um exemplo do que precisa ser feito.'),DQ('Que faça o primeiro passo comigo.'),DQ('Que me dê um tempo e depois volte a conversar.'),DQ('Que me ajude a escolher um passo menor.')
 ]},
 {topic:'Um primeiro teste que caiba',title:'Qual tamanho de teste cabe de verdade no seu momento?',hint:'Cada um responde pelo próprio tempo. Depois, vocês combinam como começar sem sobrecarregar ninguém.',options:[
  DQ('Uns 10 minutos juntos.',{minutes:10}),DQ('Uns 20 minutos juntos.',{minutes:20}),DQ('Uns 30 minutos juntos.',{minutes:30}),DQ('Dois encontros curtos, em momentos diferentes.'),DQ('Cada um faz uma parte no seu tempo e depois compartilhamos.')
 ]}
];
const newDuoQuiz=()=>({step:0,page:'questions',answers:{a:Array(10).fill(null),b:Array(10).fill(null)},roleChoices:{a:null,b:null},routeChoice:null,applied:false});
function duoQuizState(){return duoState().quiz??=newDuoQuiz()}
function duoQuizComplete(q=duoQuizState()){return ['a','b'].every(p=>q.answers[p].every((v,i)=>Number.isInteger(v)&&v>=-1&&v<duoQuestions[i].options.length))}
function duoQuizProfile(person){
 const q=duoQuizState(),routeScores=Object.fromEntries(Object.keys(routes).map(k=>[k,0])),roleKeys=[];
 [0,7].forEach(i=>{const option=duoQuestions[i].options[q.answers[person][i]];for(const [k,v] of Object.entries(option?.routes||{}))routeScores[k]+=v});
 [1,3].forEach(i=>{const role=duoQuestions[i].options[q.answers[person][i]]?.role;if(role&&!roleKeys.includes(role))roleKeys.push(role)});
 return {routeScores,roleKeys};
}
function duoSharedPaths(){
 const a=duoQuizProfile('a'),b=duoQuizProfile('b');
 return Object.keys(routes).filter(k=>a.routeScores[k]>0&&b.routeScores[k]>0).sort((x,y)=>Math.min(a.routeScores[y],b.routeScores[y])-Math.min(a.routeScores[x],b.routeScores[x])||a.routeScores[y]+b.routeScores[y]-a.routeScores[x]-b.routeScores[x]);
}
function duoAnswer(person,i){const value=duoQuizState().answers[person][i];return value===-1?'Ainda não sei':duoQuestions[i].options[value]?.text||'Ainda sem resposta'}
function initializeDuoSuggestions(){const q=duoQuizState();for(const p of ['a','b']){const keys=duoQuizProfile(p).roleKeys;if(!q.roleChoices[p]&&keys.length===1)q.roleChoices[p]=keys[0]}}
function duoQuizCanApply(){const q=duoQuizState();return duoQuizComplete()&&Object.hasOwn(routes,q.routeChoice)&&['a','b'].every(p=>Object.hasOwn(duoRoles,q.roleChoices[p]))}
function duoTimeSuggestion(){
 const q=duoQuizState(),a=duoQuestions[9].options[q.answers.a[9]]?.minutes,b=duoQuestions[9].options[q.answers.b[9]]?.minutes;
 return a&&b?`Como primeira tentativa, vocês podem começar pelo bloco mais curto informado: ${Math.min(a,b)} minutos. Ajustem esse combinado juntos.`:'Combinem o tempo antes de começar. As respostas de vocês podem pedir encontros curtos, partes separadas ou outro acordo.';
}
function cleanDuoQuiz(value){
 const clean=newDuoQuiz();if(!value||typeof value!=='object')return clean;
 clean.step=Number.isInteger(value.step)?Math.max(0,Math.min(9,value.step)):0;
 for(const p of ['a','b']){clean.answers[p]=Array.from({length:10},(_,i)=>{const v=value.answers?.[p]?.[i];return Number.isInteger(v)&&v>=-1&&v<5?v:null});clean.roleChoices[p]=Object.hasOwn(duoRoles,value.roleChoices?.[p])?value.roleChoices[p]:null}
 clean.routeChoice=Object.hasOwn(routes,value.routeChoice)?value.routeChoice:null;
 clean.page=['questions','overview','result','setup'].includes(value.page)?value.page:'questions';
 clean.applied=!!value.applied&&duoQuizComplete(clean)&&!!clean.routeChoice&&['a','b'].every(p=>!!clean.roleChoices[p]);
 if(!duoQuizComplete(clean)&&['result','setup'].includes(clean.page))clean.page='questions';
 return clean;
}

function duoQuizNames(){const d=duoState();return `<details class="dq-names"><summary>Quem está nessa dupla? <span>${esc(duoName('a'))} + ${esc(duoName('b'))}</span></summary><div>${['a','b'].map((p,i)=>`<label for="dq-name-${p}">Pessoa ${i+1} <small>(nome opcional)</small><input id="dq-name-${p}" data-duo-name="${p}" maxlength="30" value="${esc(p==='a'?d.nameA:d.nameB)}" placeholder="Como podemos chamar você?"></label>`).join('')}</div></details>`}
function duoQuizQuestionView(){
 const q=duoQuizState(),question=duoQuestions[q.step],ready=['a','b'].every(p=>q.answers[p][q.step]!==null);
 return `<section class="ry-page dq-page"><button class="rp-home-back" data-act="home"><span aria-hidden="true">←</span> Voltar ao início</button><div class="dq-intro"><div><span class="rp-overline">Rumo em dupla · conhecer os dois jeitos</span><h1>Uma conversa a dois.<br><em>Cada resposta tem seu espaço.</em></h1><p>São dez situações para entender como vocês querem criar juntos. Cada pessoa escolhe a própria resposta.</p></div><i data-lucide="users-round" aria-hidden="true"></i></div>${duoQuizNames()}<div class="rp-step-meta"><span>CONHECER A PARCERIA</span><span>${q.step+1} de 10</span></div><div class="rp-track" role="progressbar" aria-label="Posição no questionário da dupla" aria-valuenow="${q.step+1}" aria-valuemin="0" aria-valuemax="10"><span style="width:${(q.step+1)*10}%"></span></div><span class="rp-overline">${question.topic}</span><h2 class="dq-question-title">${question.title}</h2><p class="dq-question-hint">${question.hint}</p><div class="dq-answers">${['a','b'].map((p,index)=>{const answer=q.answers[p][q.step];return `<section class="dq-person"><div class="dq-person-head"><span>${String(index+1).padStart(2,'0')}</span><div><strong>${esc(duoName(p))}</strong><small>${answer===null?'Sua resposta ainda está em aberto':'Resposta escolhida ✓'}</small></div></div><div class="dq-options" role="group" aria-label="Resposta de ${esc(duoName(p))}">${question.options.map((o,i)=>`<button data-dq-person="${p}" data-dq-option="${i}" aria-pressed="${answer===i}"><span class="dq-check" aria-hidden="true">${answer===i?'✓':''}</span><span>${o.text}</span></button>`).join('')}</div><button class="rp-skip" data-dq-person="${p}" data-dq-option="-1" aria-pressed="${answer===-1}">${answer===-1?'✓ ':''}Ainda não sei / nenhuma opção me representa</button></section>`}).join('')}</div><div class="dq-question-footer"><button class="rp-button rp-quiet" data-dq-action="back" ${q.step===0?'disabled':''}>← Pergunta anterior</button><span>${ready?'As duas respostas estão aqui. Podem seguir.':'Cada pessoa responde por si. As duas respostas liberam o próximo passo.'}</span><button class="rp-button" data-dq-action="next" ${!ready?'disabled':''}>${q.step===9?'Ver nosso ponto de partida':'Próxima pergunta'} →</button></div><button class="rp-link" data-dq-action="overview">Ver as dez perguntas da dupla</button></section>`;
}
function duoQuizOverview(){const d=duoState(),q=duoQuizState(),readOnly=d.phase==='mission';return `<section class="ry-page"><span class="rp-overline">Questionário da dupla · visão completa</span><h1>Dez situações.<br><em>Dois pontos de vista.</em></h1><p>As perguntas falam da parceria, das tarefas e dos combinados. As respostas da jornada individual continuam separadas.</p><button class="rp-button rp-secondary" data-dq-action="${readOnly||duoQuizComplete()?'result':'resume'}">${readOnly||duoQuizComplete()?'Voltar ao ponto de partida da dupla':'Continuar nossas respostas'} →</button><div class="rp-questions">${duoQuestions.map((question,i)=>`<details><summary><span class="rp-q-number">${String(i+1).padStart(2,'0')}</span>${question.title}</summary><p>${question.hint}</p><ul>${question.options.map((option,j)=>`<li>${option.text}${['a','b'].filter(p=>q.answers[p][i]===j).map(p=>` <small class="dq-choice-name">${esc(duoName(p))}</small>`).join('')}</li>`).join('')}<li>Ainda não sei / nenhuma opção me representa.</li></ul>${!readOnly?`<button class="rp-button rp-quiet rp-q-edit" data-dq-jump="${i}">${['a','b'].every(p=>q.answers[p][i]!==null)?'Rever respostas':'Responder esta pergunta'}</button>`:''}</details>`).join('')}</div></section>`}
function duoQuizRoleChoice(person,readOnly){const q=duoQuizState(),profile=duoQuizProfile(person),selected=readOnly?duoState().roles[person]:q.roleChoices[person];return `<section class="dq-role-result"><h3>${esc(duoName(person))}</h3><p>${profile.roleKeys.length?'Nas respostas sobre começar e finalizar, você citou: '+profile.roleKeys.map(k=>duoRoles[k].title.toLowerCase()).join(' e ')+'.':'Você ainda não indicou um papel nessas respostas. Pode escolher um para experimentar.'}</p><div class="dq-role-chips" role="group" aria-label="Papel de ${esc(duoName(person))}">${Object.entries(duoRoles).map(([k,r])=>`<button data-dq-role-person="${person}" data-dq-role="${k}" aria-pressed="${selected===k}" ${readOnly?'disabled':''}>${r.title}</button>`).join('')}</div></section>`}
function duoQuizAgreements(readOnly){const items=[{title:'Como decidir juntos',index:2,tip:'Se as respostas forem diferentes, escolham um jeito de decidir que os dois aceitem.'},{title:'Como dividir o esforço',index:5,tip:'O combinado pode respeitar tempos diferentes sem deixar uma pessoa responsável por tudo.'},{title:'Como conversar sobre melhorias',index:6,tip:'Ao comentar o trabalho do outro, levem em conta como essa pessoa prefere receber retorno.'},{title:'O apoio que cada um precisa',index:8,tip:'A ajuda que você oferece nem sempre é a mesma que a outra pessoa quer receber.'}];return `<div class="dq-agreements">${items.map(item=>`<article><h3>${item.title}</h3>${['a','b'].map(p=>`<p><strong>${esc(duoName(p))}:</strong> ${duoAnswer(p,item.index)}</p>`).join('')}<small>${item.tip}</small>${!readOnly?`<button class="rp-link" data-dq-jump="${item.index}">Rever esse combinado →</button>`:''}</article>`).join('')}</div><details class="dq-support"><summary>O apoio que cada um costuma oferecer</summary>${['a','b'].map(p=>`<p><strong>${esc(duoName(p))}:</strong> ${duoAnswer(p,4)}</p>`).join('')}</details>`}
function duoQuizResult(){
 if(!duoQuizComplete())return duoQuizQuestionView();
 const d=duoState(),q=duoQuizState(),shared=duoSharedPaths(),readOnly=d.phase==='mission',keys=shared.length?shared.slice(0,3):Object.keys(routes);
 return `<section class="ry-page dq-result"><span class="rp-overline">O ponto de partida da dupla</span><h1>Dois jeitos de pensar.<br><em>Um começo para combinar.</em></h1><p>As respostas trazem preferências para uma primeira experiência. Vocês podem ajustar os papéis e mudar de ideia depois de testar.</p><section class="dq-result-section"><div class="ry-heading"><div><h2>${shared.length?'Onde há curiosidades dos dois':'Escolham uma curiosidade para testar'}</h2><p>${shared.length?'Estes caminhos apareceram nas respostas de interesse das duas pessoas. Eles não definem uma profissão.':'Ainda não apareceu um caminho com sinais dos dois. Vocês podem escolher uma ideia pequena ou experimentar duas áreas antes de decidir.'}</p></div>${!readOnly?'<button class="rp-link" data-dq-jump="0">Rever interesses</button>':''}</div><div class="dq-paths">${keys.map(k=>`<article class="${q.routeChoice===k?'dq-picked':''}"><span class="rp-overline">${shared.includes(k)?'Pistas das duas pessoas':'Uma possibilidade para explorar'}</span><h3>${routes[k].title}</h3><p>${routes[k].desc}</p><button class="rp-button rp-secondary" data-dq-route="${k}" ${readOnly?'disabled':''}>${q.routeChoice===k?'Caminho escolhido ✓':'Escolher este caminho'}</button></article>`).join('')}</div>${shared.length?`<details class="ry-route-picker"><summary>Vocês podem escolher outro caminho <span aria-hidden="true">⌄</span></summary><div class="ry-route-options">${Object.entries(routes).map(([k,r])=>`<button data-dq-route="${k}" aria-pressed="${q.routeChoice===k}" ${readOnly?'disabled':''}>${r.title}</button>`).join('')}</div></details>`:''}<p class="dq-selection">${q.routeChoice?'Caminho escolhido: '+routes[q.routeChoice].title:'Escolham um caminho para preparar a missão.'}</p></section><section class="dq-result-section"><h2>Papéis para a primeira tentativa.</h2><p>${q.roleChoices.a&&q.roleChoices.a===q.roleChoices.b?'Vocês se interessaram pelo mesmo papel. Podem fazer duas versões pequenas ou revezar entre as rodadas.':'Escolham o que cada um quer experimentar. Dois papéis diferentes são uma possibilidade, não uma obrigação.'}</p><div class="dq-role-results">${['a','b'].map(p=>duoQuizRoleChoice(p,readOnly)).join('')}</div></section><section class="dq-result-section"><h2>Antes de começar, combinem estas partes.</h2>${duoQuizAgreements(readOnly)}</section><section class="dq-time"><span class="rp-overline">O tamanho da primeira tentativa</span>${['a','b'].map(p=>`<p><strong>${esc(duoName(p))}:</strong> ${duoAnswer(p,9)}</p>`).join('')}<p>${duoTimeSuggestion()}</p></section><div class="dq-apply">${readOnly?'<button class="rp-button" data-dq-action="mission">Voltar para nossa missão →</button>':`<button class="rp-button" data-dq-action="apply" ${!duoQuizCanApply()?'disabled':''}>Preparar nossa missão →</button><small>${duoQuizCanApply()?'Vocês poderão escolher o tema e ajustar os papéis antes de começar.':'Escolham um caminho e um papel para cada pessoa.'}</small>`}<button class="rp-link" data-dq-action="overview">Ver as dez perguntas</button></div></section>`;
}
function duoView(){
 const d=duoState(),q=duoQuizState();
 if(q.page==='overview')return duoQuizOverview();
 if(q.page==='result')return duoQuizResult();
 if(d.phase==='mission')return `<div class="dq-mission-bar"><span>Os combinados da dupla continuam com vocês.</span><button class="rp-link" data-dq-action="result">Ver respostas da dupla →</button></div>`+duoMissionAppView();
 if(q.applied&&q.page==='setup')return `<div class="dq-mission-bar"><span>Vocês responderam às dez perguntas. Agora, deem forma ao projeto.</span><button class="rp-link" data-dq-action="result">Rever nosso ponto de partida →</button></div>`+duoMissionAppView();
 return duoQuizQuestionView();
}

root.addEventListener('click',event=>{
 const b=event.target.closest('button');if(!b||!root.contains(b))return;
 if(b.dataset.dqOption!==undefined){
  const d=duoState(),q=duoQuizState(),p=b.dataset.dqPerson,v=Number(b.dataset.dqOption);
  if(d.phase!=='setup'||!['a','b'].includes(p)||!Number.isInteger(v)||v< -1||v>=5)return;
  q.answers[p][q.step]=v;q.applied=false;
  if([1,3].includes(q.step))q.roleChoices[p]=null;
  if([0,7].includes(q.step))q.routeChoice=null;
  render();return;
 }
 if(b.dataset.dqJump!==undefined){const d=duoState(),q=duoQuizState(),i=Number(b.dataset.dqJump);if(d.phase==='setup'&&Number.isInteger(i)&&i>=0&&i<10){q.step=i;q.page='questions';render()}return}
 if(b.dataset.dqRoute){if(duoState().phase==='setup'&&duoQuizComplete()&&Object.hasOwn(routes,b.dataset.dqRoute)){duoQuizState().routeChoice=b.dataset.dqRoute;render()}return}
 if(b.dataset.dqRolePerson){const p=b.dataset.dqRolePerson;if(duoState().phase==='setup'&&duoQuizComplete()&&['a','b'].includes(p)&&Object.hasOwn(duoRoles,b.dataset.dqRole)){duoQuizState().roleChoices[p]=b.dataset.dqRole;render()}return}
 if(b.dataset.duoRolePerson&&duoQuizState().applied)duoQuizState().roleChoices[b.dataset.duoRolePerson]=duoState().roles[b.dataset.duoRolePerson];
 if(b.dataset.duoRoute&&duoQuizState().applied)duoQuizState().routeChoice=duoState().route;
 switch(b.dataset.dqAction){
  case'next':{const d=duoState(),q=duoQuizState();if(d.phase!=='setup'||!['a','b'].every(p=>q.answers[p][q.step]!==null))break;if(q.step<9)q.step++;else{const missing=duoQuestions.findIndex((_,i)=>['a','b'].some(p=>q.answers[p][i]===null));if(missing>=0)q.step=missing;else{initializeDuoSuggestions();q.page='result'}}render();break;}
  case'back':{const q=duoQuizState();if(duoState().phase==='setup'&&q.step>0){q.step--;q.page='questions';render()}break;}
  case'overview':duoQuizState().page='overview';render();break;
  case'resume':{const q=duoQuizState();q.page='questions';const missing=duoQuestions.findIndex((_,i)=>['a','b'].some(p=>q.answers[p][i]===null));q.step=missing>=0?missing:0;render();break;}
  case'result':{const q=duoQuizState();if(duoQuizComplete()){initializeDuoSuggestions();q.page='result'}else q.page='questions';render();break;}
  case'apply':{const d=duoState(),q=duoQuizState();if(d.phase!=='setup'||!duoQuizCanApply())break;d.roles={...q.roleChoices};d.route=q.routeChoice;q.applied=true;q.page='setup';render();break;}
  case'mission':if(duoState().phase==='mission'){duoQuizState().page='setup';render()}break;
 }
});

const upDetails={
 team:['Organizar pessoas e entregas','Administração · logística · atendimento','Acompanhar prazos, organizar informações e conversar com equipes ou clientes.','Monte o planejamento de um pequeno evento com tarefas, responsáveis e prazo.','Combine três tarefas com alguém e observe se gostou de acompanhar a execução.'],
 enterprise:['Transformar um problema em proposta','Criação de negócios · operações · vendas','Ouvir um público, testar uma solução e ajustar custos e comunicação.','Desenhe um serviço que resolva uma dificuldade de estudantes.','Converse com uma pessoa sobre o problema antes de criar a solução.'],
 creative:['Dar forma a ideias','Design gráfico · produção audiovisual · escrita','Pesquisar referências, criar versões, receber comentários e revisar projetos.','Crie um cartaz, um roteiro ou um trecho de música sobre um tema seu.','Faça um rascunho e peça a alguém para dizer o que entendeu.'],
 research:['Investigar e testar soluções','Programação · análise de dados · pesquisa','Formular perguntas, examinar dados, montar testes e corrigir erros.','Desenhe as telas de um app ou organize uma pequena tabela de dados.','Escolha um problema e escreva uma hipótese que consiga testar.'],
 freelance:['Fazer uma entrega prática','Manutenção · produção · serviços técnicos','Entender um pedido, preparar materiais, executar e conferir a entrega.','Escreva um passo a passo ilustrado para uma tarefa que você domina.','Teste seu passo a passo com alguém, sem usar ferramentas ou equipamentos de risco.'],
 social:['Ajudar pessoas a aprender e participar','Educação · projetos sociais · formação','Preparar atividades, escutar necessidades e adaptar explicações a públicos diferentes.','Crie uma explicação curta ou uma atividade sobre algo que você sabe.','Explique um assunto a alguém e descubra onde sua explicação precisa melhorar.'],
 build:['Pensar espaços e estruturas','Engenharia · arquitetura · planejamento de espaços','Interpretar necessidades, desenhar alternativas, calcular e revisar projetos com equipes.','Desenhe uma melhoria conceitual para um espaço conhecido.','Observe um ambiente e esboce duas soluções, sem fazer obras ou intervenções.'],
 care:['Entender cuidado e bem-estar','Enfermagem · fisioterapia · educação física','Estudar necessidades, trabalhar em equipe e acompanhar pessoas com responsabilidade.','Monte um painel sobre a rotina de uma profissão de cuidado.','Liste perguntas para conhecer a profissão; não prescreva treinos ou tratamentos.'],
 nature:['Observar e cuidar do ambiente','Biologia · gestão ambiental · agronomia','Observar sistemas naturais, registrar informações e planejar ações com critérios técnicos.','Faça um registro fotográfico de plantas ou de resíduos em um espaço.','Observe sem coletar nem tocar em animais e anote uma pergunta para investigar.']};
function upState(){return youth.upgrades??={minutes:20,reflections:{}}}
let upRoute=null,upPanel='paths',upCopy=false;
function upKey(){return routeChosen?activeRoute:null}
function upTimePanel(){const m=upState().minutes;return `<section class="up-time"><span class="rp-overline">Cabe no seu dia</span><h2>Quanto tempo você tem agora?</h2><div class="up-options">${[10,20,30].map(n=>`<button data-up-minutes="${n}" aria-pressed="${m===n}">${n} min</button>`).join('')}</div><p>${m===10?'Faça só uma parte da tarefa: 2 min para escolher o recorte, 6 min para tentar e 2 min para anotar uma descoberta.':m===20?'Escolha um recorte em 3 min, experimente por 12 min e use os últimos 5 min para revisar e registrar.':'Prepare o recorte em 5 min, experimente por 20 min e registre o que percebeu nos últimos 5 min.'}</p><small>É uma sugestão de divisão do tempo, sem cronômetro obrigatório. Você pode parar e continuar depois.</small></section>`}
function upReflection(){const k=upKey();if(!k)return `<section class="up-box"><h2>Sua experiência vem primeiro.</h2><p>Escolha um caminho e registre uma tentativa no plano. Depois, volte para pensar no que gostaria de repetir.</p><button class="rp-button" data-up-panel="paths">Conhecer os caminhos →</button></section>`;const days=routineState[k].days.filter(d=>d.registered),r=upState().reflections[k];return `<section class="up-box"><span class="rp-overline">${routes[k].title} · ${days.length} registros</span><h2>Gostou ou foi diferente do que imaginava?</h2>${days.length?`<div class="up-records">${days.slice(-3).map(d=>`<p><strong>${esc(moodLabels[d.mood]||'Experiência registrada')}</strong>${d.note?' · '+esc(d.note):''}</p>`).join('')}</div><p>O que você quer fazer a partir dessa experiência?</p><div class="up-options">${[['continue','Quero continuar'],['adapt','Quero adaptar'],['change','Quero testar outra área']].map(([v,t])=>`<button data-up-reflect="${v}" aria-pressed="${r===v}">${t}</button>`).join('')}</div>${r?`<p class="up-response">${{continue:'Repita uma parte que deu vontade de continuar e aumente só um pouco o desafio.',adapt:'Mude uma coisa: o tamanho, o apoio ou o formato do projeto. Uma dificuldade não define sua capacidade.',change:'Você pode comparar outro caminho sem apagar o que já descobriu.'}[r]}</p><button class="rp-button" ${r==='change'?'data-y-nav="compare"':'data-route="'+k+'"'}>${r==='change'?'Comparar caminhos':'Voltar ao meu plano'} →</button>`:''}`:`<p>Você ainda não registrou uma experiência nessa área. Faça uma tentativa pequena antes de decidir com base na prática.</p><button class="rp-button" data-route="${k}">Abrir meu plano →</button>`}</section>`}
function upJourneyText(){const lines=['RUMO — MINHA JORNADA','Caminho escolhido: '+(upKey()?routes[upKey()].title:'Indefinido'),'Tempo preferido: '+upState().minutes+' minutos','','MINHAS RESPOSTAS'];questions.forEach((q,i)=>lines.push((i+1)+'. '+(q.title||q.question||q.text||'Pergunta '+(i+1))+'\n'+(answers[i]===null?'Não respondida':answers[i]===-1?'Ainda não sei':(q.options[answers[i]]?.text||q.options[answers[i]]?.label||JSON.stringify(q.options[answers[i]])))));lines.push('','MEU MAPA',complete()?(getProfile().clear?'Primeira possibilidade: '+routes[getProfile().top].title:'Sem uma indicação única. Compare os caminhos.'):'Questionário ainda incompleto. Caminho não definido pelo mapa.');lines.push('','MINHAS REFLEXÕES');Object.entries(upState().reflections).forEach(([k,v])=>lines.push(routes[k].title+': '+({continue:'Quero continuar',adapt:'Quero adaptar',change:'Quero testar outra área'}[v]||v)));lines.push('','EXPERIÊNCIAS');Object.entries(routineState).forEach(([k,rs])=>rs.days.forEach((d,i)=>{if(d.registered)lines.push(routes[k].title+' · Dia '+(i+1)+' · '+(moodLabels[d.mood]||'')+'\n'+d.note)}));lines.push('','MINHAS CRIAÇÕES');youth.creations.forEach(c=>lines.push(c.title+'\n'+(c.description||'')+'\n'+(c.url||'')));lines.push('','O mapa é exploratório e não define aptidão ou profissão.','Esta cópia de leitura não restaura os dados no aplicativo. Imagens não são incluídas.');return lines.join('\n')}
function upSaveView(){return `<section class="up-box"><span class="rp-overline">Leve suas descobertas</span><h2>Sua jornada também pode ir com você.</h2><p>Guarde uma cópia em texto das respostas, caminho escolhido, experiências e descrições das suas criações.</p><button class="rp-button" data-up-download="true">Baixar minha jornada (.txt) ↓</button><button class="rp-link" data-up-copy="true">Ver texto para copiar</button><p class="ry-fine">Não inclui imagens nem restaura o app. Nada é enviado automaticamente.</p>${upCopy?`<label for="up-copy">Selecione e copie sua jornada</label><textarea id="up-copy" readonly rows="12">${esc(upJourneyText())}</textarea>`:''}</section>`}
function upPaths(){if(upRoute){const k=upRoute,d=upDetails[k];return `<button class="rp-link" data-up-back="true">← Todos os caminhos</button><section class="up-detail"><span class="rp-overline">Conheça esse caminho</span><h1>${routes[k].title}</h1><p>${d[0]}.</p><div class="up-detail-grid"><article class="up-box"><span class="rp-overline">Algumas possibilidades</span><h2>${d[1]}</h2><p>Exemplos de atuações para investigar. Algumas exigem formação específica.</p><h3>Como pode ser o dia a dia</h3><p>${d[2]}</p></article><article class="up-box"><span class="rp-overline">Do interesse à prática</span><h2>Um projeto para começar</h2><p>${d[3]}</p><h3>Uma primeira tentativa</h3><p>${d[4]}</p><button class="rp-button" data-route="${k}">Experimentar esse caminho →</button></article></div>${experimentWeekPreview(k)}<p class="ry-fine">Conhecer esta página não muda seu mapa. Escolher experimentar abre o plano dessa área.</p></section>`}return `<span class="rp-overline">Conheça esse caminho</span><h1>Além do nome da área.<br><em>Descubra o que dá para fazer.</em></h1><p>Veja exemplos do dia a dia e projetos para experimentar. Seu caminho segue ${upKey()?routes[upKey()].title:'indefinido'} até você escolher.</p><div class="up-path-grid">${Object.entries(upDetails).map(([k,d])=>`<article class="up-box"><span class="rp-overline">${routeKinds[k]||'Possibilidades'}</span><h2>${routes[k].title}</h2><p>${d[0]}.</p><small>${d[1]}</small><button class="rp-link" data-up-route="${k}">Conhecer esse caminho ↗</button></article>`).join('')}</div>`}
function upgradesView(){return `<section class="up-page"><button class="rp-link" data-act="home">← Início</button>${upPanel==='paths'?upPaths():upPanel==='reflect'?upReflection():upPanel==='time'?`${upTimePanel()}<p>Esse tempo será usado ao abrir a tarefa do dia.</p>${routeChosen?`<button class="rp-button" data-route="${activeRoute}">Abrir meu plano →</button>`:'<button class="rp-link" data-up-panel="paths">Escolher um caminho →</button>'}`:upSaveView()}</section>`}
function render(){if(view==='settings'){stage.innerHTML=settingsView();root.dataset.screen=view;refreshDrawer();refreshNextAvailability();if(typeof lucide!=='undefined')lucide.createIcons();if(hostingReady)scheduleHostedSave();return;}if(view==='mentor'){stage.innerHTML=mentorView();root.dataset.screen=view;refreshDrawer();refreshNextAvailability();if(typeof lucide!=='undefined')lucide.createIcons();if(hostingReady)scheduleHostedSave();return;}if(view==='upgrades'){stage.innerHTML=upgradesView();root.dataset.screen=view;refreshDrawer();refreshNextAvailability();}else{renderCore();}if(['routine','today','passport'].includes(view))stage.insertAdjacentHTML('beforeend','<button class="rp-button rp-secondary" data-mentor-open="true">Pedir feedback ao Mentor ↗</button>');if(['routine','today','passport'].includes(view))stage.insertAdjacentHTML('beforeend','<div class="rp-actions"><button class="rp-button rp-secondary" data-up-panel="reflect">Rever o que descobri →</button><button class="rp-link" data-up-panel="save">Guardar minha jornada ↓</button></div>');if(typeof lucide!=='undefined')lucide.createIcons();if(hostingReady)scheduleHostedSave();}
root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||!root.contains(b))return;const d=b.dataset;
 if(d.upPanel){upPanel=d.upPanel;upRoute=null;closeMenu();view='upgrades';render();return}
 if(d.upRoute&&Object.hasOwn(upDetails,d.upRoute)){upRoute=d.upRoute;view='upgrades';render();return}
 if(d.upBack){upRoute=null;render();return}
 if(d.upMinutes){const m=Number(d.upMinutes);if([10,20,30].includes(m))upState().minutes=m;render();return}
 if(d.upReflect&&upKey()&&routineState[upKey()].days.some(x=>x.registered)&&['continue','adapt','change'].includes(d.upReflect)){upState().reflections[upKey()]=d.upReflect;render();return}
 if(d.upCopy){upCopy=true;render();return}
 if(d.upDownload){try{const blob=new Blob([upJourneyText()],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Minha_Jornada_Rumo.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}catch{upCopy=true;render();}return}
});

function todayView(){return upTimePanel()+todayCoreView().replace(/<div class="rd-metadata">[\s\S]*?<\/div>/,`<div class="rd-metadata"><span>${upState().minutes} minutos sugeridos</span><span>Faça só o recorte que cabe hoje</span></div>`);}

// Each entry: concrete activity, observable result, reflection prompt.
const experimentalWeeks={
 creative:[
 ['Uma ideia, dois formatos','Escolha um assunto seu. Faça um título com três frases e depois um rascunho visual para a mesma mensagem.','Foi mais interessante escrever ou pensar em imagens?'],
 ['Monte uma história em três cenas','No papel, desenhe ou descreva começo, mudança e final de uma história de 15 segundos. Não precisa gravar.','Você gostou de criar a história ou de organizar a sequência?'],
 ['Brinque com som e ritmo','Escreva quatro versos ou crie um ritmo curto com palmas. Faça duas versões mudando o clima.','Como foi transformar uma sensação em uma criação?'],
 ['Mude a intenção do projeto','Pegue um rascunho seu e adapte para outro público: crianças, colegas ou adultos. Mude palavras, cores ou ritmo.','O desafio de comunicar para outra pessoa te interessou?'],
 ['Resolva uma limitação criativa','Crie um mini cartaz só com duas cores ou um texto com até 30 palavras. Escolha uma das restrições.','A limitação trouxe ideias ou atrapalhou sua vontade de criar?'],
 ['Teste o que sua criação comunica','Mostre um rascunho a alguém, se quiser, e pergunte qual mensagem percebeu. Ou reveja depois de uma pausa. Ajuste um detalhe.','Você gostou de revisar ou preferiu inventar algo novo?'],
 ['Escolha sua próxima linguagem','Reúna seus testes de escrita, imagem e som. Marque um para repetir e monte uma versão pequena dele.','Qual linguagem você quer explorar mais e qual deixaria de lado por enquanto?']],
 research:[
 ['Encontre um problema de uso','Escolha um aplicativo que usa. Desenhe as etapas de uma tarefa e marque onde alguém poderia se confundir.','Você gostou de investigar o problema antes de propor uma solução?'],
 ['Faça dados contarem uma história','Anote cinco dados não pessoais, como duração de músicas ou preços de itens. Organize e encontre uma diferença.','Comparar dados despertou curiosidade ou pareceu cansativo?'],
 ['Programe no papel','Escreva instruções para separar uma lista por uma regra. Simule três entradas, incluindo uma que não serve.','Foi interessante pensar em regras e exceções?'],
 ['Desenhe uma solução clicável no papel','Desenhe três telas para resolver o problema do primeiro teste. Ligue os botões às telas com setas.','Você gostou mais de descobrir o problema ou de montar a solução?'],
 ['Procure um erro de propósito','Execute as instruções do terceiro teste literalmente. Encontre uma ambiguidade e escreva uma correção.','Como foi buscar e corrigir um erro sem abandonar a ideia?'],
 ['Teste sua hipótese','Peça a alguém para seguir suas telas de papel ou simule você mesmo um uso diferente. Anote onde o fluxo falhou.','Observar o uso mudou sua ideia inicial?'],
 ['Escolha entre dados, lógica e produto','Compare a tabela, as instruções e as telas. Melhore só o teste que mais despertou sua curiosidade.','Qual dessas atividades você repetiria sem precisar de uma nota?']],
 team:[
 ['Organize uma entrega pequena','Escolha uma tarefa da sua semana. Divida em três ações com prazo e uma ordem de execução.','Você gostou de transformar uma tarefa confusa em um plano?'],
 ['Simule um atendimento','Imagine um cliente que recebeu um item diferente do pedido. Escreva uma resposta que esclareça o problema e proponha um próximo passo.','Escutar e encaminhar um problema parece interessante para você?'],
 ['Faça um controle de recursos','Monte uma tabela com cinco materiais de uma atividade fictícia: quantidade disponível, necessária e o que falta.','Você teve vontade de conferir os detalhes e evitar faltas?'],
 ['Resolva um choque de prazos','Duas ações do primeiro teste precisam acontecer no mesmo horário. Reorganize o plano e justifique uma prioridade.','Como foi negociar prioridades em vez de fazer tudo ao mesmo tempo?'],
 ['Explique uma proposta de compra','Compare duas opções fictícias de um mesmo item usando preço, durabilidade e necessidade. Escreva sua indicação sem inventar vantagens.','Você gostou de comparar opções e explicar uma escolha?'],
 ['Coordene uma tarefa em simulação','Distribua três tarefas entre duas pessoas fictícias e você. Defina como cada pessoa avisaria que terminou.','Acompanhar o trabalho das pessoas te atrai mais que executar sozinho?'],
 ['Encontre seu tipo de organização','Compare atendimento, controle de recursos e coordenação. Refine um desses testes e guarde o resultado.','Qual função você quer experimentar em uma situação real?']],
 enterprise:[
 ['Caçe uma dificuldade concreta','Anote três pequenas dificuldades que percebe na escola ou no cotidiano. Escolha uma e descreva quem a enfrenta, sem supor a solução.','Você sentiu curiosidade pelo problema ou só pela ideia de vender?'],
 ['Investigue sem oferecer nada','Se puder, pergunte a alguém como lida com essa dificuldade. Sem conversa disponível, separe o que você observou do que está supondo.','Que suposição sua precisaria ser conferida?'],
 ['Desenhe uma oferta em uma folha','Escreva para quem seria a solução, o que ela entrega e o que fica de fora. Não precisa vender nem publicar.','Você gostou de transformar o problema em uma proposta?'],
 ['Veja se a conta faz sentido','Use valores fictícios: liste três custos e um preço possível. Calcule o que sobraria antes de outras despesas.','Lidar com custos te deu vontade de investigar mais?'],
 ['Simule a entrega','Represente o serviço em três passos ou desenhe uma amostra do produto. Marque a etapa mais difícil de executar.','Você gostou da execução além de imaginar o negócio?'],
 ['Teste uma objeção','Imagine que alguém diga “não preciso disso”. Escreva duas perguntas para entender o motivo e ajuste a proposta.','Você consegue ter curiosidade pelo retorno sem tentar convencer a qualquer custo?'],
 ['Decida o que ainda precisa testar','Reúna problema, proposta, custos e amostra. Escolha a maior dúvida e planeje um teste sem gasto.','O que te atraiu mais: investigar, vender, organizar ou entregar?']],
 freelance:[
 ['Transforme habilidade em entrega','Escolha uma tarefa segura que sabe tentar, como organizar arquivos ou montar um item de papel. Defina o que seria uma entrega concluída.','Você gosta de produzir algo concreto para outra pessoa usar?'],
 ['Entenda um pedido incompleto','Imagine que alguém peça “organize isso para mim”. Escreva três perguntas para esclarecer volume, formato e prazo.','Foi interessante entender a necessidade antes de executar?'],
 ['Faça uma amostra pequena','Execute uma versão de cinco minutos da entrega: organize cinco arquivos fictícios ou monte um modelo em papel, por exemplo.','Como foi executar com cuidado, sem precisar deixar perfeito?'],
 ['Crie um controle de qualidade','Liste três critérios verificáveis para sua amostra e confira um por um. Corrija uma falha.','Você gostou de conferir e ajustar o resultado?'],
 ['Estime tempo e materiais','Anote quanto a amostra levou e quais materiais usou. Estime uma entrega maior deixando uma margem de tempo.','Você prefere a execução ou o planejamento do serviço?'],
 ['Simule um pedido de alteração','Imagine que o cliente mudou o formato desejado. Descreva o que consegue ajustar e o que exigiria novo prazo.','Como foi explicar limites e combinar expectativas?'],
 ['Prepare uma ficha de serviço','Reúna amostra, critérios e limites numa folha: o que entrega, em quanto tempo e o que precisa receber antes.','Qual parte desse serviço você gostaria de repetir?']],
 social:[
 ['Explique algo que você sabe','Escolha um assunto simples e escreva uma explicação de cinco linhas para quem nunca ouviu falar dele.','Você gostou de tornar uma ideia acessível?'],
 ['Descubra a dúvida antes de ensinar','Peça a alguém uma dúvida sobre o tema ou liste duas dúvidas possíveis, identificando que são hipóteses.','Escutar a dúvida mudou o que você explicaria?'],
 ['Crie uma atividade de aprendizagem','Monte um exemplo e um exercício de uma pergunta sobre o tema, com uma explicação da resposta.','Você gostou mais de explicar ou de inventar uma atividade?'],
 ['Adapte para outro jeito de aprender','Transforme a explicação em desenho, comparação ou passo a passo. Escolha um formato diferente do primeiro.','Qual formato tornou sua ideia mais clara?'],
 ['Planeje uma ação de participação','Escolha uma dificuldade de convivência e desenhe uma pequena ação que inclua as pessoas afetadas na decisão.','Você gostou de pensar em participação, além de dar uma solução pronta?'],
 ['Teste sua explicação','Se quiser, peça a alguém para explicar o que entendeu. Sem outra pessoa, releia procurando termos que precisariam de exemplo.','Como você reagiu ao perceber que precisava explicar de outro jeito?'],
 ['Escolha como quer contribuir','Compare ensinar, adaptar materiais e planejar uma ação coletiva. Melhore um desses testes.','Você se interessou mais por aprendizagem, escuta ou mobilização?']],
 build:[
 ['Observe um espaço com atenção','Escolha um ambiente conhecido. Esboce a planta e marque uma dificuldade de circulação, uso ou iluminação que percebeu.','Observar como as pessoas usam o espaço despertou sua curiosidade?'],
 ['Desenhe duas soluções','No papel, faça duas alternativas para a dificuldade observada, sem mover móveis ou alterar estruturas.','Você gostou de imaginar alternativas e compará-las?'],
 ['Teste proporções no papel','Desenhe uma mesa fictícia usando 1 quadrado para cada 10 cm. Compare dois tamanhos de mesa no mesmo espaço desenhado.','Como foi trabalhar com medida e proporção?'],
 ['Construa um modelo de papel','Dobre uma folha para representar uma das soluções. Use só papel, sem ferramentas cortantes ou testes de carga.','Você gostou de passar do desenho para o modelo?'],
 ['Compare escolhas de materiais','Para seu modelo conceitual, compare papel e papelão em rigidez, facilidade de uso e reaproveitamento. Não conclua sobre segurança de construções reais.','Foi interessante pensar nas propriedades dos materiais?'],
 ['Faça uma revisão de uso','Imagine alguém usando seu espaço com mochila ou mobilidade reduzida. Marque obstáculos possíveis e revise o desenho.','O que mudou quando você pensou em outro usuário?'],
 ['Monte uma prancha conceitual','Junte problema, duas alternativas e modelo. Escreva por que escolheria uma delas e o que precisaria investigar.','Você preferiu desenhar, medir, modelar ou revisar o uso?']],
 care:[
 ['Conheça dois papéis de cuidado','Escolha duas profissões da área e liste o que gostaria de entender sobre a rotina de cada uma. Separe fatos conhecidos de dúvidas.','Sua curiosidade está no cuidado, no movimento ou na investigação?'],
 ['Mapeie uma experiência de acolhimento','Descreva as etapas fictícias de alguém chegando a um serviço: recepção, espera e orientação. Marque onde faltaria informação.','Você se interessou por como a pessoa se sente ao buscar ajuda?'],
 ['Pratique escuta sem aconselhar','Peça a alguém para contar como foi uma atividade comum ou escreva um diálogo fictício. Resuma o que ouviu sem diagnosticar nem dar conselho.','Escutar com atenção foi interessante ou desgastante?'],
 ['Traduza uma informação de serviço','Reescreva um aviso fictício de agendamento em linguagem simples: horário, local e documentos. Não inclua orientações clínicas.','Você gostou de tornar instruções claras para outras pessoas?'],
 ['Organize uma agenda fictícia','Distribua quatro atendimentos fictícios em horários, incluindo pausas e uma alteração de última hora. Não use dados reais.','Organizar o serviço também te interessa ou só o contato com pessoas?'],
 ['Compare cuidado e desempenho','Escreva perguntas para conhecer o trabalho de um profissional de saúde e de um profissional do esporte. Não proponha treinos nem tratamentos.','Que diferenças entre as duas rotinas você quer entender melhor?'],
 ['Escolha o que quer conhecer de perto','Reúna os testes e planeje uma conversa sobre a rotina de uma profissão. Anote três perguntas, sem precisar agendar agora.','Você repetiria escuta, comunicação, organização ou pesquisa?']],
 nature:[
 ['Faça uma observação de campo','Observe uma janela, jardim ou rua de um local seguro. Anote três elementos naturais e uma pergunta, sem coletar ou tocar em animais.','Você gostou de reparar no ambiente com mais atenção?'],
 ['Registre mudanças','Observe novamente o mesmo lugar ou compare fotos próprias. Registre uma diferença visível e uma possível explicação, identificando-a como hipótese.','Você teve vontade de voltar para conferir sua hipótese?'],
 ['Investigue resíduos sem manusear','Observe os recipientes de descarte de um espaço e anote quais sinalizações existem. Não abra lixeiras nem toque nos resíduos.','Você se interessou pelo sistema de descarte e seus problemas?'],
 ['Organize um pequeno conjunto de dados','Monte uma tabela com cinco observações do ambiente, como presença de sombra ou tipos de superfície. Procure um padrão.','Foi interessante organizar observações em dados?'],
 ['Compare duas ideias de melhoria','Imagine duas ações para reduzir desperdício em uma atividade. Compare esforço, recursos e como verificaria o efeito.','Você gostou de pensar no impacto e nos limites de uma solução?'],
 ['Explique uma descoberta com cuidado','Crie uma ficha com uma observação, uma hipótese e o que falta conferir. Evite apresentar hipótese como certeza.','Você gostou de comunicar uma descoberta sem ter todas as respostas?'],
 ['Escolha uma pergunta para continuar','Reúna observações, tabela e ideias. Escolha uma pergunta e planeje uma nova observação segura.','Você repetiria campo, análise, comunicação ou planejamento ambiental?']]
};
function getPlan(k){const base=routinePlans[k],state=routineState[k],project=projectFor(k);return {...base,intro:'Sete experiências curtas para sentir como é atuar nesta área. Não precisam acontecer em dias seguidos. Você não precisa gostar de todas.',focus:'Experimentar atividades diferentes de '+routes[k].title.toLowerCase()+'.',days:base.days.map((item,i)=>state.days[i].taskSnapshot||(i<7?[experimentalWeeks[k][i][0],experimentalWeeks[k][i][1]+(project?' Se fizer sentido, use como tema seu projeto “'+project.title+'”.':'')+' Ao registrar: '+experimentalWeeks[k][i][2]]:item))};}
function experimentWeekPreview(k){return `<section class="ex-week"><span class="rp-overline">Uma semana para sentir na prática</span><h2>7 testes. Nenhuma obrigação de acertar.</h2><p>Cada dia explora uma atividade diferente desta área. Você escolhe continuar, adaptar ou mudar depois de experimentar.</p><ol>${experimentalWeeks[k].map(([title,task,reflection],i)=>`<li><span class="ex-day">${i+1}</span><div><h3>${title}</h3><p>${task}</p><small>Perceba: ${reflection}</small></div></li>`).join('')}</ol><button class="rp-button" data-route="${k}">Quero experimentar esta área →</button></section>`}

Object.entries(experimentalWeeks).forEach(([k,week])=>{routinePlans[k].days=week.map(([title,task,reflection])=>[title,task+' Ao registrar: '+reflection]).concat(routinePlans[k].days.slice(7));});
function mentorState(){return youth.mentor??={draft:'',messages:[],attachments:[],error:'',useContext:true}}
let mentorRecognition=null,mentorListening=false;
function mentorContext(){const k=routeChosen?activeRoute:null,rs=k?routineState[k]:null,day=k?nextDailyIndex():-1;return {k,title:k?routes[k].title:'Indefinido',project:k?projectFor(k):null,task:k&&day>=0?getPlan(k).days[day]:null,records:rs?rs.days.filter(x=>x.registered):[]}}
function mentorDemo(text){const c=mentorContext(),m=mentorState();if(!m.useContext)return 'Exemplo de feedback, sem IA conectada: descreva o objetivo do projeto, mostre uma parte e diga em qual ponto quer ajuda. Um próximo teste pode ser pedir a alguém para explicar o que entendeu.';if(!c.k)return 'Exemplo de feedback, sem IA conectada: seu caminho ainda está indefinido. Escolha uma área para experimentar ou conclua seu mapa. Você também pode contar qual projeto está tentando desenvolver.';const last=c.records.at(-1);return 'Exemplo de feedback, sem IA conectada.\n\nContexto do app: '+c.title+(c.project?' · projeto “'+c.project.title+'”':'')+'.\n\n'+(last?'Seu último registro: “'+(last.note||moodLabels[last.mood])+'”. Isso é seu relato, não uma avaliação da qualidade do projeto.\n\n':'Você ainda não registrou uma experiência nesta área.\n\n')+(c.task?'Um próximo teste possível: '+c.task[0]+'. '+c.task[1]:'Revise seus registros e escolha uma experiência que gostaria de repetir.')+'\n\nPara receber feedback específico, descreva o que tentou, qual resultado esperava e onde travou.'}
function mentorSend(){const m=mentorState();if(!m.draft.trim()&&!m.attachments.length)return;const attachments=m.attachments.map(a=>({...a}));m.messages.push({role:'user',text:m.draft.trim(),attachments});const suffix=attachments.length?'\n\nAnexos recebidos nesta prévia: '+attachments.map(a=>a.name).join(', ')+'. Fotos e PDFs não foram analisados; para avaliar o conteúdo será necessário conectar a IA.':'';m.messages.push({role:'assistant',text:mentorDemo(m.draft)+suffix});m.draft='';m.attachments=[];m.error='';render();}
function mentorView(){const m=mentorState(),c=mentorContext();return `<section class="ma-page"><button class="rp-home-back" data-act="home">← Voltar ao início</button><div class="ma-heading"><span class="ma-symbol"><i data-lucide="sparkles" aria-hidden="true"></i></span><div><span class="rp-overline">Seu espaço para destravar</span><h1>Mentor Rumo</h1><p>Mostre o que está fazendo.<br>Encontre um próximo teste.</p></div></div><div class="ma-layout"><aside class="ma-context"><span class="rp-overline">Contexto da conversa</span><h2>${esc(c.title)}</h2><p>${c.project?esc(c.project.title):'Nenhum projeto selecionado.'}</p><small>${c.records.length} experiências registradas</small>${c.task?`<div class="ma-current"><small>Próximo experimento</small><h3>${esc(c.task[0])}</h3></div>`:''}<label><input type="checkbox" data-mentor-context ${m.useContext?'checked':''}> Usar meu caminho, projeto e registros</label><small>Este controle vale para os exemplos de feedback. Você pode desligá-lo a qualquer momento.</small><button class="rp-link" data-up-panel="paths">Conhecer caminhos ↗</button></aside><div class="ma-chat"><div class="ma-log" aria-live="polite">${m.messages.length?m.messages.map((msg,i)=>`<article class="ma-bubble ma-${msg.role}"><span class="rp-overline">${msg.role==='user'?'Você':'Mentor · exemplo demonstrativo'}</span><p>${esc(msg.text)}</p>${(msg.attachments||[]).map(a=>`<div class="ma-attachment">${a.image?`<img src="${a.image}" alt="Prévia da imagem anexada">`:''}<span>${esc(a.name)}</span>${a.text?'<small>Texto carregado localmente · sem análise de IA</small>':''}</div>`).join('')}${msg.role==='assistant'?`<button class="rp-link" data-mentor-read="${i}"><i data-lucide="volume-2" aria-hidden="true"></i> Ouvir resposta</button>`:''}</article>`).join(''):`<div class="ma-welcome"><i data-lucide="messages-square" aria-hidden="true"></i><h2>Uma ideia ainda pela metade?<br>Pode trazer.</h2><p>Conte o que tentou ou anexe uma referência para visualizar como seria a conversa.</p><div class="ma-prompts">${['Quero feedback sobre meu projeto','Travei no próximo passo','Como posso testar essa ideia?'].map(t=>`<button data-mentor-prompt="${t}">${t} ↗</button>`).join('')}</div></div>`}</div><section class="ma-compose"><div class="ma-files">${m.attachments.map((a,i)=>`<div class="ma-file">${a.image?`<img src="${a.image}" alt="Imagem selecionada">`:'<i data-lucide="file-text" aria-hidden="true"></i>'}<span>${esc(a.name)}</span><button data-mentor-remove="${i}" aria-label="Remover ${esc(a.name)}">×</button></div>`).join('')}</div><label for="ma-draft" class="rp-overline">Sua mensagem</label><textarea id="ma-draft" data-mentor-draft maxlength="3000" rows="3" placeholder="O que você está desenvolvendo e em qual parte precisa de ajuda?">${esc(m.draft)}</textarea><div class="ma-compose-actions"><div><button class="ma-icon" data-mentor-action="attach" aria-label="Adicionar fotos ou arquivos"><i data-lucide="plus" aria-hidden="true"></i><span>Adicionar</span></button><button class="ma-icon" data-mentor-action="voice" aria-pressed="${mentorListening}"><i data-lucide="${mentorListening?'square':'mic'}" aria-hidden="true"></i><span>${mentorListening?'Parar':'Falar'}</span></button></div><button class="rp-button" data-mentor-action="send">Enviar →</button></div><input id="ma-upload" type="file" accept="image/jpeg,image/png,image/webp,application/pdf,text/plain" multiple hidden><p class="ma-status" role="status">${esc(m.error|| (mentorListening?'Ouvindo… fale sua mensagem.':'Até 3 anexos · JPG, PNG, WebP, PDF ou TXT · 5 MB cada.'))}</p><small>O microfone depende do navegador e de sua permissão. A fala pode ser processada pelo serviço do navegador. Revise a transcrição antes de enviar.</small></section></div></div></section>`}
function mentorVoice(){const m=mentorState();if(mentorListening){mentorRecognition?.stop();return;}const Recognition=typeof window!=='undefined'&&(window.SpeechRecognition||window.webkitSpeechRecognition);if(!Recognition){m.error='Este navegador não oferece ditado aqui. Use o microfone do teclado do celular ou digite sua mensagem.';render();return;}try{const r=new Recognition();mentorRecognition=r;r.lang='pt-BR';r.interimResults=false;r.continuous=false;r.onstart=()=>{mentorListening=true;render()};r.onresult=e=>{m.draft=(m.draft+' '+e.results[0][0].transcript).trim().slice(0,3000)};r.onerror=e=>{m.error=e.error==='not-allowed'?'Microfone não autorizado. Você pode digitar ou liberar o acesso no navegador.':'Não foi possível reconhecer a fala. Tente novamente ou digite.'};r.onend=()=>{mentorListening=false;if(view==='mentor')render()};m.error='';r.start();}catch{mentorListening=false;m.error='O microfone não pôde iniciar nesta visualização. Use o teclado para continuar.';render();}}
root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||!root.contains(b))return;const d=b.dataset,m=mentorState();if(d.mentorOpen){closeMenu();view='mentor';render();return;}if(d.mentorPrompt){m.draft=d.mentorPrompt;render();root.querySelector('#ma-draft')?.focus();return;}if(d.mentorRemove!==undefined){m.attachments.splice(Number(d.mentorRemove),1);render();return;}if(d.mentorRead!==undefined){const msg=m.messages[Number(d.mentorRead)];if(typeof speechSynthesis==='undefined'||typeof SpeechSynthesisUtterance==='undefined'){m.error='Leitura em voz alta indisponível neste navegador.';render();return;}speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(msg.text);u.lang='pt-BR';speechSynthesis.speak(u);return;}if(d.mentorAction==='attach')root.querySelector('#ma-upload')?.click();if(d.mentorAction==='voice')mentorVoice();if(d.mentorAction==='send')mentorSend();});
root.addEventListener('input',e=>{if(e.target.hasAttribute('data-mentor-draft'))mentorState().draft=e.target.value.slice(0,3000)});
root.addEventListener('change',async e=>{if(e.target.hasAttribute('data-mentor-context')){mentorState().useContext=e.target.checked;return;}if(e.target.id!=='ma-upload')return;const m=mentorState(),owner=youth;for(const file of Array.from(e.target.files||[])){if(m.attachments.length>=3){m.error='Você pode adicionar até 3 anexos por mensagem.';break;}if(file.size>5*1024*1024){m.error='O arquivo '+file.name+' ultrapassa 5 MB.';continue;}if(!['image/jpeg','image/png','image/webp','application/pdf','text/plain'].includes(file.type)){m.error='Formato não aceito: '+file.name;continue;}const a={name:file.name.slice(0,180),type:file.type,image:null,text:null};try{if(file.type.startsWith('image/'))a.image=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file)});else if(file.type==='text/plain')a.text=(await file.text()).slice(0,12000);if(youth!==owner)return;m.attachments.push(a);}catch{m.error='Não foi possível abrir '+file.name;}}if(view==='mentor')render();});

let rumoTheme='dark';
function applyRumoTheme(value){rumoTheme=value==='light'?'light':'dark';root.dataset.theme=rumoTheme;}
function settingsView(){return `<section class="ts-page"><button class="rp-home-back" data-act="home">← Voltar ao início</button><span class="rp-overline">Do seu jeito</span><h1>Configurações</h1><p>Escolha a aparência que fica mais confortável para você.</p><section class="ts-appearance"><h2>Aparência</h2><div class="ts-options" role="group" aria-label="Tema do aplicativo">${[['light','sun','Claro','Fundos claros e textos escuros'],['dark','moon','Escuro','Fundos escuros e textos claros']].map(([k,icon,title,desc])=>`<button data-rumo-theme="${k}" aria-pressed="${rumoTheme===k}"><div class="ts-sample ts-${k}" aria-hidden="true"><span></span><div><b></b><b></b><b></b></div></div><div class="ts-label"><i data-lucide="${icon}" aria-hidden="true"></i><strong>${title}</strong><span>${rumoTheme===k?'✓':''}</span></div><small>${desc}</small></button>`).join('')}</div><p role="status">Tema ${rumoTheme==='light'?'claro':'escuro'} selecionado. A mudança vale para todo o aplicativo.</p></section></section>`}
root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||!root.contains(b))return;if(b.dataset.rumoSettings){closeMenu();view='settings';render();return;}if(b.dataset.rumoTheme&&['light','dark'].includes(b.dataset.rumoTheme)){applyRumoTheme(b.dataset.rumoTheme);if(typeof saveRumoTheme==='function')saveRumoTheme();render();}});

applyRumoTheme('dark');let HOSTING_KEY='rumo.account.v1.guest';
let hostingDb=null,hostingReady=false,hostingPending=null,hostingWriting=false,hostingInputTimer=null;
const savedText=(v,limit=3000)=>typeof v==='string'?v.slice(0,limit):'';
const savedRoute=v=>Object.hasOwn(routes,v)?v:'creative';
const savedTopic=v=>Object.hasOwn(youthTopics,v)?v:'sport';
const savedImage=v=>typeof v==='string'&&v.length<=4300000&&/^data:image\/(png|jpeg|webp);base64,[a-z0-9+/=]+$/i.test(v)?v:'';
function cleanStoredCreation(c,editor=false){
 if(!c||typeof c!=='object')return null;
 if(!editor&&(!savedText(c.id,100)||!savedText(c.title,120)))return null;
 return {id:editor&&!c.id?null:savedText(c.id,100),title:savedText(c.title,120),description:savedText(c.description),url:validProjectUrl(savedText(c.url,2000))||'',image:savedImage(c.image),type:'text',status:c.status==='done'?'done':'draft',feedbackRequested:!!c.feedbackRequested,route:savedRoute(c.route),topic:savedTopic(c.topic),projectId:savedText(c.projectId,100)||null,duoId:savedText(c.duoId,100)||null,error:''};
}
function cleanStoredDuo(value){
 const fresh=newDuo();if(!value||typeof value!=='object')return fresh;
 fresh.phase=value.phase==='mission'?'mission':'setup';fresh.nameA=savedText(value.nameA,30);fresh.nameB=savedText(value.nameB,30);fresh.topic=savedTopic(value.topic);fresh.route=savedRoute(value.route);fresh.id=savedText(value.id,100)||null;
 const roles=v=>({a:Object.hasOwn(duoRoles,v?.a)?v.a:'create',b:Object.hasOwn(duoRoles,v?.b)?v.b:'research'});
 const records=v=>Object.fromEntries(['a','b'].map(k=>[k,{done:!!v?.[k]?.done,energy:Object.hasOwn(energyLabels,v?.[k]?.energy)?v[k].energy:'',note:savedText(v?.[k]?.note,1000)}]));
 if(typeof cleanDuoQuiz==='function'&&value.quiz)fresh.quiz=cleanDuoQuiz(value.quiz);
 fresh.roles=roles(value.roles);fresh.records=records(value.records);fresh.round=Number.isInteger(value.round)&&value.round>0?value.round:1;
 fresh.rounds=Array.isArray(value.rounds)?value.rounds.slice(0,100).filter(r=>r&&typeof r==='object').map((r,i)=>({number:Number.isInteger(r.number)?r.number:i+1,roles:roles(r.roles),records:records(r.records)})):[];
 return fresh;
}
function restoreHostedState(data){
 if(!data||data.version!==2||!Array.isArray(data.answers)||data.answers.length!==10)return false;
 answers=data.answers.map((v,i)=>Number.isInteger(v)&&v>=-1&&v<questions[i].options.length?v:null);
 step=Number.isInteger(data.step)?Math.max(0,Math.min(9,data.step)):0;activeRoute=savedRoute(data.activeRoute);routeChosen=!!data.routeChosen&&Object.hasOwn(routes,data.activeRoute);interestFocus=savedText(data.interestFocus,100)||null;
 routineState=freshRoutes();
 for(const k of Object.keys(routes)){
  const value=data.routineState?.[k];if(!value||!Array.isArray(value.days))continue;
  const state=routineState[k];state.days=state.days.map((d,i)=>{
   const item=value.days[i]||{},mood=Object.hasOwn(moodLabels,item.mood)?item.mood:'',note=savedText(item.note,2000);
   const restored={mood,note,registered:!!item.registered&&!!mood&&(mood!=='other'||!!note.trim())};
   if(Array.isArray(item.taskSnapshot)&&item.taskSnapshot.length===2)restored.taskSnapshot=[savedText(item.taskSnapshot[0],160),savedText(item.taskSnapshot[1],4000)];
   return restored;
  });
  const f=value.feedback||{};state.feedback={feeling:Object.hasOwn(feedbackFeeling,f.feeling)?f.feeling:null,next:Object.hasOwn(feedbackNext,f.next)?f.next:null,note:savedText(f.note,2000),saved:false};
  state.feedback.saved=!!f.saved&&!!state.feedback.feeling&&!!state.feedback.next;
  state.passAccess=!!value.passAccess&&state.days.slice(0,7).every(d=>d.registered)&&state.feedback.saved;state.extended=state.passAccess;
  state.openDay=Number.isInteger(value.openDay)?Math.max(0,Math.min(state.extended?13:6,value.openDay)):0;
 }
 youth=newYouth();const value=data.youth;
 if(value&&typeof value==='object'){
  youth.topic=savedTopic(value.topic);youth.projectRoute=Object.hasOwn(routes,value.projectRoute)?value.projectRoute:null;
  for(const k of Object.keys(routes)){const p=value.projects?.[k];if(p&&Object.hasOwn(youthTopics,p.topic))youth.projects[k]={...proposedProject(k,p.topic),id:savedText(p.id,100)||'restored-'+k}}
  youth.creations=Array.isArray(value.creations)?value.creations.slice(0,100).map(c=>cleanStoredCreation(c)).filter(Boolean):[];
  youth.editor=value.editor?cleanStoredCreation(value.editor,true):null;
  youth.compareSelection=Array.isArray(value.compareSelection)?[...new Set(value.compareSelection.filter(k=>Object.hasOwn(routes,k)))].slice(0,2):[];
  for(const [key,pair] of Object.entries(value.comparisons||{}).slice(0,36)){
   const keys=key.split('|');if(keys.length!==2||keys[0]===keys[1]||!keys.every(k=>Object.hasOwn(routes,k))||!pair)continue;
   youth.comparisons[key]={topic:savedTopic(pair.topic),entries:Object.fromEntries(keys.map(k=>{const e=pair.entries?.[k]||{},energy=Object.hasOwn(energyLabels,e.energy)?e.energy:'',repeat=Object.hasOwn(repeatLabels,e.repeat)?e.repeat:'';return [k,{energy,repeat,note:savedText(e.note,1000),tried:!!e.tried&&!!energy&&!!repeat}]}))};
  }
  for(const k of Object.keys(routes)){const n=value.next?.[k];if(n)youth.next[k]={goal:Object.hasOwn(nextGoals,n.goal)?n.goal:null,done:Object.fromEntries(Object.keys(nextGoals).map(g=>[g,Array.from({length:3},(_,i)=>!!n.done?.[g]?.[i])]))}}
  youth.earned=Array.isArray(value.earned)?youthBadges.map(b=>b.id).filter(id=>value.earned.includes(id)):[];
  youth.counter=Number.isSafeInteger(value.counter)&&value.counter>0?value.counter:youth.creations.length+1;
  if(value.duo)youth.duo=cleanStoredDuo(value.duo);
  if(value.upgrades){youth.upgrades={minutes:[10,20,30].includes(value.upgrades.minutes)?value.upgrades.minutes:20,reflections:{}};for(const k of Object.keys(routes)){const r=value.upgrades.reflections?.[k];if(['continue','adapt','change'].includes(r))youth.upgrades.reflections[k]=r;}}
 }
 passportDemo=false;demoSnapshot=null;catalogue=false;view='home';return true;
}
function captureHostedState(){
 const source=passportDemo&&demoSnapshot?demoSnapshot:{answers,routineState,activeRoute,step,interestFocus,routeChosen,youth};
 const storedYouth={...source.youth};delete storedYouth.mentor;
 return JSON.parse(JSON.stringify({version:2,answers:source.answers,routineState:source.routineState,activeRoute:source.activeRoute,step:source.step,interestFocus:source.interestFocus,routeChosen:source.routeChosen,youth:storedYouth}));
}
function openHostingDb(){return new Promise((resolve,reject)=>{
 if(!globalThis.indexedDB){reject(new Error('IndexedDB unavailable'));return}
 const request=indexedDB.open('rumo-complete',1);
 request.onupgradeneeded=()=>{if(!request.result.objectStoreNames.contains('state'))request.result.createObjectStore('state')};
 request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);request.onblocked=()=>reject(new Error('Storage blocked'));
})}
function readHostingDb(){return new Promise((resolve,reject)=>{
 const tx=hostingDb.transaction('state','readonly'),request=tx.objectStore('state').get(HOSTING_KEY);
 request.onsuccess=()=>resolve(request.result||null);request.onerror=()=>reject(request.error);
})}
function writeHostingDb(data){return new Promise((resolve,reject)=>{
 const tx=hostingDb.transaction('state','readwrite');tx.objectStore('state').put(data,HOSTING_KEY);
 tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error('Storage aborted'));
})}
function hostingStatus(failed){const label=root.querySelector('.rp-foot span');if(label)label.textContent=failed?'Não foi possível salvar neste navegador. Mantenha a página aberta e verifique o espaço disponível.':'Sem cobrança real · progresso salvo neste navegador'}
async function flushHostedSave(){
 if(hostingWriting)return;hostingWriting=true;
 while(hostingPending){const data=hostingPending;hostingPending=null;try{if(hostingDb)await writeHostingDb(data);else localStorage.setItem(HOSTING_KEY,JSON.stringify(data));hostingStatus(false)}catch{hostingStatus(true)}}
 hostingWriting=false;
}
function scheduleHostedSave(){if(!hostingReady||!authUser)return;hostingPending=captureHostedState();void flushHostedSave()}
root.addEventListener('click',scheduleHostedSave);
root.addEventListener('change',scheduleHostedSave);
root.addEventListener('input',()=>{clearTimeout(hostingInputTimer);hostingInputTimer=setTimeout(scheduleHostedSave,200)});
window.addEventListener('pagehide',scheduleHostedSave);
async function bootHostedApp(){
 let saved=null;
 try{hostingDb=await openHostingDb();saved=await readHostingDb()}catch{hostingDb=null;try{saved=JSON.parse(localStorage.getItem(HOSTING_KEY)||'null')}catch{}}
 try{restoreHostedState(saved)}catch{youth=newYouth();routineState=freshRoutes();answers=Array(10).fill(null);routeChosen=false;activeRoute='creative';step=0;interestFocus=null}
 hostingReady=true;catalogue=false;view='home';render();scheduleHostedSave();
}

function saveRumoTheme(){try{localStorage.setItem('rumo.appearance',rumoTheme)}catch{}}
try{applyRumoTheme(localStorage.getItem('rumo.appearance'))}catch{applyRumoTheme('dark')}

let authUser=null,authMode='login',authEmail='',authIntent=null,authBusy=false;
async function authCall(action,data={}){
 const res=await fetch('/.netlify/functions/auth',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...data})});
 let body;try{body=await res.json()}catch{throw new Error('O login precisa ser conectado à hospedagem para funcionar.')}
 if(!res.ok)throw new Error(body.error||'Não foi possível entrar.');
 return body;
}
function authView(){
 const titles={login:'Seu próximo capítulo começa aqui.',signup:'Crie sua conta. Encontre seu rumo.',recover:'Vamos recuperar seu acesso.',verify:'Confirme seu e-mail.',recovery:'Confira seu e-mail.',password:'Escolha uma nova senha.'};
 const otp=['verify','recovery'].includes(authMode),pass=['login','signup','password'].includes(authMode);
 return '<section class="ra-page"><button class="rp-link" data-auth-mode="home">← Voltar ao início</button><div class="ra-card"><span class="ra-kicker">SUA JORNADA NO RUMO</span><h1>'+titles[authMode]+'</h1><p>'+ (otp?'Digite o código de seis números enviado para '+esc(authEmail)+'.':'Entre para explorar caminhos, criar projetos e continuar sua jornada.')+'</p><form id="ra-form">'+
 (!otp&&authMode!=='password'?'<label>E-mail<input required name="email" type="email" autocomplete="email" maxlength="254" value="'+esc(authEmail)+'" placeholder="voce@exemplo.com"></label>':'')+
 (pass?'<label>'+ (authMode==='password'?'Nova senha':'Senha')+'<input required name="password" type="password" autocomplete="'+(authMode==='login'?'current-password':'new-password')+'" minlength="'+(authMode==='login'?1:12)+'" maxlength="128"></label>'+(authMode==='login'?'':'<small>Use pelo menos 12 caracteres. Uma frase com palavras diferentes funciona bem.</small>'):'')+
 (otp?'<label>Código de confirmação<input name="code" required inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" placeholder="000000"></label>':'')+
 '<p id="ra-status" role="status" aria-live="polite"></p><button class="rp-button ra-submit" type="submit">'+({login:'Entrar',signup:'Criar conta',recover:'Enviar código',verify:'Confirmar e continuar',recovery:'Confirmar código',password:'Salvar nova senha'}[authMode])+'</button></form><div class="ra-links">'+
 (authMode==='login'?'<button class="rp-link" data-auth-mode="signup">Ainda não tenho conta</button><button class="rp-link" data-auth-mode="recover">Esqueci minha senha</button><button class="rp-link" data-auth-mode="verify-entry">Já recebi um código</button>':'<button class="rp-link" data-auth-mode="login">Voltar para entrar</button>')+
 (otp?'<button class="rp-link" data-auth-resend>Reenviar código</button>':'')+
 '</div><small>Seu progresso fica neste navegador, separado por conta.</small></div></section>';
}
function showAuth(mode='login'){
 closeMenu();authMode=mode;view='auth';render();
 stage.querySelector('input')?.focus({preventScroll:true});
}
const beforeAuthRender=render;
render=function(){
 if(!authUser&&!['home','landing','auth'].includes(view)){view='auth';authMode='login'}
 if(view==='auth'){root.dataset.screen='auth';stage.innerHTML=authView();return}
 beforeAuthRender();
 let out=navigation.querySelector('[data-auth-logout]');
 if(authUser&&!out){out=document.createElement('button');out.className='rp-drawer-item';out.dataset.authLogout='true';out.textContent='Sair da conta';navigation.querySelector('nav').append(out)}
 if(!authUser)out?.remove();
};
const beforeAuthNavigate=navigate;
navigate=function(next){if(!authUser&&!['home','landing'].includes(next)){authIntent=()=>beforeAuthNavigate(next);showAuth();return}beforeAuthNavigate(next)};
const beforeAuthOpenMenu=openMenu;
openMenu=function(){if(!authUser){authIntent=()=>beforeAuthOpenMenu();showAuth();return}beforeAuthOpenMenu()};
root.addEventListener('click',e=>{
 const b=e.target.closest('button,a');if(!b)return;
 if(b.closest('.ra-page')||b.hasAttribute('data-auth-logout'))return;
 if(!authUser&&b.dataset.act!=='home'){
  e.preventDefault();e.stopImmediatePropagation();
  const attrs=[...b.attributes].filter(a=>a.name.startsWith('data-'));
  authIntent=()=>{
   const target=[...root.querySelectorAll('button,a')].find(el=>attrs.length&&attrs.every(a=>el.getAttribute(a.name)===a.value));
   target?.click();
  };
  showAuth();
 }
},true);
function clearJourney(){
 hostingReady=false;hostingPending=null;clearTimeout(hostingInputTimer);
 youth=newYouth();routineState=freshRoutes();answers=Array(10).fill(null);routeChosen=false;activeRoute='creative';step=0;interestFocus=null;passportDemo=false;demoSnapshot=null;catalogue=false;
}
async function acceptUser(user){
 if(!user||typeof user.id!=='string')throw new Error('Sessão inválida.');
 clearJourney();authUser=user;HOSTING_KEY='rumo.account.v1.'+user.id;
 await bootHostedApp();const intent=authIntent;authIntent=null;intent?.();
}
root.addEventListener('click',async e=>{
 const b=e.target.closest('button');if(!b)return;
 if(b.dataset.authMode){
  if(authBusy)return;
  if(b.dataset.authMode==='home'){authIntent=null;view='home';render();return}
  if(b.dataset.authMode==='verify-entry'){authMode='recover';showAuth('recover');return}
  showAuth(b.dataset.authMode);return;
 }
 if(b.hasAttribute('data-auth-resend')){
  if(authBusy)return;authBusy=true;b.disabled=true;
  try{const r=await authCall(authMode==='recovery'?'recover':'resend',{email:authEmail});stage.querySelector('#ra-status').textContent=r.message}catch(err){stage.querySelector('#ra-status').textContent=err.message}
  finally{authBusy=false;b.disabled=false}return;
 }
 if(b.hasAttribute('data-auth-logout')){
  if(authBusy)return;authBusy=true;
  try{await authCall('logout');location.replace(location.pathname)}
  catch(err){live.textContent=err.message}finally{authBusy=false}
 }
});
root.addEventListener('submit',async e=>{
 if(e.target.id!=='ra-form')return;e.preventDefault();if(authBusy)return;
 const form=e.target,fields=new FormData(form),button=form.querySelector('[type=submit]'),status=form.querySelector('#ra-status');
 authEmail=String(fields.get('email')||authEmail).trim();
 authBusy=true;button.disabled=true;status.textContent='Aguarde…';
 try{
  if(authMode==='login'){const r=await authCall('login',{email:authEmail,password:fields.get('password')});await acceptUser(r.user)}
  else if(authMode==='signup'){const r=await authCall('signup',{email:authEmail,password:fields.get('password')});showAuth('verify');stage.querySelector('#ra-status').textContent=r.message}
  else if(authMode==='recover'){const r=await authCall('recover',{email:authEmail});showAuth('recovery');stage.querySelector('#ra-status').textContent=r.message}
  else if(['verify','recovery'].includes(authMode)){const recovery=authMode==='recovery';const r=await authCall('verify',{email:authEmail,code:fields.get('code'),type:recovery?'recovery':'signup'});if(recovery)showAuth('password');else await acceptUser(r.user)}
  else if(authMode==='password'){await authCall('password',{password:fields.get('password')});authUser=null;clearJourney();showAuth('login');stage.querySelector('#ra-status').textContent='Senha atualizada. Entre com sua nova senha.'}
 }catch(err){status.textContent=err.message}
 finally{const pw=form.querySelector('[name=password]');if(pw)pw.value='';authBusy=false;button.disabled=false}
});
async function initAuth(){
 view='home';render();
 try{const r=await authCall('session');await acceptUser(r.user)}catch{/* Public home remains available; never simulate a session. */}
}
void initAuth();

})();
